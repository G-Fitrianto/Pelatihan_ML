# WEEK 2 ASSIGNMENT: OLS vs LASSO prediction
# Synthetic regional poverty data (100 regions, 2021-2025)
# Complete the TODOs in Questions 1 and 2; answer Question 3 in the report.

# Install once: install.packages(c("readxl", "dplyr", "ggplot2", "glmnet"))
library(readxl)
library(dplyr)
library(ggplot2)
library(glmnet)

input_file <- "Assignment_Regional_Poverty_Prediction.xlsx"
stopifnot(file.exists(input_file))
raw <- read_excel(input_file, sheet = "Assignment_Data")
predictors <- grep("^lag_", names(raw), value = TRUE)
stopifnot(length(predictors) == 64, nrow(raw) == 500)

train_raw <- filter(raw, year %in% 2021:2024)
test_raw  <- filter(raw, year == 2025)

# Prepared helper: replace missing predictor values with TRAINING medians.
impute_pair <- function(training, other, variables) {
  med <- vapply(variables, function(v) median(training[[v]], na.rm = TRUE), numeric(1))
  stopifnot(all(is.finite(med)))
  for (v in variables) {
    training[[v]][is.na(training[[v]])] <- med[v]
    other[[v]][is.na(other[[v]])] <- med[v]
  }
  list(training = training, other = other)
}

# Prepare a 2024 validation year for LASSO penalty selection.
# 2025 outcomes never enter the training or tuning process.
validation_data <- impute_pair(filter(train_raw, year <= 2023),
                               filter(train_raw, year == 2024), predictors)
x_tune <- data.matrix(validation_data$training[, predictors])
y_tune <- validation_data$training$poverty_rate_pct
x_val <- data.matrix(validation_data$other[, predictors])
y_val <- validation_data$other$poverty_rate_pct

# Prepared tuning example: pick lambda with lowest 2024 validation RMSE.
lasso_path <- glmnet(x_tune, y_tune, alpha = 1, standardize = TRUE)
validation_predictions <- predict(lasso_path, newx = x_val)
validation_rmse <- sqrt(colMeans((validation_predictions - y_val)^2))
selected_lambda <- lasso_path$lambda[which.min(validation_rmse)]
cat("Selected lambda (based on validation year 2024):", selected_lambda, "\n")

# Refit both final models using all training years, 2021-2024.
prepared <- impute_pair(train_raw, test_raw, predictors)
train <- prepared$training
test <- prepared$other
formula_ols <- reformulate(predictors, response = "poverty_rate_pct")
x_train <- data.matrix(train[, predictors]); y_train <- train$poverty_rate_pct
x_test <- data.matrix(test[, predictors]); y_test <- test$poverty_rate_pct

# QUESTION 1: ESTIMATION ------------------------------------------------------
# TODO: estimate OLS with lm() and LASSO with glmnet(alpha=1,
#       lambda=selected_lambda). Use train/x_train/y_train and the formula above.
# ols_fit <- ...
# lasso_fit <- ...

# QUESTION 2: FORECASTING AND EVALUATION -------------------------------------
# TODO: predict 2025 with both final models (test / x_test).
# pred_ols <- ...
# pred_lasso <- ...

rmse <- function(y, p) sqrt(mean((y - p)^2))
mae <- function(y, p) mean(abs(y - p))

# TODO: create a two-row table with RMSE and MAE; print it in the R Console.
# Hint: data.frame(model = c("OLS", "LASSO"),
#                  RMSE = c(rmse(y_test, pred_ols), rmse(y_test, pred_lasso)),
#                  MAE = c(mae(y_test, pred_ols), mae(y_test, pred_lasso)))

# TODO: save one actual-vs-predicted figure with a 45-degree reference line.
# Hint: ggplot, geom_point, geom_abline(slope=1, intercept=0), facet_wrap.
# ggsave("prediction_comparison_2025.png", plot_object, width=9, height=4.5)

# QUESTION 3 (PDF REPORT): CHOOSE THE MODEL ---------------------------------
# Discuss the lower 2025 RMSE, supporting MAE, prediction plot,
# and whether multicollinearity necessarily worsens forecasts.
