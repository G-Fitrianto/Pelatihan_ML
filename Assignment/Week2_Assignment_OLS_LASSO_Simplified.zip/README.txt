WEEK 2 ASSIGNMENT | OLS VS LASSO (SIMPLIFIED)

Files:
- Assignment_OLS_vs_LASSO_Week2_Simplified.pdf : one-page student brief
- Assignment_OLS_vs_LASSO_Week2_Simplified.docx : editable student brief
- Assignment_Regional_Poverty_Prediction.xlsx : identical synthetic dataset to the prior assignment
- Assignment_Starter_Simplified.R : shorter R starter template

Students complete exactly THREE questions:
1. Estimate OLS and LASSO using 2021-2024 data and identical predictors.
2. Forecast 2025 and compare RMSE, MAE, and one actual-predicted plot.
3. Select the model and justify in one short paragraph.

Submit one .R and one PDF report (max 2 pages). No other mandatory deliverables.

Important: the dataset is fully synthetic. No results about actual Indonesian regions are implied.
