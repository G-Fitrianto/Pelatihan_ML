# Pure model and data helpers for Week 2 Shiny. No side effects on import.
# All datasets and simulations here are synthetic.

score_predictions <- function(actual, estimate) {
  stopifnot(length(actual) == length(estimate), length(actual) > 0L,
            all(is.finite(actual)), all(is.finite(estimate)))
  error <- as.numeric(estimate - actual)
  data.frame(n = length(error), MAE = mean(abs(error)),
             RMSE = sqrt(mean(error^2)), Mean_error = mean(error))
}

true_function <- function(x, dgp) {
  switch(dgp,
    linear = 1.2 + 1.1 * x,
    quadratic = 0.5 + 1.1 * x + 0.9 * x^2,
    sine = 0.5 + 1.8 * sin(2.6 * x) + 0.15 * x,
    threshold = 0.5 + 1.8 * (x > 0) + 0.4 * x,
    stop('Unknown DGP'))
}

make_simulation <- function(dgp, n_train = 50, noise = 0.65, seed = 123) {
  set.seed(as.integer(seed))
  # Each partition has independent X and noise draws, on the same X support.
  sample_partition <- function(n, name) {
    x <- runif(n, -2, 2)
    data.frame(x = x, y = true_function(x, dgp) + rnorm(n, 0, noise),
               split = name)
  }
  list(train = sample_partition(n_train, 'Training'),
       val = sample_partition(140, 'Validation'),
       test = sample_partition(250, 'Test'), dgp = dgp,
       grid = data.frame(x = seq(-2, 2, length.out = 350)))
}

# Orthogonal polynomial terms for numerical stability. Degree 1 and degree K
# share a nested feature space; the original slope on x is not directly
# comparable to coefficient values on orthogonal basis columns.
poly_design <- function(train_x, degree) {
  stopifnot(degree >= 1, degree < length(unique(train_x)))
  basis <- stats::poly(train_x, degree = degree, raw = FALSE)
  transform <- function(new_x) {
    mm <- as.matrix(stats::predict(basis, newdata = as.numeric(new_x)))
    colnames(mm) <- paste0('P', seq_len(degree))
    mm
  }
  list(train = transform(train_x), transform = transform)
}

# Gaussian glmnet requires >= 2 columns. Exact one-feature solutions have
# glmnet's objective scaling: half MSE + lambda*((1-alpha)/2*bz^2+alpha*abs(bz)).
# X is population-standardized internally (intercept unpenalized).
fit_penalized <- function(x, y, alpha, lambdas) {
  x <- as.matrix(x); stopifnot(nrow(x) == length(y), ncol(x) >= 1L,
                              all(lambdas > 0), all(is.finite(lambdas)))
  if (ncol(x) >= 2L) {
    model <- glmnet::glmnet(x, y, family = 'gaussian', alpha = alpha,
                            lambda = sort(unique(lambdas), decreasing = TRUE),
                            intercept = TRUE, standardize = TRUE)
    return(list(predict = function(newx, s) as.numeric(stats::predict(
                  model, newx = as.matrix(newx), s = s)),
                coefs = function(s) as.numeric(stats::coef(model, s = s)),
                raw_model = model))
  }
  xvec <- as.numeric(x[, 1]); mu <- mean(xvec); sigma <- sqrt(mean((xvec-mu)^2))
  if (sigma <= 0 || !is.finite(sigma)) stop('Constant predictor.')
  z <- (xvec-mu)/sigma; mean_y <- mean(y); score <- mean(z*(y-mean_y))
  get_coefs <- function(lam) {
    b <- if (alpha == 0) score/(1+lam) else sign(score)*max(abs(score)-lam, 0)
    slope <- b/sigma
    c(mean_y-slope*mu, slope)
  }
  list(predict = function(newx, s) {
         b <- get_coefs(s); as.numeric(b[1] + b[2]*as.matrix(newx)[, 1])
       },
       coefs = function(s) get_coefs(s), raw_model = NULL)
}

fit_sim_core <- function(sim, degree, lambda) {
  tr <- sim$train; va <- sim$val
  basis <- poly_design(tr$x, degree)
  xt <- basis$train; xv <- basis$transform(va$x)
  xgrid <- basis$transform(sim$grid$x)
  # No penalty for OLS: exact least squares on the identical degree-K basis.
  fit_ols <- stats::lm.fit(cbind(1, xt), tr$y)
  if (anyNA(fit_ols$coefficients)) stop('OLS is rank deficient; reduce degree.')
  ols_predict <- function(x) as.numeric(cbind(1, x) %*% fit_ols$coefficients)
  grid_lambda <- exp(seq(log(10), log(0.0001), length.out = 75))
  ridge <- fit_penalized(xt, tr$y, alpha = 0, lambdas = grid_lambda)
  lasso <- fit_penalized(xt, tr$y, alpha = 1, lambdas = grid_lambda)
  candidates <- list('Linear OLS' = NULL, 'Polynomial OLS' = ols_predict,
                     'Polynomial Ridge' = ridge, 'Polynomial LASSO' = lasso)
  # Linear OLS uses the same X (original x) and stays linear in x.
  lin_fit <- stats::lm(y ~ x, data = tr)
  predictions <- function(x, x_basis, variable = 'x') {
    data.frame('Linear OLS' = as.numeric(stats::predict(lin_fit,
                                     newdata = data.frame(x = x))),
               'Polynomial OLS' = ols_predict(x_basis),
               'Polynomial Ridge' = ridge$predict(x_basis, lambda),
               'Polynomial LASSO' = lasso$predict(x_basis, lambda),
               check.names = FALSE)
  }
  pred_train <- predictions(tr$x, xt)
  pred_val <- predictions(va$x, xv)
  pred_grid <- predictions(sim$grid$x, xgrid)
  pred_test <- function() predictions(sim$test$x, basis$transform(sim$test$x))
  metric_table <- function(df, predictions, split) {
    do.call(rbind, lapply(names(predictions), function(nm) {
      cbind(data.frame(Split = split, Model = nm),
            score_predictions(df$y, predictions[[nm]]))
    }))
  }
  metrics <- rbind(metric_table(tr, pred_train, 'Training'),
                   metric_table(va, pred_val, 'Validation'))
  # Objective values at the fitted coefficients. glmnet penalizes coefficients
  # after standardizing the orthogonal basis to population SD units.
  objective <- do.call(rbind, lapply(c('Polynomial OLS','Polynomial Ridge','Polynomial LASSO'), function(nm) {
    fit_obj <- switch(nm, 'Polynomial OLS' = NULL, 'Polynomial Ridge' = ridge,
                      'Polynomial LASSO' = lasso)
    b <- if (is.null(fit_obj)) fit_ols$coefficients[-1] else fit_obj$coefs(lambda)[-1]
    bz <- b * apply(xt, 2, function(v) sqrt(mean((v-mean(v))^2)))
    mseloss <- mean((tr$y-pred_train[[nm]])^2)/2
    penalty <- switch(nm, 'Polynomial OLS' = 0,
                      'Polynomial Ridge' = lambda/2*sum(bz^2),
                      'Polynomial LASSO' = lambda*sum(abs(bz)))
    data.frame(Model = nm, Half_MSE = mseloss, Penalty = penalty,
               Penalized_objective = mseloss+penalty,
               Nonzero_terms = sum(abs(b) > 1e-7))
  }))
  # Full regularization path: train coefficients, validation performance.
  paths <- do.call(rbind, lapply(c('Ridge','LASSO'), function(nm) {
    obj <- if (nm == 'Ridge') ridge else lasso
    do.call(rbind, lapply(grid_lambda, function(lam) {
      estimate <- obj$predict(xv, lam)
      coef <- obj$coefs(lam)[-1]
      data.frame(Model = nm, lambda = lam,
                 validation_RMSE = score_predictions(va$y, estimate)$RMSE,
                 term = paste0('P', seq_along(coef)), coefficient = coef)
    }))
  }))
  list(data = sim, degree = degree, lambda = lambda, basis = basis,
       metrics = metrics, objective = objective, paths = paths,
       pred_train = pred_train, pred_val = pred_val, pred_grid = pred_grid,
       pred_test = pred_test, lin_fit = lin_fit,
       ridge = ridge, lasso = lasso)
}

# Model engines for arbitrary numeric matrices, shared by simulation + panel.
# Missing optional packages are caught upstream and shown to users.
model_package <- function(name) switch(name,
  'Decision Tree' = 'rpart', 'Random Forest' = 'ranger',
  'XGBoost' = 'xgboost', 'SVR (RBF)' = 'e1071', stop('Unknown model'))

fit_advanced <- function(name, train_x, train_y, config) {
  train_x <- as.matrix(train_x)
  colnames(train_x) <- if (is.null(colnames(train_x))) paste0('x',seq_len(ncol(train_x))) else colnames(train_x)
  pkg <- model_package(name)
  if (!requireNamespace(pkg, quietly = TRUE))
    stop(sprintf('Package %s is not installed. Run install.packages("%s").', pkg, pkg))
  if (name == 'Decision Tree') {
    df <- as.data.frame(train_x);df$y <- train_y
    model <- rpart::rpart(y ~ ., data = df, method = 'anova',
      control = rpart::rpart.control(maxdepth = config$tree_depth,
        cp = 0, xval = 0, minsplit = 6, minbucket = 3))
    return(function(newx) as.numeric(stats::predict(model,
                        newdata = as.data.frame(setNames(as.data.frame(as.matrix(newx)),
                                                                 colnames(train_x))))))
  }
  if (name == 'Random Forest') {
    df <- as.data.frame(train_x); df$y <- train_y
    model <- ranger::ranger(y ~ ., data = df, num.trees = config$trees,
                mtry = max(1L, floor(sqrt(ncol(train_x)))),
                min.node.size = config$min_node, seed = config$seed,
                num.threads = 1L)
    return(function(newx) as.numeric(predict(model, data =
       as.data.frame(setNames(as.data.frame(as.matrix(newx)),colnames(train_x))))$predictions))
  }
  if (name == 'XGBoost') {
    set.seed(config$seed)
    dtr <- xgboost::xgb.DMatrix(data = train_x, label = train_y)
    model <- xgboost::xgb.train(data = dtr, nrounds = config$rounds,
      params = list(objective = 'reg:squarederror', eta = config$eta,
          max_depth = config$tree_depth, subsample = 1, colsample_bytree = 1,
          nthread = 1, verbosity = 0), verbose = 0)
    return(function(newx) {
      xx <- as.matrix(newx); colnames(xx) <- colnames(train_x)
      as.numeric(predict(model, xgboost::xgb.DMatrix(xx)))
    })
  }
  if (name == 'SVR (RBF)') {
    model <- e1071::svm(x = train_x, y = train_y, type = 'eps-regression',
                        kernel = 'radial', cost = config$svr_cost,
                        gamma = config$svr_gamma, epsilon = 0.1,
                        scale = TRUE)
    return(function(newx) {
      xx <- as.matrix(newx); colnames(xx) <- colnames(train_x)
      as.numeric(predict(model, newdata = xx))
    })
  }
  stop('Unrecognized model')
}

week1_predictors <- c('grdp_pc_million_idr', 'unemployment_pct',
   'schooling_years', 'internet_access_pct', 'manufacturing_share_pct',
   'investment_pc_million_idr')
lagged_predictors <- paste0('lag_', week1_predictors)

read_week1_panel <- function(path) {
  if (!file.exists(path)) stop('Workbook is missing: ', path)
  raw <- readxl::read_excel(path, sheet = 'Economic_Panel')
  required <- c('region_id','economic_zone','year','poverty_rate_pct',week1_predictors)
  if (!all(required %in% names(raw))) stop('The workbook is not the Week 1 panel.')
  if (nrow(raw) != 720 || length(unique(raw$region_id)) != 120)
    stop('Unexpected panel dimensions: expected 720 rows and 120 regions.')
  if (anyNA(raw$poverty_rate_pct) || anyDuplicated(raw[,c('region_id','year')]))
    stop('Invalid outcome or duplicate region-year.')
  raw <- raw[order(raw$region_id,raw$year), ]
  regions <- split(raw, raw$region_id)
  panel <- do.call(rbind,lapply(regions,function(g) {
    g <- g[order(g$year), ]; for (v in week1_predictors)
      g[[paste0('lag_',v)]] <- c(NA, head(g[[v]], -1))
    g
  }))
  panel <- panel[panel$year >= 2021, ]
  rownames(panel) <- NULL
  stopifnot(nrow(panel)==600L)
  panel
}

impute_by_training <- function(train, other) {
  medians <- vapply(lagged_predictors,
                    function(c) stats::median(train[[c]], na.rm=TRUE), numeric(1))
  if (any(!is.finite(medians))) stop('Missing entire predictor in training.')
  for (c in lagged_predictors) {
    train[[c]][is.na(train[[c]])] <- medians[[c]]
    other[[c]][is.na(other[[c]])] <- medians[[c]]
  }
  list(train=train,other=other,medians=medians)
}

# Never read test outcomes in the model/parameter tuning section.
fit_week1_models <- function(panel, config, extra = character()) {
  train0 <- panel[panel$year <= 2024, ]
  test0 <- panel[panel$year == 2025, ]
  if (nrow(train0)!=480L || nrow(test0)!=120L) stop('Unexpected split sizes.')
  lambda_grid <- exp(seq(log(100),log(0.0008),length.out=75))
  folds <- list(c(2021L,2022L), c(2021:2022,2023L),c(2021:2023,2024L))
  cvrows <- list(); fnum <- 0L
  for (f in folds) {
    fnum <- fnum+1L
    im <- impute_by_training(train0[train0$year %in% f[-length(f)],],
                              train0[train0$year == f[length(f)],])
    tr <- im$train; va <- im$other
    xtr <- as.matrix(tr[,lagged_predictors]);xva <- as.matrix(va[,lagged_predictors])
    ytr <- tr$poverty_rate_pct;yva <- va$poverty_rate_pct
    ols <- stats::lm(stats::reformulate(lagged_predictors,
                        response='poverty_rate_pct'), data=tr)
    for (nm in c('Multiple OLS','Ridge','LASSO',extra)) {
      if (nm=='Multiple OLS') {
        pred <- as.numeric(predict(ols,newdata=va))
        sc <- score_predictions(yva,pred)
        cvrows[[length(cvrows)+1L]] <- data.frame(Model=nm,
                   fold=fnum,lambda=NA_real_,MSE=sc$RMSE^2,MAE=sc$MAE,n=sc$n)
      } else if (nm %in% c('Ridge','LASSO')) {
        obj <- fit_penalized(xtr,ytr,if (nm=='Ridge') 0 else 1,lambda_grid)
        for (lam in lambda_grid) {
          pred <- obj$predict(xva,lam)
          sc <- score_predictions(yva,pred)
          cvrows[[length(cvrows)+1L]] <- data.frame(Model=nm,
                      fold=fnum,lambda=lam,MSE=sc$RMSE^2,MAE=sc$MAE,n=sc$n)
        }
      } else {
        # Advanced hyperparams are fixed by user BEFORE viewing test results.
        pred <- tryCatch({fn<-fit_advanced(nm,xtr,ytr,config);fn(xva)},error=function(e) e)
        if (!inherits(pred,'error')) {
          sc <- score_predictions(yva,pred)
          cvrows[[length(cvrows)+1L]] <- data.frame(Model=nm,
                    fold=fnum,lambda=NA_real_,MSE=sc$RMSE^2,MAE=sc$MAE,n=sc$n)
        }
      }
    }
  }
  cv <- do.call(rbind,cvrows)
  cv$group <- ifelse(is.na(cv$lambda),'fixed',format(cv$lambda,digits=15))
  cv$weightedMSE <- cv$MSE * cv$n
  cv$weightedMAE <- cv$MAE * cv$n
  aggregated <- stats::aggregate(cbind(weightedMSE,weightedMAE,n) ~ Model+group,
                                  data=cv,FUN=sum)
  aggregated$CV_RMSE <- sqrt(aggregated$weightedMSE/aggregated$n)
  aggregated$CV_MAE <- aggregated$weightedMAE/aggregated$n
  aggregated$lambda <- suppressWarnings(as.numeric(aggregated$group))
  # Require complete fold coverage so no model has preferential validation.
  aggregated <- aggregated[aggregated$n==360L,]
  if (!nrow(aggregated)) stop('No model completed all 3 validation years.')
  select_one <- function(nm) {
    d<-aggregated[aggregated$Model==nm,,drop=FALSE]
    if (!nrow(d)) return(NULL)
    # Larger lambda breaks equal MSE ties, favoring stronger regularization.
    d[order(d$CV_RMSE,-ifelse(is.na(d$lambda),0,d$lambda))[1],,drop=FALSE]
  }
  chosen <- do.call(rbind,lapply(unique(aggregated$Model),select_one))
  final <- impute_by_training(train0,test0)
  tr<-final$train;te<-final$other
  xtr<-as.matrix(tr[,lagged_predictors]);xte<-as.matrix(te[,lagged_predictors])
  ytr<-tr$poverty_rate_pct
  mean_train<-mean(ytr)
  lm_simple<-stats::lm(poverty_rate_pct~lag_schooling_years,data=tr)
  lm_multi<-stats::lm(stats::reformulate(lagged_predictors,
                       response='poverty_rate_pct'),data=tr)
  model_fn <- list('Mean benchmark'=function(d) rep(mean_train,nrow(d)),
                   'Simple OLS'=function(d) as.numeric(predict(lm_simple,newdata=d)),
                   'Multiple OLS'=function(d) as.numeric(predict(lm_multi,newdata=d)))
  pred_tr<-lapply(model_fn,function(fn) fn(tr))
  pred_te<-lapply(model_fn,function(fn) fn(te))
  coefs <- list('Multiple OLS'=stats::coef(lm_multi))
  for (nm in c('Ridge','LASSO')) {
    decision <- chosen[chosen$Model==nm,,drop=FALSE]
    lam<-decision$lambda[1]
    obj<-fit_penalized(xtr,ytr,if (nm=='Ridge')0 else 1,lambda_grid)
    pred_tr[[nm]]<-obj$predict(xtr,lam)
    pred_te[[nm]]<-obj$predict(xte,lam)
    coefs[[nm]]<-obj$coefs(lam)
  }
  for (nm in extra) {
    fn<-tryCatch(fit_advanced(nm,xtr,ytr,config),error=function(e)e)
    if (!inherits(fn,'error')) {
      pred_tr[[nm]]<-fn(xtr); pred_te[[nm]]<-fn(xte)
    }
  }
  make_score_table <- function(df,preds,label) {
    do.call(rbind,lapply(names(preds),function(nm) {
      cbind(data.frame(Split=label, Model=nm),
            score_predictions(df$poverty_rate_pct,preds[[nm]]))
    }))
  }
  train_scores<-make_score_table(tr,pred_tr,'Training')
  test_scores<-make_score_table(te,pred_te,'Test 2025')
  numeric_check<-test_scores[test_scores$Model=='Multiple OLS',]
  # Week 1 verified: RMSE 1.977169951, MAE 1.5229110293.
  baseline_parity<-isTRUE(all.equal(numeric_check$RMSE,1.977169951,tolerance=1e-5))&&
                   isTRUE(all.equal(numeric_check$MAE,1.5229110293,tolerance=1e-5))
  pred_df<-data.frame(region_id=te$region_id,economic_zone=te$economic_zone,
       year=te$year,Observed=te$poverty_rate_pct,check.names=FALSE)
  for (nm in names(pred_te)) {
    pred_df[[paste0('Pred_',gsub('[^A-Za-z0-9]+','_',nm))]]<-pred_te[[nm]]
    pred_df[[paste0('Error_',gsub('[^A-Za-z0-9]+','_',nm))]]<-pred_te[[nm]]-te$poverty_rate_pct
  }
  list(train=tr,test=te,train_metrics=train_scores,test_metrics=test_scores,
       fold_metrics=cv, cv_curve=aggregated,chosen=chosen, pred=pred_df,
       coef=coefs,baseline_parity=baseline_parity,complete_models=names(pred_te),
       config=config)
}
