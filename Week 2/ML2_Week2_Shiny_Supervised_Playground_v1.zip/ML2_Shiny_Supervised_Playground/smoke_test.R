# Run in RStudio *inside the extracted folder*:
#   source('smoke_test.R')
# Checks exact Week 1 parity and core simulation code. No Shiny browser required.
stopifnot(file.exists('helpers.R'),file.exists('app.R'),
          file.exists('ML1_Economic_Panel_Synthetic.xlsx'))
for(pkg in c('shiny','ggplot2','glmnet','readxl'))
  if(!requireNamespace(pkg,quietly=TRUE))
    stop('Missing core package: ',pkg,'; run install.packages("',pkg,'")')
parse('app.R')
parse('helpers.R')
source('helpers.R',local=TRUE)
cat('[1/6] Both R files parsed successfully.\n')
for(dgp in c('linear','quadratic','sine','threshold')) {
  s<-make_simulation(dgp,n_train=50,noise=.7,seed=123)
  stopifnot(nrow(s$train)==50L,nrow(s$val)==140L,nrow(s$test)==250L,
            all(is.finite(s$train$y)))
}
cat('[2/6] Four synthetic DGPs generated successfully.\n')
s<-make_simulation('quadratic',n_train=50,noise=.7,seed=123)
for(deg in c(1L,2L,6L)) {
  f<-fit_sim_core(s,degree=deg,lambda=.09)
  stopifnot(nrow(f$metrics)==8L,nrow(f$objective)==3L,
            all(is.finite(f$metrics$RMSE)),
            length(f$pred_test()[['Polynomial OLS']])==250L)
  # Same polynomial feature space: OLS minimizes (unpenalized) training MSE.
  o<-f$objective
  ols_loss<-o$Half_MSE[o$Model=='Polynomial OLS']
  stopifnot(all(ols_loss<=o$Half_MSE+1e-6))
}
cat('[3/6] Linear and nonlinear fits, p=1 penalty, objectives: PASS.\n')
p<-read_week1_panel('ML1_Economic_Panel_Synthetic.xlsx')
stopifnot(nrow(p)==600L,length(unique(p$region_id))==120L)
cat('[4/6] Week 1 panel is valid; 600 model-ready region-years.\n')
config<-list(tree_depth=4L,trees=40L,min_node=5L,rounds=30L,
             eta=.12,svr_cost=3,svr_gamma=.6,seed=123L)
result<-fit_week1_models(p,config,extra=character())
stopifnot(result$baseline_parity,
          nrow(result$train)==480L,nrow(result$test)==120L,
          all(c('Mean benchmark','Simple OLS','Multiple OLS','Ridge','LASSO')
              %in% result$test_metrics$Model),
          all(is.finite(result$test_metrics$RMSE)),
          nrow(result$chosen)>=3L)
cat('[5/6] Exact Week 1 OLS parity and expanding-year validation: PASS.\n')
if(requireNamespace('rpart',quietly=TRUE)) {
  fn<-fit_advanced('Decision Tree',matrix(s$train$x,ncol=1),s$train$y,config)
  stopifnot(length(fn(matrix(s$val$x,ncol=1)))==nrow(s$val))
  cat('[6/6] Decision Tree fit and prediction: PASS.\n')
} else cat('[6/6] Decision Tree not installed; optional test skipped.\n')
cat('All available smoke tests passed. Open app.R with Run App.\n')
