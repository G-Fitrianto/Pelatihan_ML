# Week 2: Supervised Machine Learning Playground (R Shiny)

An interactive undergraduate economics workshop on **OLS versus Ridge/LASSO versus nonlinear supervised methods**, with the same *synthetic economic panel* used in Week 1. No internet connection or external dataset is required **after the R packages have been installed**.

## Get started in RStudio

1. Unzip the ZIP package **without separating the files**. The folder should contain `app.R`, `helpers.R`, `smoke_test.R`, and `ML1_Economic_Panel_Synthetic.xlsx`.
2. Install the essential packages once:

   ```r
   install.packages(c('shiny','ggplot2','glmnet','readxl'))
   ```

3. Install optional packages to use the advanced-model explorer and the Excel download:

   ```r
   install.packages(c('rpart','ranger','xgboost','e1071','openxlsx'))
   ```

   Some packages, particularly `xgboost`, may require a C++ toolchain on Windows (Rtools). If installation is difficult, leave that model deselected; the app's basic tabs remain usable.

4. Open RStudio. Set the working directory to the extracted folder and run:

   ```r
   source('smoke_test.R')
   shiny::runApp('.', launch.browser = TRUE)
   ```

   Or open `app.R` and click **Run App**.

## Modules and learning aims

| Tab | What students manipulate | Output and intuition |
|---|---|---|
| 1. Linear vs Nonlinear | Linear/quadratic/sine/threshold DGP, sample size, noise, degree and lambda | True function, fitted curves, training/validation RMSE, optional test; OLS can represent nonlinearity through feature expansion |
| 2. Loss, Penalty & Shrinkage | Same polynomial degree and lambda from Tab 1 | Paths of orthogonal-polynomial coefficients, validation RMSE vs penalty, half-MSE and penalty decomposition |
| 3. Advanced ML Explorer | Decision Tree, Random Forest, XGBoost, SVR-RBF; algorithm hyperparameters | Nonlinear fitted curves and validation RMSE on identical synthetic observations |
| 4. Week 1 Economic Panel | Six previous-year predictors, training years 2021–2024, validation years 2022–2024, final testing year 2025 | Reproduces OLS benchmark, performs chronological regularization tuning, plots actual vs predicted, exports CSV/XLSX |
| Instructor Notes | Pre-defined teaching sequence and methodological caveats | Discussion prompts and software requirements |

**Synthetic DGP:** 50+ training observations, plus fixed independent validation (140) and testing (250) observations. The sample seed is fixed until **Generate / reset data** is pressed. The true functional relationship is known because it was generated, not estimated from actual economic data.

**Polynomial features:** OLS, Ridge, and LASSO use the same orthogonal polynomial basis of the selected degree. A separate **Linear OLS** fit is always shown as the benchmark. The polynomial basis is learned only from training X. With degree = 1, the one-feature Ridge/LASSO equations are calculated analytically because `glmnet` normally expects at least two predictor columns. Regularization changes coefficient size, not the feature-space degree.

## Econometric comparison and fairness

The bundled workbook is **identical in content** to `ML1_Economic_Panel_Synthetic.xlsx` from Week 1. It contains 720 synthetic region-year rows and 120 fictitious regions (2020–2025). The app constructs lags, leaving 2021–2025 outcomes, then divides into **480 training (2021–2024) and 120 testing (2025)**.

- Mean benchmark, Simple OLS, and six-predictor Multiple OLS are reproduced with the original Week 1 model specifications.
- Expected Multiple OLS test MAE **1.5229** and RMSE **1.9772**, in poverty percentage points. The app checks this internally.
- Ridge and LASSO use **exactly the same six lagged predictors** as Multiple OLS.
- Penalties are selected using three expanding historical folds: fit 2021 / validate 2022, fit 2021–22 / validate 2023, fit 2021–23 / validate 2024. Imputation medians are learned within each fold's training period.
- Advanced models, when selected, use the same observed features and year folds. Their hyperparameters are controlled manually and compared on historical validation. The app does **not** automatically tune their hyperparameters.
- After choices are made, models are refitted on all training years. The **Reveal final 2025 test** button shows the results. The evaluation gate is for teaching: if students repeatedly adjust choices after seeing 2025 outcomes, 2025 loses its status as an independent test set.

## Excel and CSV downloads

- **Tab 1**: `Week2_simulated_prediction_comparison.csv`, including the synthetic test subset only after it is revealed.
- **Tab 4**: `Week2_2025_predictions.csv` and `Week2_supervised_model_comparison.xlsx`, including training metrics, test metrics, validation curves, selected parameters, fold scores, and one-row-per-region predictions (with signed prediction errors).
- Positive prediction error = predicted minus actual, so a positive value means **over-prediction**. MAE and RMSE remain in **poverty percentage points**, not relative percentage changes.

## What not to infer

1. OLS is itself supervised learning. Ridge and LASSO add coefficient penalties. They do not inherently capture nonlinear relationships unless nonlinear features are added.
2. A more flexible or penalized algorithm may have **higher**, **lower**, or equal error on unseen data. The app makes no assumption that advanced ML must win.
3. Coefficient shrinkage or variable selection does not identify causal effects.
4. The Week 1 dataset is fully **synthetic**, not observed Indonesian regional poverty data. The results are for teaching, not policy inference.
5. A one-dimensional fitted curve is a useful explanation for the synthetic tab; the six-dimensional economic models are instead compared with their predicted versus observed values.

## Troubleshooting

- **`there is no package called 'shiny'`**: install the four essential packages listed above.
- **`Package xgboost is not installed`**: install it, or deselect XGBoost. Decision Tree requires `rpart`, Random Forest requires `ranger`, and SVR requires `e1071`.
- **Excel download fails**: install `openxlsx`; CSV downloads work without it.
- **App cannot find `helpers.R`**: the files were separated after extraction. Keep all files in one folder and launch from the extracted directory.
- **OLS Week 1 parity says CHECK THE DATASET**: review which workbook was uploaded. The bundled dataset is expected to reproduce the reference exactly.
- **A package update changes behavior**: run `smoke_test.R`, keep the package versions from `sessionInfo()` in R, and share the console error for review.

## Validation statement

All source files were checked structurally in the build environment, and the **Week 1 OLS metrics were independently recomputed** from the bundled workbook. The Shiny app and R smoke test **have not been executed in an R runtime in the creation environment**. Run `smoke_test.R` locally before classroom use. The included test checks the DGP, one-predictor regularization, polynomial fits, temporal validation, exact OLS benchmark, and a Decision Tree if installed.

## References

- `glmnet` official vignette: https://glmnet.stanford.edu/articles/glmnet.html
- `ranger` R package documentation: https://cran.r-project.org/package=ranger
- `e1071` SVR documentation: https://cran.r-project.org/package=e1071
- `xgboost` R documentation: https://xgboost.readthedocs.io/en/stable/R-package/index.html
- James et al., *An Introduction to Statistical Learning*: https://www.statlearning.com/
