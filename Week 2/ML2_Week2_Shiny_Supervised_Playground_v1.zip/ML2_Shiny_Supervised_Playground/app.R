# Week 2 interactive supervised-ML workshop
# Launch: shiny::runApp("path/to/ML2_Shiny_Supervised_Playground")
# Week 1 panel is synthetic. Educational app, not empirical findings for Indonesia.
if (!requireNamespace('shiny', quietly = TRUE) ||
    !requireNamespace('ggplot2', quietly = TRUE) ||
    !requireNamespace('glmnet', quietly = TRUE) ||
    !requireNamespace('readxl', quietly = TRUE)) {
  stop('Install the core packages: install.packages(c("shiny","ggplot2","glmnet","readxl"))')
}
suppressPackageStartupMessages(library(shiny))
suppressPackageStartupMessages(library(ggplot2))
source('helpers.R', local = TRUE)

model_colors <- c('True function'='#141F35','Linear OLS'='#4A78A8',
                  'Polynomial OLS'='#AF802B','Polynomial Ridge'='#2B8260',
                  'Polynomial LASSO'='#B64F57',
                  'Decision Tree'='#7464AE','Random Forest'='#1991A5',
                  'XGBoost'='#BF6B31','SVR (RBF)'='#975E98')

app_ui <- navbarPage(
  title = 'Supervised ML Playground', id = 'nav',
  header = tags$head(tags$style(HTML('
  body{background:#f7f9fc;} .navbar{background:#163852!important;border:0;}
  .navbar-default .navbar-brand,.navbar-default .navbar-nav>li>a{color:#f1f5f9!important;}
  .navbar-default .navbar-nav>.active>a{background:#2e6688!important;color:white!important;}
  .well{background:#fff;border:1px solid #dce3eb;border-radius:12px;}
  .note{border-left:4px solid #277d67;padding:9px 13px;background:#edf7f2;margin:11px 0;}
  .warning-note{border-left:4px solid #bb8430;padding:9px 13px;background:#fff7e9;margin:11px 0;}
  .title-text{color:#173650;font-weight:700;} .help-small{color:#627386;font-size:12px;}
  .plot-panel{background:white;padding:11px;border:1px solid #e1e9f1;border-radius:10px;margin-bottom:12px;}
  .btn-primary{background:#286d72;border-color:#286d72;}
  table{font-size:13px;} .table>thead>tr>th{background:#e9f1f6;}
  '))),
  tabPanel('1. Linear vs Nonlinear',
    fluidRow(
      column(3,wellPanel(
        h4('Generate a Data Generating Process',class='title-text'),
        selectInput('dgp','True underlying relationship',
          choices=c('Linear'='linear','Quadratic (U-shaped)'='quadratic',
                    'Sinusoidal'='sine','Threshold / jump'='threshold'),
          selected='quadratic'),
        sliderInput('n_train','Number of training observations',30,180,55,step=5),
        sliderInput('noise','Outcome noise (SD)',0.1,1.6,0.7,step=0.1),
        numericInput('seed','Random seed',123,min=1,max=999999),
        actionButton('regen','Generate / reset data',class='btn-primary',width='100%'),
        hr(),h4('Fit and regularization'),
        sliderInput('degree','Polynomial degree',min=1,max=10,value=5,step=1),
        sliderInput('log_lambda','log10(lambda)',min=-3.5,max=1,value=-1.1,step=.1),
        textOutput('lambda_label'),
        div(class='note',HTML('<b>Key distinction:</b> Polynomial features make the model flexible. Ridge and LASSO control coefficient size. OLS can also fit nonlinear curves after feature expansion.'))
      )),
      column(9,
        h3('How well does each model fit the same observations?',class='title-text'),
        div(class='plot-panel',plotOutput('sim_fitted',height='430px')),
        div(class='note','The black curve is known only because these data are simulated. All fitted models use training observations only.'),
        h4('Training and validation performance'),tableOutput('sim_table'),
        actionButton('sim_test_button','Reveal final test performance',class='btn-primary'),
        downloadButton('sim_download','Download simulated predictions CSV'),
        div(class='warning-note','Use validation error to explore model settings. Once test results are revealed, further tuning to that test set would compromise a true blind evaluation.')
      )
    )
  ),
  tabPanel('2. Loss, Penalty & Shrinkage',
    fluidRow(column(12,
      h3('How does regularization change the optimization objective?',class='title-text'),
      p('The controls on Tab 1 set the data, polynomial degree, and lambda. All models are fit on the same training sample.'),
      fluidRow(
        column(6,div(class='plot-panel',h4('Coefficient paths'),plotOutput('paths_plot',height='340px'))),
        column(6,div(class='plot-panel',h4('Validation error vs penalty'),plotOutput('validation_plot',height='340px')))
      ),
      h4('Training loss and penalty at the selected lambda'),tableOutput('objective_table'),
      div(class='note',HTML('<b>OLS:</b> minimize half-MSE. <b>Ridge:</b> half-MSE + lambda/2 × sum(standardized slopes squared). <b>LASSO:</b> half-MSE + lambda × sum(abs(standardized slopes)). The intercept is unpenalized.')),
      div(class='warning-note',HTML('Do not compare different models by the numerical value of their <i>penalized objective</i>. Compare common predictive losses (MAE/RMSE) on validation or test data. A penalty may increase training loss while improving validation accuracy.'))
    ))
  ),
  tabPanel('3. Advanced ML Explorer',
    fluidRow(
      column(3,wellPanel(
        h4('Optional nonlinear algorithms',class='title-text'),
        checkboxGroupInput('advanced_choice','Models to fit',
           choices=c('Decision Tree','Random Forest','XGBoost','SVR (RBF)'),
           selected=c('Decision Tree','Random Forest')),
        sliderInput('tree_depth','Maximum tree depth',1,8,4,step=1),
        sliderInput('trees','Random forest trees',20,300,120,step=20),
        sliderInput('min_node','Forest minimum node size',2,15,5,step=1),
        sliderInput('rounds','XGBoost boosting rounds',10,180,65,step=5),
        sliderInput('eta','XGBoost learning rate',0.03,0.4,0.12,step=.01),
        sliderInput('svr_cost','SVR cost (C)',0.1,20,3,step=.1),
        sliderInput('svr_gamma','SVR RBF gamma',0.05,3,0.6,step=.05),
        actionButton('train_advanced','Fit selected algorithms',class='btn-primary',width='100%'),
        div(class='help-small','Model fitting occurs only when you press the button. Optional packages are reported if missing.')
      )),
      column(9,
        h3('Do flexible methods learn the nonlinear structure?',class='title-text'),
        div(class='plot-panel',plotOutput('advanced_plot',height='400px')),
        h4('Model diagnostics (same synthetic validation observations)'),tableOutput('advanced_metrics'),
        verbatimTextOutput('advanced_status'),
        div(class='note','A decision tree produces step-like fitted values. Random forests average many trees; XGBoost iteratively builds trees; RBF-SVR uses a nonlinear kernel. More flexibility does not guarantee lower test error.'),
        div(class='warning-note','Advanced-model hyperparameters are set manually for this teaching laboratory. Select them using validation errors, not by repeatedly optimizing the revealed test score.')
      )
    )
  ),
  tabPanel('4. Week 1 Economic Panel',
    fluidRow(
      column(3,wellPanel(
        h4('Same dataset and split as Week 1',class='title-text'),
        p('120 fictional regions; 2021–2024 training outcomes; 2025 final holdout.'),
        fileInput('panel_upload','Optional: replace bundled Week 1 workbook',accept='.xlsx'),
        checkboxGroupInput('econ_advanced','Additional models (optional)',
           choices=c('Decision Tree','Random Forest','XGBoost','SVR (RBF)'),selected=character()),
        actionButton('run_econ','Fit & validate economic models',class='btn-primary',width='100%'),
        hr(),actionButton('eval_econ','Reveal final 2025 test',width='100%'),
        hr(),downloadButton('econ_csv','Download predictions CSV',width='100%'),
        downloadButton('econ_xlsx','Download results XLSX',width='100%'),
        div(class='help-small','The Excel download needs the optional openxlsx package.'),
        div(class='warning-note','The supplied panel contains synthetic data and is not a real Indonesian regional dataset. Hyperparameters are selected on 2022–2024 validation folds, not on 2025 outcomes.')
      )),
      column(9,
        h3('Fair economic prediction comparison',class='title-text'),
        p('Re-estimate the exact six-variable Week 1 OLS; fit Ridge and LASSO on the same variables; optionally compare advanced nonlinear models.'),
        verbatimTextOutput('econ_status'),
        h4('Expanding-window validation: 2022, 2023, 2024'),
        div(class='plot-panel',plotOutput('econ_cv_plot',height='330px')),
        tableOutput('econ_cv_table'),
        h4('2025 final holdout results'),
        tableOutput('econ_test_table'),
        div(class='plot-panel',plotOutput('econ_actual_plot',height='370px')),
        div(class='note','Benchmark audit: Multiple OLS Week 1 should reproduce MAE ≈ 1.523 and RMSE ≈ 1.977. Test error is measured in percentage points. Error = predicted minus observed.')
      )
    )
  ),
  tabPanel('Instructor Notes',
    fluidRow(column(10,offset=1,
      h2('Teaching sequence',class='title-text'),
      tags$ol(
        tags$li('Start with linear DGP: linear OLS is a sensible benchmark; compare models on validation.'),
        tags$li('Change to quadratic / sine / threshold while keeping sample size and noise fixed. Identify underfitting.'),
        tags$li('Increase polynomial degree: note training-versus-validation divergence; introduce Ridge and LASSO shrinkage.'),
        tags$li('Explore Tree, Forest, XGBoost and RBF-SVR. Compare fits on the same synthetic data.'),
        tags$li('Apply the method comparison to the identical synthetic Week 1 poverty panel. Historical validation is mandatory.'),
        tags$li('Reveal final test metrics only after discussing likely model performance.')
      ),
      h3('Conceptual safeguards'),
      div(class='note','OLS is itself supervised learning. Ridge/LASSO with only X are linear in X; adding polynomial features gives them nonlinear flexibility. Trees, ensembles and RBF-SVR can learn nonlinear patterns without manually selecting polynomial degrees.'),
      div(class='warning-note','Training a flexible model can reduce training loss, but its validation/test accuracy may be worse. Repeatedly adjusting a model based on revealed test scores removes the independence of the test evaluation.'),
      h3('Data and output'),p('The supplied Excel workbook is the same synthetic panel used in Week 1. Results can be exported from Tab 4 as CSV and XLSX.'),
      h3('Software'),p('Core: shiny, ggplot2, glmnet, readxl. Optional: rpart, ranger, xgboost, e1071, openxlsx.'),
      h3('References'),
      tags$p(tags$a(href='https://glmnet.stanford.edu/articles/glmnet.html',target='_blank','glmnet documentation'),
             ' | ',tags$a(href='https://www.statlearning.com/',target='_blank','Introduction to Statistical Learning'))
    ))
  )
)

app_server <- function(input, output, session) {
  sim <- eventReactive(input$regen, {
    make_simulation(input$dgp, input$n_train, input$noise, input$seed)
  }, ignoreNULL = FALSE)
  lambda <- reactive(10^input$log_lambda)
  core <- reactive({fit_sim_core(sim(), as.integer(input$degree), lambda())})
  sim_test_gate <- reactiveVal(FALSE)
  adv_results <- reactiveVal(NULL)
  observeEvent(list(input$regen,input$degree,input$log_lambda), {
    sim_test_gate(FALSE);adv_results(NULL)
  },ignoreInit=TRUE)
  observeEvent(list(input$advanced_choice,input$tree_depth,input$trees,input$rounds,
                    input$eta,input$svr_cost,input$svr_gamma,input$min_node),{
    adv_results(NULL)
  },ignoreInit=TRUE)
  observeEvent(input$sim_test_button,{sim_test_gate(TRUE)})
  output$lambda_label <- renderText(sprintf('Current lambda = %.5f',lambda()))

  output$sim_fitted <- renderPlot({
    c<-core();s<-sim();g<-s$grid
    combined<-data.frame(x=g$x,y=true_function(g$x,s$dgp),Model='True function')
    for (nm in names(c$pred_grid))
      combined<-rbind(combined,data.frame(x=g$x,y=c$pred_grid[[nm]],Model=nm))
    plot<-ggplot(combined,aes(x,y,color=Model))+
      geom_line(linewidth=1.15)+
      geom_point(data=s$train,aes(x=x,y=y),inherit.aes=FALSE,
                 color='#222F45',alpha=.55,size=1.6)+
      geom_point(data=s$val,aes(x=x,y=y),inherit.aes=FALSE,
                 color='#8E9AA8',alpha=.25,size=1.1)+
      scale_color_manual(values=model_colors)+
      labs(title='Fitted curves on training data',
           subtitle='Dark dots = training, pale dots = validation; black = true DGP',
           x='Predictor X',y='Outcome Y',color=NULL)+theme_minimal(base_size=12)+
      theme(legend.position='bottom')
    if (sim_test_gate())
      plot<-plot+geom_point(data=s$test,aes(x=x,y=y),inherit.aes=FALSE,
                           color='#DD8E35',alpha=.22,size=1)
    plot
  })
  output$sim_table <- renderTable({
    c<-core(); ans<-c$metrics
    if (sim_test_gate()) {
      p<-c$pred_test(); dd<-do.call(rbind,lapply(names(p),function(nm)
        cbind(data.frame(Split='Test',Model=nm),score_predictions(c$data$test$y,p[[nm]]))))
      ans<-rbind(ans,dd)
    }
    ans[,c('Split','Model','n','MAE','RMSE','Mean_error')]
  },digits=3,striped=TRUE,rownames=FALSE)
  output$sim_download <- downloadHandler(
    filename=function() 'Week2_simulated_prediction_comparison.csv',
    content=function(file) {
      c<-core();s<-sim()
      combine<-function(dd,pr,split){
        data.frame(Split=split,X=dd$x,Actual=dd$y,pr,check.names=FALSE)
      }
      result<-rbind(combine(s$train,c$pred_train,'Training'),
                    combine(s$val,c$pred_val,'Validation'))
      if(sim_test_gate()) result<-rbind(result,
            combine(s$test,c$pred_test(),'Test'))
      utils::write.csv(result,file,row.names=FALSE)
    })
  output$paths_plot <- renderPlot({
    c<-core(); ggplot(c$paths,aes(lambda,coefficient,color=term))+
      geom_line(linewidth=.7)+geom_vline(xintercept=lambda(),linetype='dashed')+
      facet_wrap(~Model,ncol=1,scales='free_y')+scale_x_log10()+
      labs(x='Penalty λ (log scale)',y='Coefficient on polynomial basis',color='Term')+
      theme_minimal(base_size=11)+theme(legend.position='bottom')
  })
  output$validation_plot <- renderPlot({
    cc<-core()$paths
    d<-unique(cc[,c('Model','lambda','validation_RMSE')])
    ggplot(d,aes(lambda,validation_RMSE,color=Model))+
      geom_line(linewidth=1)+geom_vline(xintercept=lambda(),linetype='dashed')+
      scale_x_log10()+labs(x='Penalty λ (log scale)',y='Validation RMSE',color=NULL)+
      theme_minimal(base_size=11)+theme(legend.position='bottom')
  })
  output$objective_table <- renderTable({core()$objective},digits=4,striped=TRUE,rownames=FALSE)

  advanced_config <- reactive(list(tree_depth=input$tree_depth,trees=input$trees,
     rounds=input$rounds,eta=input$eta,svr_cost=input$svr_cost,
     svr_gamma=input$svr_gamma,min_node=input$min_node,
     seed=as.integer(input$seed)))
  observeEvent(input$train_advanced, {
    c<-core(); s<-sim();config<-advanced_config()
    chosen<-input$advanced_choice
    if (!length(chosen)) {adv_results(list(pred=list(),metrics=NULL,
                                         failures='Select at least one model.'));return()}
    preds<-list();scores<-list();failures<-character()
    withProgress(message='Fitting advanced models...',value=0,{
      for (j in seq_along(chosen)) {
        nm<-chosen[j]
        result<-tryCatch({fn<-fit_advanced(nm,matrix(s$train$x,ncol=1),
                                s$train$y,config)
             list(training=fn(matrix(s$train$x,ncol=1)),
                  validation=fn(matrix(s$val$x,ncol=1)),
                  grid=fn(matrix(s$grid$x,ncol=1)),
                  testing=fn(matrix(s$test$x,ncol=1)))},error=function(e)e)
        if (inherits(result,'error')) failures<-c(failures,paste(nm,':',conditionMessage(result)))
        else {
          preds[[nm]]<-result
          scores[[length(scores)+1L]]<-rbind(
            cbind(data.frame(Split='Training',Model=nm),
                  score_predictions(s$train$y,result$training)),
            cbind(data.frame(Split='Validation',Model=nm),
                  score_predictions(s$val$y,result$validation)))
        }
        incProgress(1/length(chosen))
      }
    })
    adv_results(list(pred=preds,metrics=if(length(scores))do.call(rbind,scores) else NULL,
                     failures=failures))
    sim_test_gate(FALSE)
  })
  output$advanced_plot <- renderPlot({
    res<-adv_results();s<-sim();c<-core();g<-s$grid
    d<-data.frame(x=g$x,y=true_function(g$x,s$dgp),Model='True function')
    d<-rbind(d,data.frame(x=g$x,y=c$pred_grid[['Polynomial OLS']],Model='Polynomial OLS'))
    if (!is.null(res)) for(nm in names(res$pred))
      d<-rbind(d,data.frame(x=g$x,y=res$pred[[nm]]$grid,Model=nm))
    ggplot(d,aes(x,y,color=Model))+geom_line(linewidth=1.15)+
      geom_point(data=s$train,aes(x,y),inherit.aes=FALSE,alpha=.35,size=1.3)+
      scale_color_manual(values=model_colors)+
      labs(title='Nonlinear fitted curves compared on common training observations',
           x='Predictor X',y='Outcome Y',color=NULL)+
      theme_minimal(base_size=12)+theme(legend.position='bottom')
  })
  output$advanced_metrics <- renderTable({
    res<-adv_results()
    if(is.null(res) || is.null(res$metrics)) return(NULL)
    tbl<-res$metrics
    if (sim_test_gate()) {
      s<-sim()
      for (nm in names(res$pred)) tbl<-rbind(tbl,cbind(data.frame(Split='Test',Model=nm),
             score_predictions(s$test$y,res$pred[[nm]]$testing)))
    }
    tbl[,c('Split','Model','RMSE','MAE','Mean_error')]
  },digits=3,striped=TRUE,rownames=FALSE)
  output$advanced_status <- renderText({
    res<-adv_results()
    if(is.null(res))return('Choose algorithms, then press "Fit selected algorithms".')
    x<-if(length(res$pred))paste('Fitted:',paste(names(res$pred),collapse=', ')) else 'No advanced models fitted.'
    paste(c(x,res$failures),collapse='\n')
  })

  economic_result<-reactiveVal(NULL)
  economic_gate<-reactiveVal(FALSE)
  observeEvent(input$run_econ, {
    economic_gate(FALSE)
    path <- if (is.null(input$panel_upload)) {
      file.path(getwd(), 'ML1_Economic_Panel_Synthetic.xlsx')
    } else {
      input$panel_upload$datapath
    }
    config<-advanced_config()
    chosen<-input$econ_advanced
    tryCatch(withProgress(message='Building time-aware model comparison...',value=0,{
      missing<-chosen[!vapply(chosen,function(nm)
        requireNamespace(model_package(nm),quietly=TRUE),logical(1))]
      if(length(missing)) stop('Missing optional packages for: ',paste(missing,collapse=', '),
        '. Install the required packages or deselect the models.')
      p<-read_week1_panel(path)
      incProgress(.22,detail='Validated Week 1 data and lagged indicators')
      out<-fit_week1_models(p,config,extra=chosen)
      incProgress(.75,detail='Finished historical validation and model fits')
      economic_result(list(result=out,error=NULL))
    }),error=function(e) economic_result(list(result=NULL,error=conditionMessage(e))))
  })
  observeEvent(input$eval_econ,{
    if(!is.null(economic_result()) && !is.null(economic_result()$result))
      economic_gate(TRUE)
  })
  output$econ_status <- renderText({
    obj<-economic_result()
    if(is.null(obj)) return('Select models and click "Fit & validate economic models".')
    if(!is.null(obj$error))return(paste('Unable to fit models:',obj$error))
    a<-obj$result
    paste('Models fit:',paste(a$complete_models,collapse=', '),
          '\nOLS Week 1 parity:',if(a$baseline_parity)'PASS' else 'CHECK THE DATASET',
          '\nTraining: 2021–2024 (n=480); validation targets: 2022, 2023, 2024.',
          '\nTest 2025:',if(economic_gate())'RESULTS REVEALED' else 'HIDDEN until final evaluation.')
  })
  output$econ_cv_plot <- renderPlot({
    ob<-economic_result();req(ob,ob$result)
    d<-ob$result$cv_curve
    curve<-d[!is.na(d$lambda)&d$Model %in% c('Ridge','LASSO'),]
    ols_ref <- ob$result$chosen
    ols_ref <- ols_ref$CV_RMSE[ols_ref$Model=='Multiple OLS']
    g <- ggplot(curve,aes(lambda,CV_RMSE,color=Model))+
      geom_line(linewidth=1.1)+scale_x_log10()
    if(length(ols_ref)) g <- g+geom_hline(yintercept=ols_ref[1],
                 linetype='dashed',color='#6B7280')
    g+
      labs(title='Pooled historical validation RMSE',
           subtitle='Validation in 2022, 2023, 2024; no 2025 outcomes used',
           x='Penalty λ (log scale)',y='Validation RMSE (poverty percentage points)')+
      theme_minimal(base_size=11)+theme(legend.position='bottom')
  })
  output$econ_cv_table <- renderTable({
    ob<-economic_result();req(ob,ob$result)
    d<-ob$result$chosen
    d[,c('Model','lambda','CV_RMSE','CV_MAE')]
  },digits=4,striped=TRUE,rownames=FALSE)
  output$econ_test_table <- renderTable({
    ob<-economic_result();req(ob,ob$result,economic_gate())
    ob$result$test_metrics[,c('Model','n','MAE','RMSE','Mean_error')]
  },digits=3,striped=TRUE,rownames=FALSE)
  output$econ_actual_plot <- renderPlot({
    ob<-economic_result();req(ob,ob$result,economic_gate())
    df<-ob$result$pred
    names_list<-ob$result$complete_models
    d<-do.call(rbind,lapply(names_list,function(nm) {
      key<-paste0('Pred_',gsub('[^A-Za-z0-9]+','_',nm))
      data.frame(Observed=df$Observed,Predicted=df[[key]],Model=nm)
    }))
    ggplot(d,aes(Observed,Predicted))+geom_point(color='#277d67',alpha=.6,size=1.8)+
      geom_abline(slope=1,intercept=0,linetype='dashed',color='#b18335')+
      facet_wrap(~Model,scales='fixed',ncol=3)+coord_equal()+
      labs(title='2025 actual versus predicted on the identical 120 regions',
           subtitle='Dashed 45° line indicates a perfect prediction',
           x='Observed poverty (%)',y='Predicted poverty (%)')+
      theme_minimal(base_size=11)
  })
  output$econ_csv<-downloadHandler(
    filename=function()'Week2_2025_predictions.csv',
    content=function(file){ob<-economic_result();req(ob,ob$result,economic_gate())
      utils::write.csv(ob$result$pred,file,row.names=FALSE)}
  )
  output$econ_xlsx<-downloadHandler(
    filename=function()'Week2_supervised_model_comparison.xlsx',
    content=function(file){
      ob<-economic_result();req(ob,ob$result,economic_gate())
      if(!requireNamespace('openxlsx',quietly=TRUE))
        stop('Install openxlsx with install.packages("openxlsx") to export Excel.')
      a<-ob$result;wb<-openxlsx::createWorkbook()
      sheets<-list('Training_Metrics'=a$train_metrics,'Test_2025'=a$test_metrics,
                   'Validation_Curves'=a$cv_curve,'Selected_Hyperparams'=a$chosen,
                   'All_Fold_Errors'=a$fold_metrics,'Predictions_2025'=a$pred)
      for(nm in names(sheets)){
        openxlsx::addWorksheet(wb,nm)
        openxlsx::writeDataTable(wb,nm,sheets[[nm]],tableStyle='TableStyleMedium2')
        openxlsx::freezePane(wb,nm,firstRow=TRUE)
        openxlsx::setColWidths(wb,nm,cols=seq_len(ncol(sheets[[nm]])),widths=19)
      }
      openxlsx::saveWorkbook(wb,file,overwrite=TRUE)
    }
  )
}
shinyApp(ui=app_ui,server=app_server)
