# Run this once. 'openxlsx' is optional but enables Excel export from Module 5.
packages <- c('shiny', 'ggplot2', 'glmnet', 'openxlsx')
missing <- packages[!vapply(packages, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing) > 0) install.packages(missing)
cat('Installed / verified:', paste(packages, collapse = ', '), '\n')
