# Economic Regression Lab v1.3.0 | complete computational smoke tests
# Run this script from the extracted folder, then launch app.R.
stopifnot(file.exists('app.R'))
parse(file = 'app.R')
cat('[1/9] R syntax parsed.\n')
source('app.R', local = TRUE, echo = FALSE, print.eval = FALSE)
cat('[2/9] Complete Shiny source loaded.\n')

set.seed(101)
x <- seq(-2, 2, length.out = 35)
y <- true_nonlinear(x) + rnorm(35, sd = 0.8)
fit <- fit_orthogonal_poly(x, y, 10)
stopifnot(all(is.finite(predict_orthogonal_poly(fit, c(-1, 0.8)))))
cat('[3/9] Polynomial QR helper works.\n')

simple <- make_simple_data(45, 1, 123, 0)
for (method in c('ridge', 'lasso')) {
  bb <- fit_one_x_penalty(simple$x, simple$y, lambda = 0, method = method)
  stopifnot(max(abs(unname(bb) - unname(coef(lm(y ~ x, simple))))) < 1e-7)
}
cat('[4/9] One-X ridge/lasso reduces to OLS at lambda=0.\n')

s1 <- make_collinearity_data(160, rho = 0.04, sigma = 1.3,
                             pattern = 'linear', seed = 123, refresh = 0)
s2 <- make_collinearity_data(160, rho = 0.97, sigma = 1.3,
                             pattern = 'nonlinear', seed = 123, refresh = 0)
X1 <- col_design(s1$train, expanded = FALSE)
X2 <- col_design(s2$train, expanded = TRUE)
stopifnot(ncol(X1) == 6, ncol(X2) == 13, nrow(s2$test) == 250,
          cor(s2$train$X1, s2$train$X2) > 0.90,
          all(is.finite(col_ols(X2, s2$train$Y))))
cat('[5/9] Linear and nonlinear synthetic data; full-rank OLS.\n')

vif_low <- col_vif(X1, 'X1')
vif_high <- col_vif(col_design(s2$train, FALSE), 'X1')
stopifnot(is.finite(vif_low), is.finite(vif_high), vif_high > vif_low)
if_table <- col_ols_diagnostics(X2, s2$train$Y, 'Expanded OLS')
stopifnot(nrow(if_table) == 4, all(is.finite(if_table$Std_Error)),
          all(is.finite(if_table$VIF)))
cat('[6/9] VIF and conventional OLS standard-error diagnostics.\n')

set.seed(892)
folds <- sample(rep(1:5, length.out = nrow(X2)))
cv_r <- glmnet::cv.glmnet(X2, s2$train$Y, alpha = 0, foldid = folds, nlambda = 45)
cv_l <- glmnet::cv.glmnet(X2, s2$train$Y, alpha = 1, foldid = folds, nlambda = 45)
Xtest <- col_design(s2$test, TRUE)
pr <- as.numeric(predict(cv_r, newx = Xtest, s = 'lambda.min'))
pl <- as.numeric(predict(cv_l, newx = Xtest, s = 'lambda.min'))
stopifnot(length(pr) == nrow(s2$test), length(pl) == nrow(s2$test),
          all(is.finite(pr)), all(is.finite(pl)))
cat('[7/9] Ridge/LASSO cross-validation and test prediction.\n')

shift <- make_collinearity_data(160, rho = 0.97, sigma = 1.3,
                                pattern = 'linear', seed = 123,
                                refresh = 0, shift = TRUE)
stopifnot(abs(cor(shift$test$X1, shift$test$X2)) < 0.40,
          cor(shift$train$X1, shift$train$X2) > 0.90)
cat('[8/9] Optional predictor-correlation test shift.\n')

mock_fits <- list(data = s2, predictions = list('OLS (raw X)' = pr,
                       'Ridge (expanded)' = pl))
mock_export <- col_export_predictions(mock_fits)
stopifnot(nrow(mock_export) == 250, ncol(mock_export) == 6,
          all(is.finite(mock_export[, -1])))
cat('[9/9] Exportable predictions and signed errors.\n')
cat('\nAll computational smoke tests passed. Open app.R and click Run App.\n')
cat('Note: automated tests do not test every interactive plot or browser rendering.\n')
