# Economic Regression Lab v1.3.0 FULL

**Introduction to Machine Learning Using R | Undergraduate Economics | Weeks 1–2**

A single, stand-alone R Shiny app with five interactive classroom modules. All data are **fully synthetic** and generated in memory. No external Excel workbook or API is required for the app.

## Quick start

1. Extract the entire ZIP to a folder, such as `F:/MACHINE LEARNING WORKSHOP/Economic_Regression_Lab_v1_3_0_FULL`.
2. In RStudio, open the extracted folder as your working directory.
3. Install packages once:

   ```r
   source('install_packages.R')
   ```

4. Test computational helpers:

   ```r
   source('smoke_test.R')
   ```

5. Launch:

   ```r
   shiny::runApp('.', launch.browser = TRUE)
   ```

Alternatively, open `app.R` and click **Run App**.

## Complete module inventory

| Module | Interaction | Main learning objective |
|---|---|---|
| 1. Fit the OLS Line | Move intercept a and slope b, toggle true line and one-X Ridge/LASSO | OLS finds the joint intercept/slope that minimizes squared residuals |
| 2. OLS vs Ridge and LASSO | Change number of observations, predictor correlation, noise, lambda selection | L1/L2 penalties, shrinkage, training vs test RMSE, cross-validation |
| 3. Complexity and Overfitting | Increase polynomial degree up to 12 | Training fit can improve while unseen-data error worsens |
| 4. Bias–Variance Simulation | Repeated training samples, fixed evaluation point x0 | Separate squared prediction bias, prediction variance and irreducible noise |
| 5. Collinearity: Linear / Nonlinear | Select linear/nonlinear truth, rho, sample size, noise, test-shift and bootstrap | Multicollinearity versus nonlinearity; OLS coefficient SE/VIF versus prediction; fair OLS/Ridge/LASSO comparison |

## Expanded Module 5: detailed outputs

- **Predictor dependence:** X1–X2 scatter, full raw/expanded-feature correlation heatmap and condition number.
- **Coefficient inference:** estimates, conventional homoskedastic standard errors, and VIF for X1–X4 under 6-predictor and 13-feature OLS designs. These **do not** establish causal effects.
- **Prediction:** conditional fitted curves, training and held-out test RMSE, test MAE, actual-versus-predicted plots, coefficient comparisons and five-fold CV curves.
- **Stability:** optional bootstrap plots of one coefficient versus prediction at a fixed input vector. Bootstrap reuses originally selected lambda to isolate sample variation.
- **Distribution shift:** option to change X1–X2 and X3–X4 correlation in the **test sample** while retaining the training process.
- **Exports:** model metrics CSV, 250 test predictions CSV including signed errors, and (when `openxlsx` is installed) Excel workbook with seven sheets: Readme, Model_Performance, Test_Predictions, OLS_Inference, OLS_Coefficients, Raw_Predictor_Correlation, CV_Lambda.

### Fair estimation comparisons

Four models are shown:

1. **OLS (raw X)** uses 6 original predictors.
2. **OLS (expanded)** uses 13 identical raw, squared and interaction features.
3. **Ridge (expanded)** uses those exact same 13 features.
4. **LASSO (expanded)** uses those exact same 13 features.

For the effect of regularization, compare models **2, 3, and 4**; model 1 additionally changes feature specification. Each experiment uses independent training and test data from the same simulation setup, except when the explicit distribution-shift option is enabled. Lambda is tuned **within the training set** using identical five-fold assignments for Ridge and LASSO.

The data-generating outcome is either linear in original predictors or contains quadratic terms/interactions. Both cases can have correlated predictors. Using polynomial features makes a model nonlinear in *inputs*, while its coefficients remain linear.

### Interpretation cautions

- **OLS is also a supervised-learning algorithm**, since it uses labeled outcomes.
- Multicollinearity may inflate uncertainty about *individual OLS slopes*; combined predictions need not become inaccurate in the same way.
- High correlation can also impact prediction under small samples or changing train/test relationships.
- Ridge can stabilize estimates by shrinking slopes; LASSO may select a subset, and this selection may be unstable under strong predictor correlation.
- Repeatedly choosing model settings based on displayed test RMSE would be test-set reuse. This app is an instructional simulation, not an unbiased model-selection exercise after repeated interaction.
- Statistical inference, forecasting, and causal inference answer different questions.
- Simulated results are not evidence about poverty, labor markets, or Indonesian regions.

## Troubleshooting

- **`there is no package called 'glmnet'`**: run `install.packages('glmnet')`.
- **`qr.coef` namespace error**: current script uses `base::qr.coef`, not the incorrect `stats::qr.coef`.
- **Large waiting time when moving sliders**: CV re-fits on changes to the simulation. Lower sample size, wait for models to update; bootstrap is only run after pressing its button.
- **Bootstrap blank**: click **Run coefficient stability demo**; rerun after changing settings.
- **Missing Excel button**: install `openxlsx` then restart the app. CSV exports work without it.

## Runtime verification

The complete source and supporting checks can be inspected in the package. This build was statically audited, but was **not** run inside a local R Shiny runtime in the creation environment. Run `source('smoke_test.R')` and visually inspect the five tabs on the target computer before a class.
