# Classroom Guide | 5 Modules

## Suggested instructor demonstrations (60–75 min)

**1. OLS objective, 8 minutes.** Set intercept a=0, slope b=0, show residual segments and SSE. Move sliders toward the red-star optimum. Press 'Move sliders to OLS optimum'. Ask why this line minimizes *training* SSE.

**2. Regularization, 12 minutes.** In Tab 2, compare models with 12 predictors. Start rho=0, then rho=0.9. Show selected lambda and coefficient shrinkage. Emphasize cross-validation (CV) is not the same as using the final test set to choose lambda.

**3. Complexity, 8 minutes.** Set n=35, noise=0.8; compare polynomial degrees 1, 3, 8 and 12. Observe train RMSE and test RMSE. Avoid selecting degree based on the final test set in a real forecasting task.

**4. Bias–variance, 8 minutes.** Hold X fixed across repeated samples; vary x0 and noise. Explain that the plotted bias is *prediction bias at x0*, not causal or coefficient bias.

**5. Multicollinearity linear case, 12 minutes.** Select linear relationship, rho=0.05, inspect OLS estimates/SE/VIF. Increase rho=0.95–0.995. Compare OLS coefficient SE with test RMSE. Explain why prediction can remain good even when individual slopes are imprecise. Do not claim every sample behaves identically.

**6. Nonlinear response, 12 minutes.** Switch to nonlinear relationship, keep same rho and sample size, inspect curvature. Compare OLS (raw X) with OLS (expanded). For a *regularization-only* comparison, use OLS (expanded) vs Ridge/LASSO (expanded), since all three use the same 13 features.

**7. Stability and exports, 10 minutes.** Run bootstrap on Tab 5. Compare SD of coefficient X1 vs SD of a fixed-input prediction. Optionally toggle changing test correlation and discuss covariate shift. Download Excel results and let students identify the lowest test RMSE **for this simulation only**.

## Student reflection (3 straightforward questions)

1. When rho rises, what happens to VIF and to the uncertainty around the OLS coefficients? How does test RMSE behave?
2. In a nonlinear data-generating process, does expanding the features improve model specification? How is that different from penalizing coefficients?
3. When OLS, Ridge and LASSO use identical features, which has the lowest held-out RMSE in the selected simulation? Would this necessarily hold for every dataset?
