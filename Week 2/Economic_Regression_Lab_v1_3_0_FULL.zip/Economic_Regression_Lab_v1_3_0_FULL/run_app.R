# Working directory must be the folder containing app.R.
stopifnot(file.exists('app.R'))
shiny::runApp('.', launch.browser = TRUE)
