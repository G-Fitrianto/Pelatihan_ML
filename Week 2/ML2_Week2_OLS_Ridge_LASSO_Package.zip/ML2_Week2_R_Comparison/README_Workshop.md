# Week 2 | Prediction in Economic Analysis: Supervised Machine Learning

## Purpose

This package extends **Week 1: Introduction to Machine Learning for Economic Analysis**. Students compare unpenalized OLS with Ridge and LASSO on *exactly the same synthetic regional poverty prediction task*. This exercise explores squared-error loss, penalties, lambda selection, coefficient shrinkage, and genuinely future-period predictions.

**The regions and values are entirely synthetic.** No result should be interpreted as a finding about Indonesia.

## Files

- `ML2_Supervised_OLS_Ridge_LASSO.R`: full analysis, chronological validation, graphics, table generation and Excel export.
- `ML2_Classroom_Quickstart.R`: guided classroom walkthrough using objects created by the main script.
- `ML1_Economic_Panel_Synthetic.xlsx`: unchanged original Week 1 workbook (720 rows, 120 fictitious regions, 2020–2025).
- `Week1_reference_performance.csv`: metrics from the original Week 1 R results. The new script checks that all six OLS/benchmark metrics match at a tolerance of 1e-6.

## Setup

1. Unzip these files into a single directory, such as `F:/MACHINE LEARNING WORKSHOP/Week 2/`.
2. In RStudio, use **Session → Set Working Directory → Choose Directory** to select the extracted folder, or `setwd("F:/MACHINE LEARNING WORKSHOP/Week 2")`.
3. Install the packages once:

```r
install.packages(c("readxl", "dplyr", "ggplot2", "glmnet", "openxlsx", "stargazer"))
```

4. Run the main script:

```r
source("ML2_Supervised_OLS_Ridge_LASSO.R", echo = FALSE)
```

5. Explore the results, which are written to the new `ML2_outputs/` directory. The script does not overwrite Week 1 outputs. For an interactive lesson afterwards, run `source("ML2_Classroom_Quickstart.R")` in the same R session.

The script uses `getwd()` by default, not a fixed drive path. If the files are stored in different directories, edit the `input_file`, `week1_reference_file`, and `out_dir` lines near the top.

## Fair-comparison protocol

| Element | Week 1 OLS | Week 2 Ridge / LASSO |
|---|---|---|
| Outcome | 2021–2024 training / 2025 test | The same |
| Sample | 480 train / 120 test | The same |
| Predictors | The same six 1-year-lagged indicators | The same six |
| Missing predictor handling | Median fitted on 2021–2024 | Same for final fit; **within-fold train-only medians** during tuning |
| Model formula | Linear, with intercept | Linear, with intercept, penalties L2 / L1 |
| Final test | All 120 regions in 2025 | The identical 120 regions |
| Comparison | Out-of-sample RMSE, MAE, mean error | Identical metrics |

Ridge and LASSO additionally select lambda **without using 2025 outcomes**. The validation folds are: train 2021 and validate 2022, train 2021–2022 and validate 2023, train 2021–2023 and validate 2024. The loss optimized in tuning is the *pooled validation MSE*, not test RMSE. The selected models are then refitted on 2021–2024 and evaluated once on 2025.

Since we already inspected 2025 results during Week 1, we should be careful not to read the exercise as a wholly prospective blind experiment. Method choice and lambda are nonetheless determined using the pre-2025 information specified in this script.

**Interpretation:** a smaller test RMSE indicates higher accuracy on this specific fictional holdout. A more highly penalized model can perform either better or worse than OLS. The goal is to compare rather than presume a particular winner.

## Learning sequence and principal outputs

1. **Recap Week 1.** `02_week1_baselines_reproduced.csv`, OLS `03_...txt` and `04_...html`; console prints PASS on exact baseline parity.
2. **Loss and penalty.** `06_loss_vs_penalty_illustration.png` shows the OLS squared loss, Ridge L2 penalized objective, and LASSO L1 penalized objective as a function of the standardized schooling slope. This illustrative lambda is **not** a data-selected hyperparameter.
3. **Time-aware validation.** `07_expanding_window_fold_design.csv`, `08_penalized_cv_fold_scores.csv`, `10_penalty_validation_curve.csv`, and `13_validation_RMSE_vs_lambda.png` show how tuning uses past data only.
4. **Chosen lambda.** `11_selected_penalties.csv` displays selected parameters separately for Ridge and LASSO.
5. **Coefficient shrinkage.** `19_coefficient_shrinkage_paths.png` and `20_final_coefficient_comparison.png` visualize shrinkage, with coefficient comparisons also in `17_ols_ridge_lasso_coefficients.csv`. Coefficients per one training SD are shown for comparability.
6. **Fair prediction comparison.** `14_training_and_holdout_performance.csv` and `15_final_2025_model_comparison.csv` contain RMSE, MAE, signed mean error, and R² relative to each evaluation sample's mean.
7. **Actual vs predicted and errors.** `16_predictions_and_errors_2025.csv` keeps all 120 test observations. The `22_`, `23_`, and `24_` graphics compare OLS, Ridge, and LASSO on the same observations. The top-20 error diagnostic is selected *only for display* based on the OLS error; all observations remain in the evaluation.
8. **Output workbook.** `27_ML2_OLS_Ridge_LASSO_Results.xlsx` contains summary tables, all 2025 predictions, CV details, coefficient paths, group diagnostics, and inserted figures. It is created when the R script is run.

## Why not Stargazer p-values for Ridge/LASSO?

The `stargazer` tables present the same OLS coefficients and usual OLS inferential statistics as Week 1. Ridge/LASSO coefficient estimates are saved in their own tables, **without treating them as standard OLS p-values**. This workshop is about predictive performance, not causal inference.

## Interpreting the figures

- **Validation RMSE vs lambda:** x-axis is the regularization strength (log scale); y-axis is error on validation years 2022–2024. Lower is better. A vertical marker denotes the selected lambda for each family and a horizontal dashed line is the OLS validation benchmark.
- **Shrinkage paths:** x-axis is lambda. Larger values correspond to more penalty. Each line shows one predictor's coefficient after scaling the predictor by one training-standard-deviation unit. LASSO coefficients may become exactly zero.
- **Actual vs predicted:** each dot is a different 2025 region. Points close to the dashed 45-degree line indicate smaller prediction error. The dot positions are computed from out-of-sample forecasts.
- **Signed error plot:** positive error means prediction exceeds the observed poverty rate, while negative error means under-prediction.
- **Train vs test RMSE:** training performance is assessed on fitting rows. Test performance is measured on the subsequent year. Comparing both helps illustrate that fitting more closely does not guarantee generalization.

## Verification status

The Week 1 benchmark, fitted multiple-OLS coefficients, and sample construction have been independently recalculated from the source workbook and match the supplied Week 1 R output. The R source has been statically checked for matching delimiters and output completeness. **The Week 2 R script has not been executed in this environment, because an R runtime is unavailable.** Please run the script in RStudio before the workshop and report any version-dependent warning with the console output.

## Suggested discussion questions

1. What does it mean that a model is "supervised"? Does that definition exclude OLS?
2. Which component changes when OLS is turned into Ridge or LASSO: squared-error loss or the penalty?
3. Why do we tune lambda using years before 2025 rather than the 2025 test outcomes?
4. Does the penalized model with the smallest training error have the smallest validation error?
5. Can we interpret a LASSO-selected predictor as a causal determinant of poverty?
6. If Ridge or LASSO loses to OLS on the 2025 holdout, does that make the estimation incorrect?

## Further reading

- Friedman, Hastie & Tibshirani (2010), *Regularization Paths for Generalized Linear Models via Coordinate Descent*, Journal of Statistical Software. https://doi.org/10.18637/jss.v033.i01
- glmnet package vignette: https://glmnet.stanford.edu/articles/glmnet.html
- James et al., *An Introduction to Statistical Learning*, Chapter 6. https://www.statlearning.com/
