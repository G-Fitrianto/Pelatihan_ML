# WEEK 2 | GUIDED CLASSROOM REVIEW
# Run the full main script first; this file reuses its calculated R objects.
# Do not re-estimate or retune using 2025 data.
stopifnot(exists("ols_multiple"), exists("final_fits"),
          exists("selected_lambda"), exists("test_metrics"),
          exists("predictions_2025"))

cat("\n1 | SUPERVISION SIGNAL\n")
cat("Target known on training rows: poverty_rate_pct\n")
cat("OLS is also supervised regression; Ridge/LASSO add penalties.\n")

cat("\n2 | WEEK 1 REFERENCE\n")
print(week1_reproduced[week1_reproduced$split == "Holdout: 2025",
                       c("model", "MAE", "RMSE")], row.names = FALSE)

cat("\n3 | FOLD STRUCTURE (2025 IS NOT USED FOR TUNING)\n")
print(fold_design, row.names = FALSE)

cat("\n4 | HOW STRONG IS THE PENALTY?\n")
print(selected[, c("model", "selected_lambda",
                   "selected_validation_RMSE")], row.names = FALSE)
print(p_cv)

cat("\n5 | UNDERSTANDING COEFFICIENT SHRINKAGE\n")
print(coef_tbl)
print(p_path)

cat("\n6 | FINAL OUT-OF-SAMPLE COMPARISON (2025)\n")
print(test_metrics[, c("model", "MAE", "RMSE", "mean_prediction_error")],
      row.names = FALSE)
print(p_scatter)
print(p_series)
print(p_error)

cat("\n7 | WHAT WAS EXPORTED?\n")
cat(normalizePath(out_dir), "\n")
cat("Workbook: 27_ML2_OLS_Ridge_LASSO_Results.xlsx\n")

cat("\nQUESTIONS FOR STUDENTS\n")
cat("- Which method has the lowest validation RMSE?\n")
cat("- Does it also have the lowest 2025 RMSE?\n")
cat("- Which coefficients became exactly zero under LASSO?\n")
cat("- Why is a test-year comparison preferable to training R-squared?\n")
cat("- Why do these predictive coefficients not identify causal effects?\n")
