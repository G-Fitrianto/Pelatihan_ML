# =============================================================================
# WEEK 2 | PREDICTION IN ECONOMIC ANALYSIS: SUPERVISED MACHINE LEARNING
# Loss functions, regularization, OLS versus Ridge versus LASSO
# Continuation of Week 1, instructor: Gigih Fitrianto
# Version: 1.0.0 | For the synthetic regional economics workshop
# =============================================================================
# RESEARCH QUESTION
# Can Ridge or LASSO improve poverty predictions over the SAME Week 1 OLS?
#
# FAIR COMPARISON RULES
# * Identical raw workbook, target, six lagged predictors and 2025 holdout.
# * Exactly the Week 1 mean, simple OLS, and multiple OLS specifications.
# * All candidate models use the same imputation and 2025 observations.
# * Only historical outcomes (2021-2024) inform model and penalty selection.
# * For temporal CV, preprocessing is re-learned inside each training fold.
# * The 2025 holdout is read for evaluation ONLY after final models are fixed.
# * Ridge/LASSO: glmnet standardizes X within each fitting dataset, then
#   returns coefficients on the original scale; intercept is not penalized.
# * All outputs and interpretations concern FICTIONAL / SYNTHETIC data.
#
# HOW TO RUN
# 1. Unzip the entire package into one folder.
# 2. Set RStudio's working directory to that folder (Session > Set Working Directory).
# 3. Run this file from the beginning. Only modify input_file/out_dir if needed.
# 4. Outputs will be created in ML2_outputs; Week 1 outputs are untouched.
# =============================================================================

# 0 | PACKAGES AND PATHS ------------------------------------------------------
required_packages <- c("readxl", "dplyr", "ggplot2", "glmnet", "openxlsx", "stargazer")
missing_packages <- required_packages[!vapply(required_packages, requireNamespace,
                                               logical(1), quietly = TRUE)]
if (length(missing_packages)) {
  stop("Install packages first: install.packages(c('",
       paste(missing_packages, collapse = "', '"), "'))")
}
suppressPackageStartupMessages({
  library(readxl)
  library(dplyr)
  library(ggplot2)
})

input_file <- file.path(getwd(), "ML1_Economic_Panel_Synthetic.xlsx")
week1_reference_file <- file.path(getwd(), "Week1_reference_performance.csv")
out_dir <- file.path(getwd(), "ML2_outputs")
if (!file.exists(input_file)) stop("Cannot locate Excel data: ", input_file,
                                   "\nSet the working directory or edit input_file.")
if (!dir.exists(out_dir)) dir.create(out_dir, recursive = TRUE)

# Reproducible (all fits are deterministic; seed is also set for reproducibility).
set.seed(20261026)

save_fig <- function(filename, p, w = 9.0, h = 5.4) {
  ggplot2::ggsave(file.path(out_dir, filename), p, width = w,
                  height = h, dpi = 180, bg = "white")
  print(p)
}
write_out <- function(df, filename) {
  utils::write.csv(df, file.path(out_dir, filename), row.names = FALSE,
                   na = "")
}

# Metrics use PERCENTAGE POINTS (not percentage changes).
# Signed error = prediction - observed; positive indicates over-prediction.
score <- function(y, pred) {
  stopifnot(length(y) == length(pred), all(is.finite(y)),
            all(is.finite(pred)))
  err <- as.numeric(pred - y)
  denom <- sum((y - mean(y))^2)
  data.frame(n = length(y),
             MAE = mean(abs(err)),
             RMSE = sqrt(mean(err^2)),
             mean_prediction_error = mean(err),
             R2_relative_to_sample_mean = if (denom > 0)
               1 - sum(err^2) / denom else NA_real_)
}

# 1 | EXACT WEEK 1 DATA CONSTRUCTION -----------------------------------------
raw <- readxl::read_excel(input_file, sheet = "Economic_Panel")
predictors <- c("grdp_pc_million_idr", "unemployment_pct", "schooling_years",
                "internet_access_pct", "manufacturing_share_pct",
                "investment_pc_million_idr")
required_columns <- c("region_id", "economic_zone", "year", "poverty_rate_pct",
                      predictors)
stopifnot(all(required_columns %in% names(raw)))
stopifnot(nrow(raw) == 720L, dplyr::n_distinct(raw$region_id) == 120L)
stopifnot(!anyNA(raw$poverty_rate_pct), !anyDuplicated(raw[c("region_id", "year")]))

# Lag creation matches Week 1 (within region, chronologically ordered).
panel <- raw %>%
  arrange(region_id, year) %>%
  group_by(region_id) %>%
  mutate(across(all_of(predictors), dplyr::lag, .names = "lag_{.col}")) %>%
  ungroup() %>%
  filter(year >= 2021)
lag_predictors <- paste0("lag_", predictors)
stopifnot(nrow(panel) == 600L)
train_raw <- panel %>% filter(year <= 2024)
test_raw <- panel %>% filter(year == 2025)
stopifnot(nrow(train_raw) == 480L, nrow(test_raw) == 120L)
stopifnot(max(train_raw$year) < min(test_raw$year))

# Fixed-fold/preprocessing helper. The supplied 'learning' rows are the ONLY
# source of each median. This avoids validation-period leakage as well.
train_only_impute <- function(learning, applying, vars) {
  meds <- vapply(vars, function(v) median(learning[[v]], na.rm = TRUE), numeric(1))
  if (!all(is.finite(meds))) stop("No finite training median for a predictor.")
  a <- learning; b <- applying
  for (v in vars) {
    a[[v]][is.na(a[[v]])] <- meds[[v]]
    b[[v]][is.na(b[[v]])] <- meds[[v]]
  }
  stopifnot(!anyNA(a[, vars, drop = FALSE]),
            !anyNA(b[, vars, drop = FALSE]))
  list(train = a, validation = b, medians = meds)
}

full_imp <- train_only_impute(train_raw, test_raw, lag_predictors)
train <- full_imp$train
test  <- full_imp$validation
full_medians <- full_imp$medians
write_out(data.frame(predictor = names(full_medians),
                     training_median = as.numeric(full_medians)),
          "01_training_medians.csv")

# 2 | WEEK 1 MODELS REPRODUCED, UNCHANGED -------------------------------------
ytrain <- train$poverty_rate_pct
ytest <- test$poverty_rate_pct
baseline_value <- mean(ytrain)
ols_simple <- stats::lm(poverty_rate_pct ~ lag_schooling_years, data = train)
ols_multiple <- stats::lm(stats::reformulate(lag_predictors,
                                            response = "poverty_rate_pct"),
                          data = train)

train$pred_mean <- rep(baseline_value, nrow(train))
train$pred_simple <- as.numeric(stats::predict(ols_simple, newdata = train))
train$pred_ols <- as.numeric(stats::predict(ols_multiple, newdata = train))
test$pred_mean <- rep(baseline_value, nrow(test))
test$pred_simple <- as.numeric(stats::predict(ols_simple, newdata = test))
test$pred_ols <- as.numeric(stats::predict(ols_multiple, newdata = test))

score_model <- function(d, split, pred_col, label) {
  cbind(data.frame(split = split, model = label),
        score(d$poverty_rate_pct, d[[pred_col]]))
}
week1_models <- c("Training-mean benchmark" = "pred_mean",
                  "Simple OLS: schooling" = "pred_simple",
                  "Multiple OLS: six lagged indicators" = "pred_ols")
week1_reproduced <- do.call(rbind, lapply(c("Training: 2021-2024", "Holdout: 2025"),
  function(split) {
    d <- if (identical(split, "Training: 2021-2024")) train else test
    do.call(rbind, lapply(names(week1_models), function(m)
      score_model(d, split, week1_models[[m]], m)))
  }))
rownames(week1_reproduced) <- NULL

# Strict audit: same Week 1 holdout, same imputation, identical OLS estimates.
if (file.exists(week1_reference_file)) {
  ref <- utils::read.csv(week1_reference_file, stringsAsFactors = FALSE)
  joined <- merge(week1_reproduced, ref, by = c("split", "model"),
                  suffixes = c("_W2", "_W1"), sort = FALSE)
  if (nrow(joined) != nrow(week1_reproduced))
    stop("Week 1 reference models/splits do not match Week 2.")
  for (metric in c("n", "MAE", "RMSE", "mean_prediction_error",
                   "R2_relative_to_sample_mean")) {
    gap <- abs(joined[[paste0(metric, "_W2")]] -
               joined[[paste0(metric, "_W1")]])
    if (any(is.na(gap)) || max(gap) > 1e-6)
      stop("Week 1 parity failed: ", metric,
           ". Check predictors, split, input workbook and imputation.")
  }
  cat("[PASS] Week 1 OLS / mean baseline parity, all splits and metrics.\n")
  week1_parity <- data.frame(check = "Week 1 baseline parity",
                             status = "PASS", tolerance = 1e-6)
} else {
  warning("Week 1 reference file absent: baseline computed but parity not checked.")
  week1_parity <- data.frame(check = "Week 1 baseline parity",
                             status = "NOT CHECKED", tolerance = 1e-6)
}
write_out(week1_reproduced, "02_week1_baselines_reproduced.csv")

# Keep a human-readable Stargazer OLS reference. Penalized coefficients do not
# inherit conventional OLS standard errors/p-values.
stargazer::stargazer(ols_simple, ols_multiple, type = "text", header = FALSE,
   title = "Week 1 OLS Reference (2021-2024 training)",
   column.labels = c("Simple OLS", "Multiple OLS"), digits = 3, no.space = TRUE)
stargazer::stargazer(ols_simple, ols_multiple, type = "text", header = FALSE,
   title = "Week 1 OLS Reference (2021-2024 training)",
   column.labels = c("Simple OLS", "Multiple OLS"), digits = 3, no.space = TRUE,
   out = file.path(out_dir, "03_week1_ols_stargazer.txt"))
stargazer::stargazer(ols_simple, ols_multiple, type = "html", header = FALSE,
   title = "Week 1 OLS Reference (2021-2024 training)",
   column.labels = c("Simple OLS", "Multiple OLS"), digits = 3, no.space = TRUE,
   out = file.path(out_dir, "04_week1_ols_stargazer.html"))

# 3 | LOSS FUNCTION AND PENALTY: A ONE-PREDICTOR TEACHING FIGURE --------------
# Conceptual illustration using the ACTUAL Week 1 training observations.
# This separate lambda is solely illustrative, NOT the tuned Ridge/LASSO lambda.
x_demo <- as.numeric(scale(train$lag_schooling_years))
y_demo <- ytrain
ols_slope_z <- sum(x_demo * (y_demo - mean(y_demo))) / sum(x_demo^2)
b_grid <- seq(ols_slope_z - 4, ols_slope_z + 4, length.out = 301)
lambda_demo <- 2.0
loss_demo <- data.frame(
  coefficient = rep(b_grid, times = 3),
  objective = c(vapply(b_grid, function(b)
                  mean((y_demo - (mean(y_demo) + b*x_demo))^2)/2, numeric(1)),
                vapply(b_grid, function(b)
                  mean((y_demo - (mean(y_demo) + b*x_demo))^2)/2 +
                    lambda_demo*b^2/2, numeric(1)),
                vapply(b_grid, function(b)
                  mean((y_demo - (mean(y_demo) + b*x_demo))^2)/2 +
                    lambda_demo*abs(b), numeric(1))),
  objective_name = rep(c("OLS: loss", "Ridge: loss + L2 penalty",
                         "LASSO: loss + L1 penalty"), each = length(b_grid))
)
write_out(loss_demo, "05_loss_penalty_teaching_values.csv")
p_loss <- ggplot(loss_demo, aes(coefficient, objective, color = objective_name)) +
  geom_line(linewidth = 1.05) +
  labs(title = "Why do Ridge and LASSO fit different coefficients?",
       subtitle = "One standardized schooling predictor; illustrative lambda = 2 (not cross-validated)",
       x = "Slope coefficient on standardized schooling",
       y = "Objective value: squared loss / 2 + penalty", color = NULL) +
  theme_minimal(base_size = 12) + theme(legend.position = "bottom")
save_fig("06_loss_vs_penalty_illustration.png", p_loss, 10, 6.0)

# 4 | CHRONOLOGICAL VALIDATION DESIGN -----------------------------------------
# Three expanding-origin folds for one-year-ahead forecasting:
# 2021 -> 2022 | 2021-2022 -> 2023 | 2021-2023 -> 2024
# The FULL 2025 outcome is excluded from all folds and lambda selection.
folds <- list(
  list(fold = "V1", train_years = 2021L, valid_year = 2022L),
  list(fold = "V2", train_years = 2021:2022, valid_year = 2023L),
  list(fold = "V3", train_years = 2021:2023, valid_year = 2024L)
)
fold_design <- do.call(rbind, lapply(folds, function(f) data.frame(
  fold = f$fold,
  training_outcome_years = paste(f$train_years, collapse = ", "),
  validation_outcome_year = f$valid_year,
  training_n = sum(train_raw$year %in% f$train_years),
  validation_n = sum(train_raw$year == f$valid_year))))
write_out(fold_design, "07_expanding_window_fold_design.csv")

# glmnet needs a decreasing sequence. Supply the SAME pre-specified grid in
# every fold and for both model families. It never depends on 2025 outcomes.
lambda_grid <- exp(seq(log(100), log(0.001), length.out = 81))
model_alpha <- c(Ridge = 0, LASSO = 1)

make_x <- function(d, columns = lag_predictors) {
  x <- as.matrix(d[, columns, drop = FALSE]); storage.mode(x) <- "double"
  stopifnot(ncol(x) == length(columns), all(is.finite(x)))
  x
}

cv_fold_results <- list()
cv_ols_results <- list()
idx <- 0L
for (f in folds) {
  fold_train_raw <- train_raw %>% filter(year %in% f$train_years)
  fold_valid_raw <- train_raw %>% filter(year == f$valid_year)
  # Critical: imputation is trained ONLY on fold_train_raw, not full 2021-24.
  pp <- train_only_impute(fold_train_raw, fold_valid_raw, lag_predictors)
  tr <- pp$train; va <- pp$validation
  xtr <- make_x(tr); xva <- make_x(va)
  ytr <- tr$poverty_rate_pct; yva <- va$poverty_rate_pct

  # OLS is also evaluated on the EXACT same validation folds, no special terms.
  ols_f <- stats::lm(stats::reformulate(lag_predictors,
                                       response = "poverty_rate_pct"), data = tr)
  simple_f <- stats::lm(poverty_rate_pct ~ lag_schooling_years, data = tr)
  ols_cv_preds <- list(
    "Training-mean benchmark" = rep(mean(ytr), length(yva)),
    "Simple OLS: schooling" = as.numeric(predict(simple_f, newdata = va)),
    "Multiple OLS: six lagged indicators" = as.numeric(predict(ols_f, newdata = va)))
  for (nm in names(ols_cv_preds)) {
    s <- score(yva, ols_cv_preds[[nm]])
    cv_ols_results[[length(cv_ols_results) + 1L]] <-
      cbind(data.frame(fold = f$fold, valid_year = f$valid_year, model = nm), s)
  }

  for (nm in names(model_alpha)) {
    idx <- idx + 1L
    fit <- glmnet::glmnet(x = xtr, y = ytr, family = "gaussian",
                          alpha = model_alpha[[nm]], lambda = lambda_grid,
                          intercept = TRUE, standardize = TRUE)
    predictions <- as.matrix(predict(fit, newx = xva, s = lambda_grid))
    stopifnot(nrow(predictions) == length(yva),
              ncol(predictions) == length(lambda_grid),
              all(is.finite(predictions)))
    squared_err <- sweep(predictions, 1, yva, "-")^2
    absolute_err <- abs(sweep(predictions, 1, yva, "-"))
    cv_fold_results[[idx]] <- data.frame(
      fold = f$fold, valid_year = f$valid_year, model = nm,
      lambda = lambda_grid, n = length(yva),
      MSE = colMeans(squared_err),
      RMSE = sqrt(colMeans(squared_err)),
      MAE = colMeans(absolute_err))
  }
}
cv_folds <- do.call(rbind, cv_fold_results)
cv_ols_folds <- do.call(rbind, cv_ols_results)
rownames(cv_folds) <- NULL
rownames(cv_ols_folds) <- NULL
write_out(cv_folds, "08_penalized_cv_fold_scores.csv")
write_out(cv_ols_folds, "09_ols_cv_fold_scores.csv")

# Average MSE across the 3 equal-sized annual validation cohorts (each n=120).
# Optimize pooled validation MSE, then report pooled validation RMSE.
cv_summary <- cv_folds %>%
  group_by(model, lambda) %>%
  summarise(folds = n(), validation_n = sum(.data$n),
            validation_MSE = weighted.mean(.data$MSE, w = .data$n),
            validation_RMSE = sqrt(validation_MSE),
            validation_MAE = weighted.mean(.data$MAE, w = .data$n),
            .groups = "drop")
stopifnot(all(cv_summary$folds == length(folds)))
selected <- cv_summary %>%
  group_by(model) %>%
  arrange(validation_MSE, desc(lambda), .by_group = TRUE) %>%
  slice_head(n = 1) %>%
  ungroup() %>%
  rename(selected_lambda = lambda,
         selected_validation_MSE = validation_MSE,
         selected_validation_RMSE = validation_RMSE,
         selected_validation_MAE = validation_MAE)
selected_lambda <- stats::setNames(selected$selected_lambda, selected$model)
stopifnot(all(c("Ridge", "LASSO") %in% names(selected_lambda)))
write_out(cv_summary, "10_penalty_validation_curve.csv")
write_out(selected, "11_selected_penalties.csv")

# OLS validation scores for the exact same 2022/2023/2024 cohorts.
cv_ols_summary <- cv_ols_folds %>%
  group_by(model) %>%
  summarise(folds = n(), validation_n = sum(.data$n),
            validation_MSE = weighted.mean(.data$RMSE^2, w = .data$n),
            validation_RMSE = sqrt(validation_MSE),
            validation_MAE = weighted.mean(.data$MAE, w = .data$n),
            .groups = "drop")
write_out(cv_ols_summary, "12_ols_validation_reference.csv")

p_cv <- ggplot(cv_summary, aes(lambda, validation_RMSE, color = model)) +
  geom_line(linewidth = 1.1) +
  geom_point(data = selected,
             aes(x = selected_lambda, y = selected_validation_RMSE),
             size = 2.7, show.legend = FALSE) +
  geom_hline(yintercept = cv_ols_summary$validation_RMSE[
    cv_ols_summary$model == "Multiple OLS: six lagged indicators"],
    linetype = "dashed", color = "grey35") +
  scale_x_log10() +
  labs(title = "Select lambda using the past, not the 2025 test sample",
       subtitle = "Expanding validation (2022-2024); dashed line = multiple OLS validation RMSE",
       x = "Penalty lambda (log scale; larger to the right)",
       y = "Pooled validation RMSE (percentage points)", color = NULL) +
  theme_minimal(base_size = 12) + theme(legend.position = "bottom")
save_fig("13_validation_RMSE_vs_lambda.png", p_cv, 10, 5.8)

# 5 | FINAL FIT ON EXACTLY THE WEEK 1 TRAINING ROWS ----------------------------
xtrain <- make_x(train)
xtest <- make_x(test)
final_fits <- lapply(names(model_alpha), function(nm)
  glmnet::glmnet(xtrain, ytrain, family = "gaussian",
                 alpha = model_alpha[[nm]], lambda = lambda_grid,
                 intercept = TRUE, standardize = TRUE))
names(final_fits) <- names(model_alpha)
for (nm in names(final_fits)) {
  lam <- unname(selected_lambda[[nm]])
  train[[paste0("pred_", tolower(nm))]] <- as.numeric(
    predict(final_fits[[nm]], newx = xtrain, s = lam))
  test[[paste0("pred_", tolower(nm))]] <- as.numeric(
    predict(final_fits[[nm]], newx = xtest, s = lam))
}
stopifnot(all(is.finite(test$pred_ridge)), all(is.finite(test$pred_lasso)))

# 6 | FAIR COMPARISON: MAE, RMSE, MEAN ERROR, TEST R2 --------------------------
model_names <- c(week1_models,
                 "Ridge: tuned (six predictors)" = "pred_ridge",
                 "LASSO: tuned (six predictors)" = "pred_lasso")
all_performance <- do.call(rbind, lapply(c("Training: 2021-2024", "Holdout: 2025"),
  function(split) {
    d <- if (identical(split, "Training: 2021-2024")) train else test
    do.call(rbind, lapply(names(model_names), function(m)
      score_model(d, split, model_names[[m]], m)))
  }))
rownames(all_performance) <- NULL
train_metrics <- all_performance %>% filter(split == "Training: 2021-2024")
test_metrics <- all_performance %>% filter(split == "Holdout: 2025")
write_out(all_performance, "14_training_and_holdout_performance.csv")
write_out(test_metrics, "15_final_2025_model_comparison.csv")
cat("\n===== FINAL 2025 HOLDOUT: ALL FIVE PRE-SPECIFIED MODELS =====\n")
print(test_metrics[, c("model", "MAE", "RMSE", "mean_prediction_error")],
      row.names = FALSE, digits = 5)

# Signed prediction error = fitted - actual; keep identical observations.
predictions_2025 <- test %>%
  transmute(region_id, economic_zone, year, actual_poverty_pct = poverty_rate_pct,
            pred_mean_pct = pred_mean, pred_simple_ols_pct = pred_simple,
            pred_multiple_ols_pct = pred_ols,
            pred_ridge_pct = pred_ridge, pred_lasso_pct = pred_lasso,
            error_ols_pp = pred_ols - poverty_rate_pct,
            error_ridge_pp = pred_ridge - poverty_rate_pct,
            error_lasso_pp = pred_lasso - poverty_rate_pct,
            abs_error_ols_pp = abs(error_ols_pp),
            abs_error_ridge_pp = abs(error_ridge_pp),
            abs_error_lasso_pp = abs(error_lasso_pp))
stopifnot(nrow(predictions_2025) == 120L,
          n_distinct(predictions_2025$region_id) == 120L)
write_out(predictions_2025, "16_predictions_and_errors_2025.csv")

# 7 | COEFFICIENT COMPARISON AND PENALTY PATHS ---------------------------------
# Coefficients returned by glmnet are in ORIGINAL variable units. Standardized
# effects below multiply slope by the TRAIN predictor SD for teaching comparability.
sd_train <- vapply(train[, lag_predictors, drop = FALSE],
                   stats::sd, numeric(1))
stopifnot(all(is.finite(sd_train)), all(sd_train > 0))
coef_ols <- stats::coef(ols_multiple)
coef_ridge <- as.numeric(coef(final_fits$Ridge, s = selected_lambda[["Ridge"]]))
coef_lasso <- as.numeric(coef(final_fits$LASSO, s = selected_lambda[["LASSO"]]))
coef_tbl <- do.call(rbind, lapply(seq_along(lag_predictors), function(j) {
  key <- lag_predictors[j]
  data.frame(predictor = key,
             model = c("Multiple OLS", "Ridge", "LASSO"),
             coefficient_original_units = c(unname(coef_ols[key]),
                                             coef_ridge[j+1], coef_lasso[j+1]),
             coefficient_per_1SD_predictor = c(unname(coef_ols[key]),
                                               coef_ridge[j+1], coef_lasso[j+1]) *
                                               unname(sd_train[key]),
             predictor_training_SD = unname(sd_train[key]))
}))
write_out(coef_tbl, "17_ols_ridge_lasso_coefficients.csv")

penalty_paths <- do.call(rbind, lapply(names(final_fits), function(nm) {
  B <- as.matrix(coef(final_fits[[nm]], s = lambda_grid))
  do.call(rbind, lapply(seq_along(lag_predictors), function(j) {
    data.frame(model = nm, lambda = lambda_grid,
               predictor = lag_predictors[j],
               coefficient_original_units = as.numeric(B[j+1, ]),
               coefficient_per_1SD_predictor = as.numeric(B[j+1, ]) * sd_train[j])
  }))
}))
write_out(penalty_paths, "18_penalty_coefficient_paths.csv")
chosen_for_plot <- data.frame(model = names(selected_lambda),
                              lambda = as.numeric(selected_lambda))
p_path <- ggplot(penalty_paths,
                 aes(lambda, coefficient_per_1SD_predictor, color = predictor)) +
  geom_line(linewidth = 0.9) +
  geom_vline(data = chosen_for_plot, aes(xintercept = lambda),
             color = "black", linetype = "dashed", inherit.aes = FALSE) +
  geom_hline(yintercept = 0, color = "grey60") +
  facet_wrap(~model, nrow = 2, scales = "free_y") +
  scale_x_log10() +
  labs(title = "Coefficient shrinkage under increasing regularization",
       subtitle = "Each curve is one economic indicator; dashed line = CV-selected lambda",
       x = "Penalty lambda (log scale; larger to the right)",
       y = "Coefficient per 1-SD change in predictor (poverty points)",
       color = "Lagged predictor") +
  theme_minimal(base_size = 11) + theme(legend.position = "bottom")
save_fig("19_coefficient_shrinkage_paths.png", p_path, 10.8, 8)

p_coef <- ggplot(coef_tbl,
  aes(x = model, y = coefficient_per_1SD_predictor, color = model)) +
  geom_point(size = 2.9) +
  facet_wrap(~predictor, scales = "free_y", ncol = 3) +
  geom_hline(yintercept = 0, linetype = "dotted", color = "grey50") +
  labs(title = "OLS vs Ridge vs LASSO: coefficient differences",
       subtitle = "Effects rescaled to a 1-SD predictor change; not causal estimates",
       x = NULL, y = "Estimated coefficient per 1-SD increase") +
  theme_minimal(base_size = 11) +
  theme(legend.position = "none", axis.text.x = element_text(angle = 25, hjust = 1))
save_fig("20_final_coefficient_comparison.png", p_coef, 11.0, 6.4)

# Illustrate the two different objective functions on the 2021-24 training set.
# glmnet internally standardizes columns before applying penalties. For this
# teaching decomposition use population SD for standardized-predictor slopes.
# Objective totals must NOT be compared across differently selected lambdas.
objective_parts <- do.call(rbind, lapply(names(final_fits), function(nm) {
  b <- if (nm == "Ridge") coef_ridge[-1] else coef_lasso[-1]
  b_standardized <- b * vapply(seq_len(ncol(xtrain)), function(j)
    sqrt(mean((xtrain[, j] - mean(xtrain[, j]))^2)), numeric(1))
  lam <- selected_lambda[[nm]]
  alpha <- model_alpha[[nm]]
  pred <- if (nm == "Ridge") train$pred_ridge else train$pred_lasso
  loss <- mean((ytrain - pred)^2) / 2
  penalty_unweighted <- alpha * sum(abs(b_standardized)) +
    (1 - alpha)/2 * sum(b_standardized^2)
  data.frame(model = nm, lambda = lam, training_loss_half_MSE = loss,
             penalty_term = lam * penalty_unweighted,
             objective_sum = loss + lam * penalty_unweighted,
             nonzero_predictors = sum(abs(b) > 1e-8))
}))
write_out(objective_parts, "21_loss_penalty_decomposition.csv")

# 8 | ACTUAL VERSUS PREDICTED: IDENTICAL 2025 REGIONS --------------------------
comparison_long <- do.call(rbind, lapply(
  c("Multiple OLS" = "pred_multiple_ols_pct", "Ridge" = "pred_ridge_pct",
    "LASSO" = "pred_lasso_pct"), function(col) {
      data.frame(region_id = predictions_2025$region_id,
                 actual = predictions_2025$actual_poverty_pct,
                 predicted = predictions_2025[[col]])
    }))
comparison_long$model <- rep(c("Multiple OLS", "Ridge", "LASSO"),
                             each = nrow(predictions_2025))
p_scatter <- ggplot(comparison_long, aes(actual, predicted)) +
  geom_point(alpha = 0.65, color = "#285F4E", size = 1.7) +
  geom_abline(slope = 1, intercept = 0, color = "#A37D2B",
              linetype = "dashed", linewidth = 0.8) +
  facet_wrap(~model, nrow = 1) +
  coord_equal() +
  labs(title = "2025 holdout: predictions versus observed poverty",
       subtitle = "All 120 fictional regions; dashed = perfect agreement",
       x = "Observed poverty rate (%)", y = "Predicted poverty rate (%)") +
  theme_minimal(base_size = 11)
save_fig("22_2025_actual_vs_predicted_models.png", p_scatter, 12.2, 4.9)

ordered_test <- predictions_2025 %>%
  arrange(actual_poverty_pct) %>% mutate(region_rank = row_number())
series_long <- do.call(rbind, lapply(c(
  "Observed" = "actual_poverty_pct", "Multiple OLS" = "pred_multiple_ols_pct",
  "Ridge" = "pred_ridge_pct", "LASSO" = "pred_lasso_pct"), function(v) {
    data.frame(rank = ordered_test$region_rank, value = ordered_test[[v]])
  }))
series_long$model <- rep(c("Observed", "Multiple OLS", "Ridge", "LASSO"),
                         each = nrow(ordered_test))
p_series <- ggplot(series_long, aes(rank, value, color = model)) +
  geom_line(linewidth = 0.9, alpha = 0.85) +
  scale_color_manual(values = c("Observed" = "#152B4B",
                                 "Multiple OLS" = "#AF772B",
                                 "Ridge" = "#3D8B65", "LASSO" = "#456CA8")) +
  labs(title = "Observed versus predicted poverty across regions in 2025",
       subtitle = "Ranked by observed poverty for display only; ranking was NOT used in fitting",
       x = "Region rank by 2025 observed poverty", y = "Poverty rate (%)", color = NULL) +
  theme_minimal(base_size = 11) + theme(legend.position = "bottom")
save_fig("23_2025_prediction_profiles.png", p_series, 11.2, 5.7)

# Compare the SAME 20 regions chosen by ABSOLUTE OLS error, for illustration.
# Test outcomes are only used to report diagnostics, never to tune the models.
top20 <- predictions_2025 %>%
  arrange(desc(abs_error_ols_pp)) %>% slice_head(n = 20)
errors_long <- rbind(
  data.frame(region_id = top20$region_id, model = "Multiple OLS", error = top20$error_ols_pp),
  data.frame(region_id = top20$region_id, model = "Ridge", error = top20$error_ridge_pp),
  data.frame(region_id = top20$region_id, model = "LASSO", error = top20$error_lasso_pp))
errors_long$region_id <- factor(errors_long$region_id,
                                levels = rev(top20$region_id))
p_error <- ggplot(errors_long, aes(region_id, error, color = model)) +
  geom_hline(yintercept = 0, color = "grey50") +
  geom_point(position = position_dodge(width = 0.52), size = 2.2) +
  coord_flip() +
  labs(title = "Do the models make different errors in the same regions?",
       subtitle = "20 regions with largest OLS absolute errors; positive = over-prediction",
       x = "Fictitious region", y = "Signed prediction error (percentage points)", color = NULL) +
  theme_minimal(base_size = 11) + theme(legend.position = "bottom")
save_fig("24_2025_prediction_gaps_same_regions.png", p_error, 10.4, 7.4)

p_perf <- ggplot(all_performance,
                 aes(model, RMSE, fill = split)) +
  geom_col(position = "dodge", width = 0.75) +
  coord_flip() +
  labs(title = "Training fit is not the same as future predictive accuracy",
       subtitle = "The 2025 holdout is evaluated after tuning on 2021-2024",
       x = NULL, y = "RMSE (poverty percentage points)", fill = "Data split") +
  theme_minimal(base_size = 11) + theme(legend.position = "bottom")
save_fig("25_training_vs_test_RMSE.png", p_perf, 10.6, 6.1)

# 9 | SUBGROUP DIAGNOSTICS ----------------------------------------------------
zone_models <- c("Multiple OLS" = "pred_multiple_ols_pct",
                 "Ridge" = "pred_ridge_pct", "LASSO" = "pred_lasso_pct")
zone_diagnostics <- do.call(rbind, lapply(
  sort(unique(predictions_2025$economic_zone)), function(z) {
    d <- predictions_2025[predictions_2025$economic_zone == z, ]
    do.call(rbind, lapply(names(zone_models), function(nm) {
      cbind(data.frame(economic_zone = z, model = nm),
            score(d$actual_poverty_pct, d[[zone_models[[nm]]]]))
    }))
  }))
rownames(zone_diagnostics) <- NULL
write_out(zone_diagnostics, "26_test_error_by_economic_zone.csv")

# 10 | EXPORT MASTER EXCEL WORKBOOK AND PNG FIGURES ---------------------------
wb <- openxlsx::createWorkbook()
overview <- data.frame(
  item = c("Title", "Data", "Status", "Target", "Predictors", "Train outcomes",
           "Test outcomes", "Historical validation years", "Penalty selection",
           "OLS design", "Ridge design", "LASSO design", "Error definition",
           "Fair comparison", "Test sample caveat", "Inference caveat"),
  value = c("Week 2: Supervised Learning using R",
            "ML1_Economic_Panel_Synthetic.xlsx", "Synthetic fictional regions",
            "Regional poverty (%)", paste(lag_predictors, collapse = ", "),
            "2021-2024 (480)", "2025 (120)", "2022, 2023, 2024",
            "Minimize expanding-origin, pooled validation MSE",
            "Unpenalized multiple regression, same as Week 1",
            paste0("Ridge alpha=0, tuned lambda=", signif(selected_lambda[["Ridge"]], 5)),
            paste0("LASSO alpha=1, tuned lambda=", signif(selected_lambda[["LASSO"]], 5)),
            "Predicted minus actual in percentage points",
            "Same variables, train/test observations and fold-aware imputation",
            "Single 2025 holdout cannot establish multi-year forecasting reliability",
            "OLS inference is not causal; Ridge/LASSO coefficients have no naive OLS p-values"))
all_sheets <- list(
  Overview = overview,
  Week1_Parity = week1_parity,
  Week1_Baselines = week1_reproduced,
  Validation_Design = fold_design,
  OLS_Validation = cv_ols_summary,
  CV_Fold_Scores = cv_folds,
  CV_Lambda_Curve = cv_summary,
  Selected_Lambda = selected,
  Train_Metrics = train_metrics,
  Test_Metrics = test_metrics,
  Predictions_2025 = predictions_2025,
  Coefficients = coef_tbl,
  Penalty_Paths = penalty_paths,
  Objective_Components = objective_parts,
  Zone_Diagnostics = zone_diagnostics,
  Training_Medians = data.frame(predictor = names(full_medians),
                                median = unname(full_medians)))
for (nm in names(all_sheets)) {
  d <- all_sheets[[nm]]
  openxlsx::addWorksheet(wb, nm)
  openxlsx::writeDataTable(wb, nm, d, tableStyle = "TableStyleMedium2")
  openxlsx::freezePane(wb, nm, firstRow = TRUE)
  openxlsx::setColWidths(wb, nm, cols = seq_len(ncol(d)), widths = 18)
}
openxlsx::setColWidths(wb, "Overview", cols = 2, widths = 94)
openxlsx::setColWidths(wb, "Test_Metrics", cols = 2, widths = 45)
openxlsx::setColWidths(wb, "Predictions_2025", cols = 1:2, widths = c(16, 20))
openxlsx::setColWidths(wb, "Coefficients", cols = 1, widths = 34)
openxlsx::addWorksheet(wb, "Figures")
openxlsx::writeData(wb, "Figures", "Visual examples: see also standalone PNG files", startRow = 1)
figure_arrangement <- list(
  list(file = "13_validation_RMSE_vs_lambda.png", row = 3,  w = 9.2, h = 5.1),
  list(file = "19_coefficient_shrinkage_paths.png", row = 33, w = 9.2, h = 7.0),
  list(file = "22_2025_actual_vs_predicted_models.png", row = 73, w = 10.4, h = 4.9),
  list(file = "24_2025_prediction_gaps_same_regions.png", row = 102, w = 9.2, h = 6.7))
for (item in figure_arrangement) {
  openxlsx::insertImage(wb, "Figures", file = file.path(out_dir, item$file),
                        startRow = item$row, startCol = 1,
                        width = item$w, height = item$h, units = "in")
}
excel_path <- file.path(out_dir, "27_ML2_OLS_Ridge_LASSO_Results.xlsx")
openxlsx::saveWorkbook(wb, excel_path, overwrite = TRUE)

# 11 | RUN CHECKS / PROVENANCE ------------------------------------------------
stopifnot(length(unique(predictions_2025$region_id)) == 120L)
stopifnot(all(predictions_2025$year == 2025L))
stopifnot(all(selected_lambda > 0), all(is.finite(selected_lambda)))
stopifnot(all(is.finite(test_metrics$MAE)), all(is.finite(test_metrics$RMSE)))
stopifnot(file.exists(excel_path))
writeLines(capture.output(sessionInfo()),
           file.path(out_dir, "28_session_info.txt"))
cat("\n[PASS] Week 2 outputs saved in: ", normalizePath(out_dir), "\n")
cat("[PASS] Week 1 baseline comparison and fair-sample checks completed.\n")
cat("[INFO] Ridge lambda: ", selected_lambda[["Ridge"]],
    "; LASSO lambda: ", selected_lambda[["LASSO"]], "\n", sep = "")
cat("[INFO] Workbook: ", normalizePath(excel_path), "\n", sep = "")
cat("[NOTE] Coefficient shrinkage can increase or decrease 2025 RMSE.\n")
cat("[NOTE] Synthetic outcomes are for instruction, not policy evidence.\n")
# =============================================================================
