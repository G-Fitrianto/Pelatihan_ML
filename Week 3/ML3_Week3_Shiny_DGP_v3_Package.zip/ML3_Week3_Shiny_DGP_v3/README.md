# Week 3 Shiny Lab v3.0: Configurable Data-Generating Processes

**Unsupervised ML for Economic Analysis**: PCA, K-means, Hierarchical Clustering, MCA, and post-hoc economic interpretation.

This version extends Week 3 Shiny v2.2. The fixed dataset and five classroom presets remain available, but students can now generate **new data from parameterized data-generating processes (DGPs)**, change the DGP parameters interactively, and study the effect on PCA, silhouette, K-means, and hierarchical clustering.

## Downloaded files

- `app.R`: complete Shiny app.
- `ML3_Regional_Profiles_2024.xlsx`: unchanged original 120-region reference dataset.
- `smoke_test.R`: regression and parameterization checks, including different sample sizes, seeds, DGPs, clustering methods, and heatmaps.
- `DGP_CLASSROOM_EXPERIMENTS.md`: guided exercises, recommended initial parameters and interpretation.
- `README.md`: this manual.

## 1. Install and launch in RStudio

Set the working directory to **the extracted folder containing `app.R` and `ML3_Regional_Profiles_2024.xlsx`**, then run:

```r
install.packages(c("shiny", "readxl", "ggplot2", "cluster", "openxlsx"))
install.packages("FactoMineR")  # optional, enables MCA

source("smoke_test.R")
shiny::runApp(".", launch.browser = TRUE)
```

The app never edits the original Excel input. New data exist in memory until the user downloads the CSV or XLSX outputs. Results are for **synthetic economic regions**, not administrative statistics.

## 2. Three data options in Start Here

| Mode | Source | User controls |
|---|---|---|
| Reference | Fixed original 2024 dataset, 120 synthetic regions | Analysis settings only |
| Classroom presets | Five preconfigured scenarios from v2.2 | Random seed and a single noise multiplier |
| **Configurable DGPs** | Five parameter-driven generators added in v3.0 | Sample size, designed group count, separation/signal strength, noise SD, correlation, and family-specific parameters |

The five parameterized DGPs are:

1. **Balanced Gaussian mixture**: draws multiple Gaussian components with equally sized designed groups; moves group centers apart using `separation`.
2. **Elliptical / correlated Gaussian mixture**: same principle, but varying noise covariance can make elongated clusters; `anisotropy` controls unequal feature-wise noise variances.
3. **Unequal-size Gaussian mixture**: variable mixture weights controlled by a largest-to-smallest relative-weight ratio (`imbalance`). Realized counts are random but all groups receive at least three observations.
4. **Continuous latent economic gradient**: a continuous factor along a direction in six-dimensional feature space; **there is no designed discrete true K**.
5. **Non-convex concentric rings**: latent circular patterns, embedded in six numeric indicators. K-means can split the rings in ways that differ from the designed group labels because Euclidean K-means is a centroid method.

**The six variables remain unchanged**: GRDP per capita, unemployment, schooling, internet access, manufacturing share, and investment per capita. Numeric simulated values are transformed into stylized economic units, with limits to keep examples readable. Those transformations may affect geometry and are part of the teaching example.

### Statistical specification

For a Gaussian-mixture example, the simulation follows:

\[
G_i \sim \mathrm{Categorical}(w_1,\ldots,w_K),\qquad
Z_i=\mu_{G_i}+\varepsilon_i,\qquad
\varepsilon_i\sim N(0,\sigma^2 D\Sigma_\rho D).
\]

`separation` scales the distances among designed group centers, `sd` controls \(\sigma\), `rho` controls equicorrelation in the Gaussian innovations, and `anisotropy` changes the diagonal scale matrix \(D\) for the elliptical family. The other families use a continuous latent score or ring-shaped latent coordinates.

## 3. Controls and what they do

| Control | Supported range | Meaning |
|---|---:|---|
| Sample size `n` | 60–300 | Number of fictional regions in the active synthetic cross-section |
| Designed K | 2–6 | Number of components/rings **in the generator**, not the K-means K selected by silhouette; not applicable to continuous DGP |
| Center separation / factor strength | 0.3–5 | Distance between designed group centers, strength of continuum or distance among rings |
| Noise SD | 0.15–3 | Within-pattern variability |
| Noise correlation `rho` | 0–0.90 | Correlation between Gaussian disturbances to the six indicators |
| Largest/smallest group weight | 1–10 | Mixture-probability imbalance; unequal-size DGP only |
| Noise anisotropy | 1–6 | Relative variance/elongation; elliptical DGP only |
| Random seed | 1–9,999,999 | Reproduce the same random sample with the same DGP and parameters |

Use the sliders or numeric entry field in **Start Here**. When a setting changes, Shiny recomputes the current data, PCA, K-means, elbow, silhouette and hierarchical results. For potentially costly cross-family calculations, click **Calculate five DGP silhouette curves** or **Compare five parameter values** explicitly.

## 4. Where to look for results

- **Start Here**: current DGP and parameter table, simulated data counts, designed-group diagnostics, ARI (when true groups exist), and a PCA projection of the current simulated data. For teaching, the colored *designed* groups are only displayed after data generation; the labels do not enter clustering.
- **PCA Explorer**: variance explained, scores, loadings, and a six-variable biplot; recalculated for each DGP.
- **K-Means Lab**: choose fitted K from 2 to 6; inspect elbow, silhouette, PCA display and group profiles. The **K selected by silhouette** can differ from the designed true K.
- **K-Means → Compare scenarios**: the original six fixed/preset patterns, unchanged, with n=120.
- **K-Means → Compare configurable DGPs**: on demand, five data-generating families compared with common sample size, seed and applicable parameters.
- **K-Means → Parameter sensitivity**: on demand, compare five values of **one** parameter on the current DGP while preserving seed and all other settings.
- **Hierarchical**: linkage methods, dendrogram, height and cut, PCA group map, standardized/raw profiles and ARI versus K-means. These use the active generated data.
- **MCA**: a teaching transformation of economic indicators into Low/Mid/High categories; it uses no poverty target.
- **Post-Hoc**: compares groups with the withheld designed labels and separately generated 2025 poverty for interpretation. Continuous DGP has no designed cluster truth.
- **Export & Guide**: active input CSV, DGP parameter CSV, cluster assignments, PNG graphics and Excel workbook.

## 5. Reproducibility and exports

The active data CSV includes generated values, scenario ID, seed, noise and **full DGP parameters**. The Excel workbook includes `DGP_Parameters` and, where applicable, `Designed_Group_Posthoc` and optional cross-DGP/sensitivity results. Keep both data and parameter files to reproduce an exercise.

The reference workbook is never overwritten. Exports are always initiated by a download action.

## 6. Interpretation safeguards

- A *silhouette-best K* is the maximum for the candidate range \(K=2,\ldots,6\). It is not proof that meaningful discrete clusters exist.
- `true K` belongs to the **simulation design**. It does not have to match the K selected by K-means.
- The `continuous` generator intentionally has no true discrete K, despite K-means returning numerical partitions.
- Some DGPs are non-convex, unequal-sized or correlated, which can challenge centroid-based K-means.
- PCA sign flips and K-means cluster numbering changes do not change substantive equivalence.
- The external `economic_zone`, the designed group labels and 2025 poverty are never used in PCA, cluster fitting or silhouette computation.
- The aim is to **learn how models respond to data-generating assumptions**, not to establish causal economic effects.

## 7. Validation status

The script and package have been inspected statically; `smoke_test.R` exercises all DGP families and the legacy clustering workflow. The baseline dataset is unchanged. **R is not installed in the code-authoring environment**, so a native R Shiny browser test has not been completed here. Run the provided smoke test and visually inspect each tab before teaching.
