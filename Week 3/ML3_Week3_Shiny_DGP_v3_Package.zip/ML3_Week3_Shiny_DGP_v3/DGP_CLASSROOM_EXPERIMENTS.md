# Week 3 DGP Simulation: Classroom Exercises

Use the configurable DGPs in **Start Here**. Leave **Standardize each indicator** selected in PCA until the final scale-sensitivity activity. For the first comparisons, keep the random seed at **123**.

## Experiment A: Separability and silhouette (10 minutes)

Choose **Gaussian mixture (balanced clusters)**. Set `n=120`, `K=4`, `sd=0.65`, `rho=0.15`. Try separation values **0.5**, **1.5**, **3.0**. For each, open **K-Means → Elbow and silhouette**. Record the preferred K and maximum silhouette. Then open **Parameter sensitivity**, choose separation, and run the controlled comparison. Ask: Does higher separation generally produce more clearly separated groups? Is the preferred K always the DGP's K?

## Experiment B: Noise and sample size (8 minutes)

Keep the Gaussian mixture at K=4, separation=2, seed=123. Set SD to **0.3**, **1.0**, **2.3**. Compare silhouette. Next change n from **60** to **240**. Ask: Does a bigger sample automatically make groups more distinct? What changes in cluster-size variability?

## Experiment C: Correlated / elliptical clusters (10 minutes)

Choose **Elliptical mixture**, K=4, n=120, separation=2, sd=0.65. First `rho=0` and anisotropy=1. Then `rho=0.75` and anisotropy=5. Compare PCA axes, K-means centroids, and dendrogram results. Ask: What do standardization and correlation change about Euclidean distances?

## Experiment D: Unbalanced groups (7 minutes)

Choose **Unequal-size mixture**. Hold n=120, K=4, separation=2, noise=0.65. Compare the group-weight ratio **1 vs 8**. Inspect true designed counts in Start Here, chosen cluster sizes in K-means, and ARI. Ask: Can a small group be absorbed by a larger cluster even if its mean differs?

## Experiment E: No designed true K (8 minutes)

Choose **Continuous latent economic gradient**. Set n=120, separation=2 and SD=0.5. Despite no designed discrete groups, calculate silhouette for 2..6. What does the silhouette-best K mean now? Contrast with four-group Gaussian mixture. This illustrates why silhouette is a *relative clustering criterion*, not a test that discrete economic types exist.

## Experiment F: Non-convex geometry (7 minutes)

Choose **Concentric rings** with n=120, K=3, separation=2, SD=0.25. Compare the designed groups in **Start Here** with the discovered groups in **K-Means** and **Hierarchical**. Ask why centroid-based K-means might group rings incorrectly and whether another linkage method changes the grouping.

## Suggested submission

Ask students to download two active datasets, each with the parameter CSV, plus a worksheet comparing the DGP label, n, K (when defined), separation, SD, rho, best silhouette K, maximum silhouette and ARI. Require a short paragraph explaining why the same algorithm can behave differently under different DGPs. The values should be filled **from their Shiny results**, not copied from a prespecified answer key.

### Interpretation notes

- Different random seeds and metric scaling can alter the results. None of the parameter values above guarantee a fixed winning K.
- The class is using simulated, fictional economic profiles, not real Indonesian district data.
- The outcome and designed labels are generated for post-hoc discussion and never enter unsupervised fitting.
