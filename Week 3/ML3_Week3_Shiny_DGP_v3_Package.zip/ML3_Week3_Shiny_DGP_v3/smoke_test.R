# Week 3 Shiny app | lightweight computational checks
# In RStudio, set working directory to the extracted app folder, then run:
# source("smoke_test.R")
# Tests use the same input workbook and functions that the Shiny app uses.

stopifnot(file.exists("app.R"), file.exists("ML3_Regional_Profiles_2024.xlsx"))
stopifnot(all(vapply(c("shiny", "readxl", "ggplot2", "cluster", "openxlsx"),
                     requireNamespace, logical(1), quietly = TRUE)))

# Sourcing an app object does not launch an interactive browser session.
app_env <- new.env(parent = globalenv())
sys.source("app.R", envir = app_env)
cat("[1/9] Loaded Shiny app functions and dataset.\n")

stopifnot(nrow(app_env$profiles) == 120,
          ncol(app_env$X_raw) == 6,
          !anyNA(app_env$X_raw),
          all(app_env$profiles$year == 2024))
cat("[2/9] Data dimensions and imputation checks passed.\n")

z <- app_env$prepare_x(TRUE)
stopifnot(nrow(z) == 120L, ncol(z) == 6L,
          max(abs(colMeans(z))) < 1e-10,
          max(abs(apply(z, 2, sd) - 1)) < 1e-10)
cat("[3/9] Standardization passed.\n")

pc <- app_env$calculate_pca(z)
pv <- app_env$pca_summary(pc)
stopifnot(nrow(pv) == 6L, all(is.finite(pc$x)),
          abs(sum(pv$variance_pct) - 100) < 1e-8)
cat("[4/9] PCA variance and scores passed.\n")

D <- app_env$calculate_k_curve(z, 50L)
km <- app_env$calculate_kmeans(z, 4L, 50L)
stopifnot(identical(as.integer(D$k), 2:6),
          all(is.finite(D$mean_silhouette)),
          length(km$cluster) == 120L,
          length(unique(km$cluster)) == 4L)
cat("[5/9] Silhouette and reproducible K-means fitting passed.\n")

hc <- stats::hclust(stats::dist(z), method = "ward.D2")
g <- stats::cutree(hc, 4L)
stopifnot(length(g) == 120L, length(unique(g)) == 4L)
cat("[6/9] Hierarchical clustering passed.\n")

stopifnot(all(table(app_env$posthoc_values(km$cluster)$cluster) > 0),
          nrow(app_env$posthoc_values(km$cluster)) == 120L)
if (requireNamespace("FactoMineR", quietly = TRUE)) {
  cats <- data.frame(Schooling=app_env$make_tertile(app_env$X_raw$schooling_years),
                     Internet=app_env$make_tertile(app_env$X_raw$internet_access_pct),
                     Manufacturing=app_env$make_tertile(app_env$X_raw$manufacturing_share_pct))
  fit <- FactoMineR::MCA(cats, ncp = 2, graph = FALSE)
  stopifnot(ncol(fit$var$coord) >= 2L,
            all(is.finite(fit$var$coord[, 1:2])))
  cat("[7/9] Post-hoc separation and MCA passed.\n")
} else {
  cat("[7/9] Post-hoc checks passed. MCA skipped (FactoMineR optional).\n")
}
# Extensions for v2.0: hierarchy cut, profiles, and permutation-invariant ARI.
ha <- stats::hclust(stats::dist(z), method = "average")
h3 <- stats::cutree(ha, 3L)
stopifnot(length(unique(h3)) == 3L,
          sum(table(h3)) == 120L,
          all(sort(as.integer(table(h3))) == c(30L, 30L, 60L)))

cut_h <- app_env$hierarchy_cut_height(ha, 3L)
stopifnot(is.finite(cut_h), cut_h > 0,
          identical(as.integer(stats::cutree(ha, h = cut_h)), as.integer(h3)))
raw_profile <- app_env$hierarchy_profile(h3, standardized = FALSE)
z_profile <- app_env$hierarchy_profile(h3, standardized = TRUE)
stopifnot(nrow(raw_profile) == 3L, nrow(z_profile) == 3L,
          ncol(raw_profile) == 7L, all(is.finite(as.matrix(z_profile[,-1]))))

# ARI must ignore a relabeling of the SAME partition.
stopifnot(abs(app_env$hierarchy_ari(g, as.integer(factor(g, levels = rev(sort(unique(g)))))) - 1) < 1e-12)
stopifnot(abs(app_env$hierarchy_ari(km$cluster, g)) <= 1 + 1e-12)
cat("[8/9] Hierarchical cut, group profiles, and ARI checks passed.\n")

# v2.1 regression: reproduce the former row-name recycling warning under
# warning-as-error mode, across all supported linkage, k and scaling choices.
# This checks exactly the tabular data consumed by the hierarchical heatmap.
original_warn <- getOption("warn")
tryCatch({
  options(warn = 2)
  for (use_scaling in c(TRUE, FALSE)) {
    xx <- app_env$prepare_x(use_scaling)
    for (linkage in c("average", "ward.D2", "complete", "single")) {
      tree <- stats::hclust(stats::dist(xx), method = linkage)
      for (number_of_groups in 2:6) {
        groups <- stats::cutree(tree, k = number_of_groups)
        long_data <- app_env$hierarchy_heatmap_data(groups)
        stopifnot(nrow(long_data) == 6L * number_of_groups,
                  all(c("group", "indicator", "mean_z") %in% names(long_data)),
                  length(unique(long_data$group)) == number_of_groups,
                  length(unique(long_data$indicator)) == 6L,
                  all(is.finite(long_data$mean_z)),
                  !anyNA(long_data$indicator),
                  is.null(rownames(long_data)) ||
                    identical(rownames(long_data), as.character(seq_len(nrow(long_data)))))
      }
    }
  }
  # Also check the exact ggplot operation on the former warning-producing data.
  example_data <- app_env$hierarchy_heatmap_data(h3)
  check_plot <- ggplot2::ggplot(example_data,
                 ggplot2::aes(indicator, group, fill = mean_z)) +
    ggplot2::geom_tile(color = "white")
  stopifnot(nrow(ggplot2::ggplot_build(check_plot)$data[[1]]) == 18L)
}, finally = options(warn = original_warn))
cat("[9/9] Hierarchical heatmap (40 settings) builds without row-name warnings.\n")
cat("\nAll available computational smoke tests passed.\n")
cat("Note: this is not a substitute for viewing all tabs in a browser.\n")


# v2.2 | Random scenario generator: fixed schema, deterministic seeds,
# distinct scenario structures, and no external labels used for fitting.
options(warn = 2)
all_scenarios <- setdiff(app_env$preset_modes, "reference")
reference <- app_env$prepare_bundle(app_env$reference_bundle)
stopifnot(nrow(reference$profiles) == 120L,
          ncol(reference$x_raw) == 6L,
          identical(reference$profiles$region_id, app_env$profiles$region_id))

set.seed(90210)
pre_rng <- get(".Random.seed", envir = .GlobalEnv)
example_a <- app_env$simulate_profiles("four_clear", 123L, noise = 1)
post_rng <- get(".Random.seed", envir = .GlobalEnv)
stopifnot(identical(pre_rng, post_rng),
          identical(example_a$profiles, app_env$simulate_profiles("four_clear", 123L, 1)$profiles),
          !identical(example_a$profiles, app_env$simulate_profiles("four_clear", 124L, 1)$profiles))
cat("[10/12] Reference untouched; simulation seeded and RNG-state safe.\n")

results <- list()
for (scenario in all_scenarios) {
  for (ss in c(123L, 124L)) {
    b <- app_env$prepare_bundle(app_env$simulate_profiles(scenario,ss,noise = 1))
    stopifnot(nrow(b$profiles) == 120L, ncol(b$x_raw) == 6L,
              all(b$profiles$year == 2024L),
              all(app_env$features %in% names(b$profiles)),
              !anyNA(b$x_raw), all(is.finite(as.matrix(b$x_raw))),
              nrow(b$posthoc) == 120L,
              !any(app_env$features %in% c("poverty_rate_pct", "economic_zone")),
              identical(b$profiles$region_id,b$posthoc$region_id))
    xx <- app_env$prepare_x(TRUE, b$x_raw)
    pca <- app_env$calculate_pca(xx)
    kmode <- app_env$calculate_kmeans(xx, 4L, 20L)
    score <- app_env$calculate_k_curve(xx, 20L)
    stopifnot(nrow(score) == 5L, all(score$k == 2:6),
              all(is.finite(score$mean_silhouette)),
              all(score$mean_silhouette >= -1),
              all(score$mean_silhouette <= 1),
              nrow(app_env$make_clusters_data(pca,kmode,b$profiles)) == 120L)
    h <- stats::cutree(stats::hclust(stats::dist(xx)),k = 3L)
    ht <- app_env$hierarchy_heatmap_data(h,b$x_raw)
    stopifnot(nrow(ht) == 18L,all(is.finite(ht$mean_z)))
    ph <- app_env$posthoc_values(kmode$cluster,b$profiles,b$posthoc)
    stopifnot(nrow(ph) == 120L, all(is.finite(ph$poverty_2025)))
    results[[paste(scenario,ss,sep = ":")]] <- score$mean_silhouette
  }
}
stopifnot(length(results) == length(all_scenarios)*2,
          length(unique(vapply(results, function(x) paste(round(x,3),collapse = ","), character(1)))) > 1L)
cat("[11/12] All five scenarios at two seeds: PCA, K-means, silhouette, hierarchy, post-hoc passed.\n")

# Silhouette must vary when the data generation process changes, even though
# the dataset dimensions and evaluation candidates k=2:6 remain identical.
best <- vapply(results, function(x) 1L + which.max(x), integer(1))
cat("Silhouette-preferred k by simulated scenario / seed (diagnostic only):\n")
print(data.frame(scenario_seed = names(best), preferred_k = unname(best)), row.names = FALSE)
cat("[12/12] Scenario sensitivity diagnostics available for classroom teaching.\n")
options(warn = original_warn)
cat("\nExtended v2.2 simulation checks passed.\n")


# v3.0 | All adjustable DGP families, flexible n/K, parameter sensitivity and
# true-group post-hoc audit. This block is intentionally warning-sensitive.
cat("\n[13/19] Checking configurable DGP families and parameter values...\n")
params <- list(n=120, k=4, separation=2, sd=.65, rho=.15,
               imbalance=4, anisotropy=3)
assert_model_input <- function(bundle, nn, k_expected) {
  b <- app_env$prepare_bundle(bundle)
  stopifnot(nrow(b$profiles) == nn, nrow(b$posthoc) == nn,
            all(b$profiles$year == 2024), all(b$posthoc$year == 2025),
            identical(as.character(b$profiles$region_id),
                      as.character(b$posthoc$region_id)),
            ncol(b$x_raw) == 6L, all(is.finite(as.matrix(b$x_raw))),
            identical(names(b$x_raw), app_env$features),
            !any(c("poverty_rate_pct", "economic_zone") %in% names(b$x_raw)),
            nrow(b$dgp_parameters) == 9L,
            length(b$true_group) == nn)
  if (is.na(k_expected)) stopifnot(all(is.na(b$true_group))) else {
    stopifnot(length(unique(b$true_group)) == k_expected,
              all(tabulate(b$true_group,nbins=k_expected) >= 3))
  }
  xx <- app_env$prepare_x(TRUE, b$x_raw)
  stopifnot(nrow(xx) == nn, ncol(xx) == 6L,
            all(is.finite(xx)), all(is.finite(app_env$calculate_pca(xx)$x)))
  fit <- app_env$calculate_kmeans(xx, 3L, nstart = 10L)
  ss <- app_env$calculate_k_curve(xx, nstart = 10L)
  stopifnot(length(fit$cluster) == nn, nrow(ss) == 5L,
            all(ss$k == 2:6),all(is.finite(ss$mean_silhouette)),
            all(ss$mean_silhouette <= 1),all(ss$mean_silhouette >= -1))
  for (lk in c("average", "ward.D2")) {
    h <- stats::cutree(stats::hclust(stats::dist(xx),method=lk),k=3)
    heat <- app_env$hierarchy_heatmap_data(h,b$x_raw)
    stopifnot(nrow(heat) == 18L,all(is.finite(heat$mean_z)))
  }
  summary <- app_env$posthoc_values(fit$cluster,b$profiles,b$posthoc)
  stopifnot(nrow(summary) == nn,all(is.finite(summary$poverty_2025)))
  if (!is.na(k_expected)) {
    a <- app_env$hierarchy_ari(fit$cluster,b$true_group)
    stopifnot(is.finite(a),a <= 1, a >= -1)
  }
  invisible(TRUE)
}

set.seed(811)
rng_before <- get(".Random.seed",envir=.GlobalEnv)
ex <- app_env$simulate_dgp("dgp_gaussian",seed=123,params=params)
rng_after <- get(".Random.seed",envir=.GlobalEnv)
stopifnot(identical(rng_before,rng_after),
  identical(ex$profiles,
    app_env$simulate_dgp("dgp_gaussian",seed=123,params=params)$profiles),
  !identical(ex$profiles,
    app_env$simulate_dgp("dgp_gaussian",seed=124,params=params)$profiles))
cat("[14/19] Deterministic seed and global RNG preservation: PASS.\n")

for (family in names(app_env$dgp_titles)) {
  for (nn in c(60L, 150L)) {
    pa <- params;pa$n <- nn
    check <- app_env$simulate_dgp(family,seed=123L,params=pa)
    n_truth <- if(family=="dgp_continuous") NA_integer_ else pa$k
    assert_model_input(check,nn,n_truth)
  }
}
cat("[15/19] All 5 DGPs x 2 sample sizes: PCA/K-means/hierarchy/post-hoc PASS.\n")

# Alter each relevant input independently; a structural parameter is genuinely
# operative only in the DGP family to which it applies.
check_parameter_changes <- function(family, changed, value) {
  pa <- params;pa[[changed]] <- value
  a <- app_env$simulate_dgp(family,seed=123,params=params)$profiles
  b <- app_env$simulate_dgp(family,seed=123,params=pa)$profiles
  stopifnot(!identical(a,b))
}
for (fam in names(app_env$dgp_titles)) {
  check_parameter_changes(fam,"separation",3.5)
  check_parameter_changes(fam,"sd",1.7)
  check_parameter_changes(fam,"rho",.65)
}
check_parameter_changes("dgp_gaussian","k",6)
check_parameter_changes("dgp_rings","k",5)
check_parameter_changes("dgp_imbalanced","imbalance",9)
check_parameter_changes("dgp_elliptical","anisotropy",5.5)
cat("[16/19] Every relevant DGP parameter changes the generated data: PASS.\n")

# Designed K exists for mixture/rings but not the latent continuum.
for (fam in c("dgp_gaussian","dgp_elliptical","dgp_imbalanced","dgp_rings")) {
  stopifnot(length(unique(app_env$simulate_dgp(fam,123,params)$true_group)) == 4L)
}
stopifnot(all(is.na(app_env$simulate_dgp("dgp_continuous",123,params)$true_group)))
cat("[17/19] Ground-truth groups withheld / continuous has no designed K: PASS.\n")

# Input validation should reject nonsensical sample sizes, k and correlations.
should_error <- function(expr) inherits(tryCatch(force(expr),error=function(e)e),"error")
bad <- params;bad$n <- 20
stopifnot(should_error(app_env$simulate_dgp("dgp_gaussian",123,bad)))
bad <- params;bad$k <- 7
stopifnot(should_error(app_env$simulate_dgp("dgp_gaussian",123,bad)))
bad <- params;bad$rho <- 1.5
stopifnot(should_error(app_env$simulate_dgp("dgp_gaussian",123,bad)))
cat("[18/19] Parameter validation rejects invalid n, k and rho: PASS.\n")

options(warn=2)
for (family in names(app_env$dgp_titles)) {
  pa <- params
  b <- app_env$prepare_bundle(app_env$simulate_dgp(family,456L,pa))
  for (center_only in c(TRUE,FALSE)) {
    xx <- app_env$prepare_x(!center_only,b$x_raw)
    for (lk in c("average","ward.D2","complete","single")) {
      tree <- stats::hclust(stats::dist(xx),method=lk)
      h <- stats::cutree(tree,k=3)
      hm <- app_env$hierarchy_heatmap_data(h,b$x_raw)
      stopifnot(nrow(hm)==18L,all(is.finite(hm$mean_z)))
    }
  }
}
options(warn=original_warn)
cat("[19/19] Hierarchy heatmaps on all DGPs / linkage / scaling: PASS.\n")
cat("\nAll v3.0 DGP smoke tests passed. Inspect each UI tab as a final visual check.\n")
