# =============================================================================
# WEEK 3 | ECONOMIC PATTERN DISCOVERY LAB
# Interactive unsupervised machine learning: PCA, K-means, hierarchical, MCA
# Instructor: Gigih Fitrianto | Undergraduate Economics workshop
# Version 3.0 | Configurable DGPs, preset scenarios, variable sample size
# =============================================================================
# HOW TO USE
# 1. Place this app.R beside ML3_Regional_Profiles_2024.xlsx.
# 2. Install packages listed in README.md and open app.R in RStudio.
# 3. Click "Run App", or run shiny::runApp("path/to/this/folder").
# 4. Poverty in 2025 and economic_zone NEVER enter fitting or k selection.
# =============================================================================

required_packages <- c("shiny", "readxl", "ggplot2", "cluster", "openxlsx")
not_installed <- required_packages[
  !vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)
]
if (length(not_installed)) {
  stop("Missing required R packages: ", paste(not_installed, collapse = ", "),
       "\nRun install.packages(c(",
       paste(sprintf('"%s"', not_installed), collapse = ", "), "))")
}

library(shiny)
library(ggplot2)

# This file locates its bundled workbook when launched from within its folder.
# If you launch the script from elsewhere, change the following line.
input_file <- file.path(getwd(), "ML3_Regional_Profiles_2024.xlsx")
if (!file.exists(input_file)) {
  stop("Cannot locate ML3_Regional_Profiles_2024.xlsx in: ", getwd(),
       "\nRun the app from the extracted folder.")
}

features <- c("grdp_pc_million_idr", "unemployment_pct", "schooling_years",
              "internet_access_pct", "manufacturing_share_pct",
              "investment_pc_million_idr")
feature_labels <- c("GRDP per capita", "Unemployment", "Schooling",
                    "Internet access", "Manufacturing", "Investment per capita")
names(feature_labels) <- features
base_seed <- 20261104L

profiles <- as.data.frame(readxl::read_excel(input_file, sheet = "Profiles_2024"))
needed <- c("region_id", "economic_zone", "year", features)
if (!all(needed %in% names(profiles))) {
  stop("The Profiles_2024 worksheet lacks: ",
       paste(setdiff(needed, names(profiles)), collapse = ", "))
}
if (nrow(profiles) != 120 || anyDuplicated(profiles$region_id) ||
    !all(profiles$year == 2024)) {
  stop("Expected 120 unique synthetic regions for year 2024.")
}
for (v in features) {
  profiles[[v]] <- as.numeric(profiles[[v]])
  if (any(!is.finite(profiles[[v]]) & !is.na(profiles[[v]]))) {
    stop("Non-finite value in feature: ", v)
  }
}

# =============================================================================
# v2.2 | SIMULATED DATASETS FOR CLASSROOM EXPERIMENTS
# The original workbook remains unchanged and reproducible.
# All simulated variables follow the identical six-feature schema.
# =============================================================================
scenario_titles <- c(
  reference = "Original Week 3 dataset (reference)",
  two_clear = "Two clearly separated groups",
  four_clear = "Four clearly separated groups",
  four_overlap = "Four overlapping groups",
  uneven = "Four unequal-sized groups",
  gradient = "Continuous economic gradient (no designed groups)"
)

# Fixed classroom presets are preserved from v2.2; parameterized DGPs are new.
preset_modes <- names(scenario_titles)
dgp_titles <- c(
  dgp_gaussian = "DGP: Gaussian mixture (balanced clusters)",
  dgp_elliptical = "DGP: Elliptical/correlated Gaussian mixture",
  dgp_imbalanced = "DGP: Gaussian mixture with unequal group sizes",
  dgp_continuous = "DGP: Continuous latent economic gradient",
  dgp_rings = "DGP: Non-convex concentric economic patterns"
)
scenario_titles <- c(scenario_titles, dgp_titles)
is_dgp_mode <- function(mode) is.character(mode) && length(mode) == 1L &&
  !is.na(mode) && mode %in% names(dgp_titles)

# The same six economic indicators are produced under every DGP. Group labels
# and simulated 2025 poverty are generated separately for post-hoc use only.
# Each DGP uses one explicit seed and returns metadata to reproduce the sample.
validate_dgp_params <- function(params, seed) {
  required <- c("n", "k", "separation", "sd", "rho", "imbalance", "anisotropy")
  if (!all(required %in% names(params))) stop("Missing DGP parameters.")
  for (v in required) {
    if (length(params[[v]]) != 1L || !is.numeric(params[[v]]) ||
        !is.finite(params[[v]])) stop("DGP parameter must be finite: ", v)
  }
  if (params$n != as.integer(params$n) || params$n < 60 || params$n > 300)
    stop("DGP sample size must be an integer between 60 and 300.")
  if (params$k != as.integer(params$k) || params$k < 2 || params$k > 6)
    stop("Designed k must be an integer from 2 to 6.")
  if (params$separation < .3 || params$separation > 5 ||
      params$sd < .15 || params$sd > 3 ||
      params$rho < 0 || params$rho > .9 ||
      params$imbalance < 1 || params$imbalance > 10 ||
      params$anisotropy < 1 || params$anisotropy > 6)
    stop("One or more DGP parameters are outside the supported ranges.")
  if (length(seed) != 1L || !is.finite(seed) || seed < 1 ||
      seed > 9999999 || seed != as.integer(seed)) stop("Invalid random seed.")
  invisible(TRUE)
}

# Put designed centers in a 6D simplex, with an orthogonal rotation so they
# are not mechanically aligned with one raw economic indicator. Pairwise
# distances of the unscaled centers are equal to 1.
dgp_simplex_centers <- function(k) {
  M <- diag(k) - matrix(1/k, k, k)
  U <- svd(M)$u[, seq_len(k-1), drop = FALSE] / sqrt(2)
  C <- matrix(0, nrow = k, ncol = 6)
  C[,seq_len(k-1)] <- U
  Q <- qr.Q(qr(matrix(rnorm(36), nrow = 6)))
  C %*% Q
}

# Gaussian innovations with a valid 6 x 6 equicorrelation matrix.
dgp_innovations <- function(n, sigma, rho, anisotropy = 1) {
  Sigma <- (1 - rho) * diag(6) + rho * matrix(1, 6, 6)
  E <- matrix(rnorm(n*6), nrow = n) %*% chol(Sigma)
  scales <- if (anisotropy > 1) c(anisotropy, 1, 1, 1.35, 1, 1)
    else rep(1, 6)
  scales <- scales / sqrt(mean(scales^2))
  sweep(E, 2, sigma * scales, `*`)
}

# Generate mixture membership with at least 3 observations per group, for
# interpretable cluster-size diagnostics even at the minimum n=60.
dgp_group_sizes <- function(n, k, ratio = 1) {
  weights <- seq(0, 1, length.out = k)
  weights <- (ratio ^ weights) / sum(ratio ^ weights)
  sizes <- 3L + tabulate(sample.int(k, n-3L*k, replace=TRUE, prob=weights), nbins=k)
  as.integer(sizes)
}

simulate_dgp <- function(dgp, seed = 123L, params = list(
    n = 120, k = 4, separation = 2, sd = .65, rho = .15,
    imbalance = 4, anisotropy = 3)) {
  if (!is_dgp_mode(dgp)) stop("Unknown parameterized DGP: ", dgp)
  validate_dgp_params(params, seed)
  n <- as.integer(params$n); k <- as.integer(params$k)
  with_sample_seed(seed, {
    mixture <- dgp != "dgp_continuous"
    if (mixture) {
      if (dgp == "dgp_imbalanced") {
        counts <- dgp_group_sizes(n, k, params$imbalance)
      } else {
        counts <- rep(n %/% k, k)
        if (n %% k > 0L) counts[seq_len(n %% k)] <- counts[seq_len(n %% k)] + 1L
      }
      groups <- rep(seq_len(k), times = counts)
      groups <- sample(groups, n, replace=FALSE)
    } else groups <- rep(NA_integer_, n)
    local_anisotropy <- if (dgp == "dgp_elliptical") params$anisotropy else 1
    E <- dgp_innovations(n, params$sd, params$rho, local_anisotropy)
    if (dgp %in% c("dgp_gaussian", "dgp_elliptical", "dgp_imbalanced")) {
      centers <- dgp_simplex_centers(k)
      # Pairwise center distances are 2.5 * separation before added noise.
      Z <- 2.5 * params$separation * centers[groups, , drop=FALSE] + E
    } else if (dgp == "dgp_continuous") {
      U <- qr.Q(qr(matrix(rnorm(36),6,6)))[,1:2,drop=FALSE]
      t <- runif(n, -2, 2)
      q <- rnorm(n, sd = .55)
      Z <- params$separation * outer(t, U[,1]) +
           0.6*outer(q, U[,2]) + E
    } else if (dgp == "dgp_rings") {
      angle <- runif(n,0,2*pi)
      radius <- 0.75 + (groups - 1) * params$separation / max(1,k-1)
      U <- qr.Q(qr(matrix(rnorm(36),6,6)))[,1:2,drop=FALSE]
      latent <- cbind(radius*cos(angle),radius*sin(angle))
      Z <- 2.8*(latent %*% t(U)) + E
    } else stop("Unsupported DGP.")

    # Use the identical 2024 six-feature schema in readable economic units.
    # Bounds introduce clipping at extreme parameters, an intentional reminder
    # that metric and scaling choices affect the resulting clusters.
    clip <- function(x,lo,hi) pmax(lo,pmin(hi,x))
    df <- data.frame(
      region_id = sprintf("DGP%03d",seq_len(n)),
      economic_zone = if (mixture) paste0("Designed group ",groups) else
        rep("Continuous pattern (no true clusters)",n),
      year = rep(2024L,n),
      grdp_pc_million_idr = round(clip(80+18*Z[,1],10,200),2),
      unemployment_pct = round(clip(6.5+1.1*Z[,2],0.4,19),2),
      schooling_years = round(clip(10.6+.85*Z[,3],3.5,17.5),2),
      internet_access_pct = round(clip(74+9*Z[,4],3,99),2),
      manufacturing_share_pct = round(clip(21.6+6.8*Z[,5],1,58),2),
      investment_pc_million_idr = round(clip(13.3+3.6*Z[,6],.4,44),2),
      stringsAsFactors=FALSE
    )
    post_poverty <- clip(18-.045*df$grdp_pc_million_idr +
      .44*df$unemployment_pct-.5*(df$schooling_years-10) -
      .055*(df$internet_access_pct-70)+rnorm(n,0,1.7),.3,45)
    post <- data.frame(region_id=df$region_id,year=rep(2025L,n),
                       poverty_rate_pct=round(post_poverty,2))
    metadata <- data.frame(
      parameter = c("DGP", "sample_size_n", "designed_group_count_k",
        "center_separation", "noise_sd", "within_feature_correlation_rho",
        "group_imbalance_ratio", "anisotropy_ratio", "random_seed"),
      value = c(dgp, params$n, if (mixture) params$k else "not applicable",
        params$separation, params$sd, params$rho,
        if (dgp == "dgp_imbalanced") params$imbalance else "not used",
        if (dgp == "dgp_elliptical") params$anisotropy else "not used", seed),
      stringsAsFactors=FALSE)
    list(profiles = df, posthoc = post, scenario=dgp,
         scenario_label=unname(dgp_titles[[dgp]]),seed=as.integer(seed),
         noise=params$sd,is_simulated=TRUE,
         dgp_parameters = metadata,
         true_group = if (mixture) as.integer(groups) else rep(NA_integer_,n))
  })
}

# Pure with respect to R's global random-number stream: each generated sample
# is reproduced from its explicit seed, without changing the RNG used elsewhere.
with_sample_seed <- function(seed, expr) {
  had_rng <- exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE)
  if (had_rng) old_rng <- get(".Random.seed", envir = .GlobalEnv)
  on.exit({
    if (had_rng) assign(".Random.seed", old_rng, envir = .GlobalEnv)
    else if (exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE))
      rm(".Random.seed", envir = .GlobalEnv)
  }, add = TRUE)
  set.seed(as.integer(seed))
  force(expr)
}

# Transparent six-dimensional group centers, constructed for teaching only.
# Positions reflect stylized economic indicator patterns, not real regions.
scenario_centers <- rbind(
  c(-1.6,  1.2, -1.4, -1.5, -0.9, -1.3),
  c(-0.35, 0.7, -0.2, -0.5,  1.7, -0.3),
  c( 0.7, -0.6,  0.65, 1.05, -0.6, 0.6),
  c( 1.7, -1.1,  1.5,  1.45,  1.2, 1.5)
)

simulate_profiles <- function(scenario, seed = 123L, noise = 1,
                              n = 120L) {
  stopifnot(scenario %in% setdiff(preset_modes, "reference"),
            length(seed) == 1L, is.finite(seed), seed >= 1,
            is.finite(noise), noise > 0, n == 120L)
  with_sample_seed(seed, {
    if (scenario == "two_clear") {
      labels <- rep(1:2, each = n/2)
      centers <- rbind(c(-1.6, 1.25,-1.4,-1.5,-0.65,-1.35),
                       c( 1.6,-1.25, 1.4, 1.5, 0.65, 1.35))
      Z <- centers[labels, , drop = FALSE] +
           matrix(rnorm(n*6, sd = 0.48*noise), nrow = n)
    } else if (scenario == "four_clear") {
      labels <- rep(1:4, each = n/4)
      Z <- 1.45*scenario_centers[labels, , drop = FALSE] +
           matrix(rnorm(n*6, sd = .48*noise), nrow = n)
    } else if (scenario == "four_overlap") {
      labels <- rep(1:4, each = n/4)
      Z <- .55*scenario_centers[labels, , drop = FALSE] +
           matrix(rnorm(n*6, sd = 1.05*noise), nrow = n)
    } else if (scenario == "uneven") {
      labels <- rep(1:4, times = c(68, 26, 16, 10))
      Z <- 1.35*scenario_centers[labels, , drop = FALSE] +
           matrix(rnorm(n*6, sd = .65*noise), nrow = n)
    } else if (scenario == "gradient") {
      labels <- rep(NA_integer_, n)
      t <- runif(n, min = -2.1, max = 2.1)
      secondary <- rnorm(n, sd = .6)
      Z <- outer(t, c(1, -.75, .9, 1.05, .08, 1.0)) +
           outer(secondary, c(.10, .30, -.12, -.08, 1.4, .12)) +
           matrix(rnorm(n*6, sd = .60*noise), nrow = n)
    } else stop("Unknown data scenario.")
    # Break contiguous ordering so regions are not grouped by their row index.
    perm <- sample.int(n)
    Z <- Z[perm, , drop = FALSE]
    labels <- labels[perm]

    # Translate stylized latent values to plausible, explicitly simulated units.
    # Truncation means z-score geometry is NOT preserved exactly by this mapping.
    clip <- function(x, lo, hi) pmax(lo, pmin(hi, x))
    df <- data.frame(
      region_id = sprintf("SIM%03d", seq_len(n)),
      economic_zone = if (scenario == "gradient")
         rep("Continuous pattern (no groups)", n)
         else paste0("Designed group ", labels),
      year = rep(2024L, n),
      grdp_pc_million_idr = round(clip(80 + 18*Z[,1], 10, 190), 2),
      unemployment_pct = round(clip(6.5 + 1.1*Z[,2], .4, 17), 2),
      schooling_years = round(clip(10.6 + .90*Z[,3], 4, 16), 2),
      internet_access_pct = round(clip(74 + 10*Z[,4], 5, 99), 2),
      manufacturing_share_pct = round(clip(21.6 + 7.2*Z[,5], 1, 55), 2),
      investment_pc_million_idr = round(clip(13.3 + 3.5*Z[,6], .5, 37), 2),
      stringsAsFactors = FALSE
    )
    # A separately generated illustration of a withheld outcome, for optional
    # post-hoc interpretation only. NEVER used for PCA, MCA, k-means or k tuning.
    sim_poverty <- clip(18 - .045*df$grdp_pc_million_idr +
                         .44*df$unemployment_pct -.5*(df$schooling_years - 10) -
                         .055*(df$internet_access_pct - 70) + rnorm(n,0,1.7),
                         .3, 45)
    post <- data.frame(region_id = df$region_id, year = rep(2025L,n),
                       poverty_rate_pct = round(sim_poverty, 2))
    list(profiles = df, posthoc = post,
         scenario = scenario, scenario_label = unname(scenario_titles[[scenario]]),
         seed = as.integer(seed), noise = noise,
         is_simulated = TRUE)
  })
}

reference_bundle <- list(profiles = profiles,
                         posthoc = as.data.frame(readxl::read_excel(
                           input_file, sheet = "Posthoc_2025")),
                         scenario = "reference",
                         scenario_label = unname(scenario_titles[["reference"]]),
                         seed = NA_integer_, noise = NA_real_,
                         is_simulated = FALSE)

impute_six_features <- function(data, variables = features) {
  x <- as.data.frame(data[, variables, drop = FALSE])
  for (v in variables) x[[v]] <- as.numeric(x[[v]])
  meds <- vapply(x, median, numeric(1), na.rm = TRUE)
  stopifnot(all(is.finite(meds)))
  miss <- data.frame(predictor = unname(feature_labels[variables]),
                     missing_count = vapply(x, function(z) sum(is.na(z)), integer(1)))
  for (v in variables) x[[v]][is.na(x[[v]])] <- meds[[v]]
  if (any(vapply(x, sd, numeric(1)) <= 0) ||
      any(!vapply(x, function(z) all(is.finite(z)), logical(1))))
    stop("Invalid or zero-variance simulated predictor.")
  list(x_raw = x, medians = meds, missing_table = miss)
}

prepare_bundle <- function(bundle) {
  checked <- impute_six_features(bundle$profiles)
  c(bundle, checked)
}

# Model input: ONLY six economic predictors. Neither poverty nor economic_zone
# is ever passed into scale(), prcomp(), kmeans(), dist(), hclust(), or MCA().
missing_table <- data.frame(
  predictor = unname(feature_labels),
  missing_count = vapply(profiles[features], function(z) sum(is.na(z)), integer(1))
)
X_raw <- profiles[features]
medians <- vapply(X_raw, function(x) median(x, na.rm = TRUE), numeric(1))
if (!all(is.finite(medians))) stop("A numeric predictor has no finite median.")
for (v in features) X_raw[[v]][is.na(X_raw[[v]])] <- medians[[v]]
if (any(vapply(X_raw, sd, numeric(1)) <= 0)) {
  stop("At least one predictor has zero variance.")
}

prepare_x <- function(standardize = TRUE, x_data = X_raw) {
  # Center always; scale by the sample SD in the standard version.
  ans <- scale(as.matrix(x_data), center = TRUE, scale = standardize)
  colnames(ans) <- features
  ans
}

calculate_pca <- function(X) {
  stats::prcomp(X, center = FALSE, scale. = FALSE)
}

calculate_kmeans <- function(X, k, nstart = 50L) {
  set.seed(base_seed + as.integer(k))
  stats::kmeans(X, centers = as.integer(k), nstart = as.integer(nstart),
                iter.max = 100L)
}

calculate_k_curve <- function(X, nstart = 50L) {
  D <- stats::dist(X)
  do.call(rbind, lapply(2:6, function(k) {
    fit <- calculate_kmeans(X, k, nstart)
    ss <- cluster::silhouette(fit$cluster, D)
    data.frame(k = k, total_withinss = fit$tot.withinss,
               mean_silhouette = mean(ss[, "sil_width"]))
  }))
}

# Rank-based illustrative tertiles, mirroring the optional Week 3 MCA code.
# For genuine categorical economics research, use real category variables.
make_tertile <- function(z) {
  stopifnot(all(is.finite(z)))
  n <- length(z)
  cut(rank(z, ties.method = "average"),
      breaks = c(-Inf, n/3, 2*n/3, Inf),
      labels = c("Low", "Mid", "High"))
}

pca_summary <- function(pc) {
  v <- 100 * pc$sdev^2 / sum(pc$sdev^2)
  data.frame(PC = paste0("PC", seq_along(v)),
             component = seq_along(v),
             variance_pct = v,
             cumulative_pct = cumsum(v))
}

pca_loadings <- function(pc) {
  r <- as.data.frame(pc$rotation)
  data.frame(variable = rownames(r), r,
             row.names = NULL, check.names = FALSE)
}

make_clusters_data <- function(pc, km, profile_data = profiles) {
  data.frame(region_id = profile_data$region_id,
             economic_zone = profile_data$economic_zone,
             PC1 = pc$x[, 1], PC2 = pc$x[, 2],
             cluster = factor(km$cluster), stringsAsFactors = FALSE)
}

cluster_profiles <- function(km, standardized = FALSE, x_data = X_raw) {
  Z <- if (standardized) as.data.frame(prepare_x(TRUE, x_data)) else x_data
  aggregate(Z, by = list(cluster = as.integer(km$cluster)), FUN = mean)
}

# Hierarchical clustering helpers. Group numeric labels have NO intrinsic order.
hierarchy_ari <- function(x, y) {
  if (length(x) != length(y) || length(x) < 2L) stop("Invalid pair of cluster labels")
  T <- table(x, y)
  comb2 <- function(z) z * (z - 1) / 2
  total <- comb2(sum(T))
  row_pairs <- sum(comb2(rowSums(T)))
  col_pairs <- sum(comb2(colSums(T)))
  observed <- sum(comb2(T))
  expected <- row_pairs * col_pairs / total
  maximum <- (row_pairs + col_pairs) / 2
  if (abs(maximum - expected) < 1e-12) {
    return(if (identical(as.integer(x == x[1]), as.integer(y == y[1]))) 1 else NA_real_)
  }
  (observed - expected) / (maximum - expected)
}

hierarchy_cut_height <- function(hc, k) {
  n <- length(hc$order)
  k <- as.integer(k)
  stopifnot(k >= 2, k < n)
  # Height strictly between the (n-k)th and (n-k+1)th merges.
  mean(hc$height[c(n - k, n - k + 1L)])
}

hierarchy_profile <- function(groups, standardized = TRUE, x_data = X_raw) {
  m <- if (standardized) as.data.frame(prepare_x(TRUE, x_data)) else x_data
  aggregate(m, by = list(group = as.integer(groups)), FUN = mean)
}

# Convert a hierarchical cluster profile from wide to long for the heatmap.
# The label lookup is a NAMED vector; data.frame() warns when a 1-element
# named value is recycled alongside multiple group rows. Remove that name
# explicitly before constructing the table, for every feature and group.
hierarchy_heatmap_data <- function(groups, x_data = X_raw) {
  d <- hierarchy_profile(groups, standardized = TRUE, x_data = x_data)
  result <- do.call(rbind, lapply(features, function(v) {
    data.frame(group = factor(d$group),
               indicator = rep(unname(feature_labels[[v]]), nrow(d)),
               mean_z = as.numeric(d[[v]]),
               stringsAsFactors = FALSE,
               row.names = NULL)
  }))
  rownames(result) <- NULL
  result
}

draw_hierarchy <- function(hc, k, method_name) {
  plot(hc, labels = FALSE, hang = -1,
       main = paste0("Hierarchical clustering: ", method_name),
       xlab = paste0(length(hc$order), " synthetic regions (leaves)"), sub = "",
       ylab = "Merge height (linkage-specific)", cex.main = 1.15)
  rect.hclust(hc, k = k, border = "#2d7955")
  abline(h = hierarchy_cut_height(hc, k), col = "#c18e32", lwd = 2, lty = 2)
}

posthoc_values <- function(clusters, profile_data = profiles, post_data = NULL) {
  # Deliberately accessed only when needed for external interpretation/export.
  post <- if (is.null(post_data)) as.data.frame(readxl::read_excel(
    input_file, sheet = "Posthoc_2025")) else post_data
  if (!all(c("region_id", "year", "poverty_rate_pct") %in% names(post))) {
    stop("Posthoc_2025 sheet has missing columns.")
  }
  ids <- match(profile_data$region_id, post$region_id)
  if (anyNA(ids) || anyDuplicated(post$region_id) ||
      !all(post$year[ids] == 2025)) {
    stop("Posthoc_2025 does not match the active synthetic regions.")
  }
  data.frame(region_id = profile_data$region_id,
             cluster = factor(clusters), economic_zone = profile_data$economic_zone,
             poverty_2025 = as.numeric(post$poverty_rate_pct[ids]))
}

format4 <- function(x) format(round(x, 4), nsmall = 4, trim = TRUE)

# A tidy printable snapshot of the current setup, with explicit reference mode.
bundle_metadata <- function(bundle) {
  if (!is.null(bundle$dgp_parameters)) return(bundle$dgp_parameters)
  data.frame(parameter = c("mode", "seed", "noise_multiplier", "sample_size_n"),
             value=c(bundle$scenario,
                     if (bundle$is_simulated) as.character(bundle$seed) else "not used",
                     if (bundle$is_simulated) as.character(bundle$noise) else "not used",
                     nrow(bundle$profiles)), stringsAsFactors=FALSE)
}

# =============================================================================
# UI
# =============================================================================
ui <- navbarPage(
  title = "Week 3 | Economic Pattern Discovery Lab",
  id = "navigation",
  header = tags$head(tags$style(HTML('
    body { background: #f7f9f8; color: #21342b; }
    .navbar-default { background: #173c2d; border: none; }
    .navbar-default .navbar-brand, .navbar-default .navbar-nav > li > a
       { color: #f7fbf9 !important; }
    .navbar-default .navbar-nav > .active > a,
    .navbar-default .navbar-nav > .active > a:focus,
    .navbar-default .navbar-nav > .active > a:hover { background: #287858 !important; }
    .well { background: #edf3ef; border-color: #d9e5dd; border-radius: 9px; }
    .panel-note { background:#edf5f0; padding:13px 15px;
                  border-left:4px solid #367b5a; margin:12px 0; border-radius:4px; }
    .panel-caution { background:#fff7e9; padding:13px 15px;
                     border-left:4px solid #c08a2a; margin:12px 0; border-radius:4px; }
    .result-title { color: #194c37; font-size:21px; font-weight:600; }
    .small-muted { color: #64756b; font-size: 12px; }
    table { font-size: 12px; }
    h2,h3,h4 { color: #173f2e; }
    .btn-primary { background:#276c50; border-color:#276c50; }
    .btn-primary:hover { background:#1c553d; border-color:#1c553d; }
    .shiny-plot-output { background: white; border-radius: 8px; }
  '))),

  tabPanel("Start Here",
    fluidPage(
      h2("What patterns do economic indicators reveal?"),
      p("An interactive undergraduate workshop: fixed reference data or parameterized synthetic economic regions (2024)."),
      div(class = "panel-note", HTML(
        "<b>From supervised to unsupervised:</b> Weeks 1–2 used known poverty outcomes to fit prediction rules. Week 3 discovers patterns in six economic indicators <b>without using any poverty target</b>.")),
      wellPanel(
        h3("Dataset & simulation controls"),
        fluidRow(
          column(5, selectInput("data_mode", "Dataset / data-generating process",
            choices = list(
              "Reference and teaching presets" = stats::setNames(
                 preset_modes, unname(scenario_titles[preset_modes])),
              "Configurable DGPs" = stats::setNames(
                 names(dgp_titles), unname(dgp_titles))),
            selected = "reference")),
          column(3, numericInput("sim_seed", "Reproducible random seed",
                                value = 123L, min = 1, max = 9999999L, step = 1L)),
          column(4, conditionalPanel(
            condition = "input.data_mode && input.data_mode.indexOf('dgp_') !== 0 && input.data_mode !== 'reference'",
            sliderInput("sim_noise", "Preset noise multiplier", min=.5,
                        max=2.5, value=1, step=.25)))
        ),
        conditionalPanel(
          condition = "input.data_mode && input.data_mode.indexOf('dgp_') === 0",
          tags$div(class="panel-note", HTML(
            "<b>Configure the data-generating process:</b> Change the parameters below. Every change regenerates the six economic indicators using the selected seed. There is no hidden fixed cluster structure in Continuous DGP.")),
          fluidRow(
            column(4, numericInput("dgp_n", "Number of regions (n)",
                                   value=120, min=60, max=300, step=10)),
            column(4, conditionalPanel(
              condition="input.data_mode !== 'dgp_continuous'",
              sliderInput("dgp_true_k", "Designed groups (true K)",
                          min=2, max=6, value=4, step=1))),
            column(4, sliderInput("dgp_separation", "Between-group separation / factor strength",
                                  min=.3,max=5,value=2,step=.1))
          ),
          fluidRow(
            column(4, sliderInput("dgp_sd", "Within-group noise SD",
                                  min=.15,max=3,value=.65,step=.05)),
            column(4, sliderInput("dgp_rho", "Correlation in noise (rho)",
                                  min=0,max=.9,value=.15,step=.05)),
            column(4, conditionalPanel(
              condition="input.data_mode === 'dgp_imbalanced'",
              sliderInput("dgp_imbalance", "Largest / smallest group weight",
                          min=1,max=10,value=4,step=.5)),
              conditionalPanel(
                condition="input.data_mode === 'dgp_elliptical'",
                sliderInput("dgp_anisotropy", "Elliptical noise anisotropy",
                            min=1,max=6,value=3,step=.25)))
          ),
          uiOutput("dgp_formula")
        ),
        actionButton("new_sample", "Generate another random sample",
                     icon = icon("refresh"), class = "btn-primary"),
        tags$span(style = "margin-left: 12px;",
                  "Changing the seed or any visible DGP parameter regenerates the dataset."),
        div(class="panel-note", HTML(
          "<b>Reference:</b> fixed 120-region dataset. <b>Presets:</b> predefined 120-region patterns. <b>Configurable DGPs:</b> choose n, designed K, separation, noise, correlation, and applicable shape/group parameters. PCA, K-means, hierarchy, and MCA all update from the same generated data. A high silhouette is not proof of a real economic grouping.")),
        uiOutput("scenario_status"),
        fluidRow(
          column(6, h4("DGP / active data diagnostics"),tableOutput("dgp_diagnostics")),
          column(6, h4("Data generation parameters"),tableOutput("dgp_parameters_table"))),
        downloadButton("download_input_csv", "Download active input data (.csv)"),
        tags$span(style="margin-left:9px;"),
        downloadButton("download_dgp_parameters", "Download DGP parameters (.csv)")
      ),
      h4("Preview: PCA projection of the generated economic indicators"),
      plotOutput("dgp_preview", height="360px"),
      div(class="small-muted", "When the DGP has designed group labels, colors indicate the group that generated each observation. Those labels are never used in PCA or K-means fitting. For a continuous DGP there is no true group label."),
      fluidRow(
        column(5,
          h4("Our shared dataset"),
          tableOutput("dataset_info"),
          div(class = "panel-caution", HTML(
            "<b>Important:</b> <code>economic_zone</code> and 2025 poverty are external labels for <i>post-hoc</i> interpretation only. They never enter PCA, K-means, hierarchical clustering, MCA, or the choice of k.")),
          h4("Preprocessing audit"), tableOutput("missing_table")),
        column(7,
          h4("The six economic indicators"),
          tableOutput("indicator_table"),
          h4("Learning pathway"),
          tags$ol(
            tags$li("PCA: summarize variation in numeric indicators."),
            tags$li("K-means: find groups of regions using all six indicators."),
            tags$li("Hierarchical: explore nested similarity between regions."),
            tags$li("MCA: explore profiles defined by categorical indicators."),
            tags$li("Post-hoc: interpret groups using withheld contextual labels.")),
          div(class="small-muted", "All displayed results are descriptive and cannot establish causal effects."))
      )
    )
  ),

  tabPanel("1. PCA Explorer",
    fluidPage(
      h2("PCA | From six variables to a few dimensions"),
      uiOutput("active_scenario_banner"),
      fluidRow(
        column(4, wellPanel(
          radioButtons("scaling", "Preprocessing for PCA and clustering",
                       choices = c("Standardize each indicator (recommended)" = "scaled",
                                   "Center only (illustrate unit sensitivity)" = "raw"),
                       selected = "scaled"),
          sliderInput("pc_count", "Number of PCs to summarize", min = 1,
                      max = 6, value = 2, step = 1),
          checkboxInput("loadings_arrows", "Show variable loading arrows", TRUE),
          div(class="panel-note", HTML(
            "<b>How to read:</b> Bars show variance explained by each component; the line is cumulative variance. PC1 and PC2 are directions of maximal variation, not economic outcomes.")),
          div(class="panel-caution", "PCA axis signs can flip while the analysis remains equivalent.")
        )),
        column(8,
          h4("Explained variance"), plotOutput("pca_scree", height = "300px"),
          h4("Regional PCA map"), plotOutput("pca_scatter", height = "365px"))
      ),
      fluidRow(
        column(6, h4("Eigenvalues and cumulative variance"), tableOutput("pca_variance_table")),
        column(6, h4("Component loadings"), tableOutput("pca_loadings_table"))
      )
    )
  ),

  tabPanel("2. K-Means Lab",
    fluidPage(
      h2("K-means | Which regions share economic characteristics?"),
      uiOutput("active_scenario_banner"),
      fluidRow(
        column(3, wellPanel(
          sliderInput("k", "Number of clusters (k)", min = 2, max = 6, value = 4,
                      step = 1),
          sliderInput("nstart", "Random initializations", min = 10,
                      max = 100, value = 50, step = 10),
          actionButton("use_best_k", "Use silhouette-best k", class = "btn-primary"),
          p(class="small-muted", "K-means uses a fixed initialization seed for each k. Simulation seed and noise are controlled on Start Here. Clustering uses six indicators, not PCA axes."),
          div(class = "panel-note", HTML(
            "<b>Silhouette:</b> higher values generally indicate more separated groups. <b>Elbow:</b> look for diminishing reductions in within-cluster variation. Neither plot guarantees a universally correct k."))
        )),
        column(9, tabsetPanel(
          tabPanel("Cluster map", plotOutput("kmap", height = "400px")),
          tabPanel("Elbow and silhouette", plotOutput("kcurve", height = "410px")),
          tabPanel("Economic profile heatmap", plotOutput("kheatmap", height = "400px")),
          tabPanel("Compare scenarios",
                   div(class="panel-note", HTML(
                     "<b>Learning exercise:</b> The same silhouette procedure can prefer different k when the underlying economic data change. Each panel uses 120 regions, the currently selected seed/noise settings, and the same scaling and nstart. The original dataset stays fixed.")),
                   plotOutput("scenario_curves", height = "610px"),
                   h4("Silhouette-best k by simulated data pattern"),
                   tableOutput("scenario_best_table")),
          tabPanel("Compare configurable DGPs",
            div(class="panel-note", HTML(
              "<b>Common-parameter comparison:</b> The five adjustable DGP families are generated with the SAME sample size, seed and relevant parameter values. This comparison is an explicit snapshot: click Calculate again after changing any setting. This does not alter the active dataset.")),
            actionButton("run_dgp_compare", "Calculate five DGP silhouette curves", class="btn-primary"),
            plotOutput("dgp_comparison_curves",height="630px"),
            h4("Preferred k by DGP, among k=2 to 6"),
            tableOutput("dgp_best_table")),
          tabPanel("Parameter sensitivity",
            div(class="panel-note", HTML(
              "<b>Controlled experiment:</b> Keep one DGP family, n, designed K, seed and all other parameters constant; vary one parameter over five values. This is a snapshot: click Compare again after changing settings. Simulations are not an economic identification test.")),
            selectInput("sensitivity_parameter", "Parameter to vary",
              choices = c("Center separation / factor strength"="separation",
                "Noise SD"="sd", "Noise correlation (rho)"="rho"),
              selected="separation"),
            actionButton("run_sensitivity", "Compare five parameter values", class="btn-primary"),
            plotOutput("sensitivity_plot",height="500px"),
            h4("Silhouette-best k at each parameter value"),
            tableOutput("sensitivity_best"))
        ))
      ),
      fluidRow(
        column(4, h4("K selection diagnostics"), tableOutput("kdiagnostics")),
        column(4, h4("Cluster sizes"), tableOutput("ksizes")),
        column(4, h4(textOutput("centers_heading", inline = TRUE)),
               tableOutput("kcenters"))
      ),
      div(class="panel-caution", "Cluster labels 1, 2, ... are arbitrary identifiers, not rankings of welfare, poverty or quality.")
    )
  ),

  tabPanel("3. Hierarchical",
    fluidPage(
      h2("Hierarchical clustering | How do regions merge?"),
      uiOutput("active_scenario_banner"),
      div(class="panel-note", HTML(
        "<b>Why this method?</b> Hierarchical clustering builds a nested tree from distances between economic profiles. It uses the same six 2024 indicators as K-means; no poverty outcome or zone label enters the model.")),
      fluidRow(
        column(3, wellPanel(
          selectInput("hmethod", "Linkage method", c("Ward.D2" = "ward.D2",
                    "Complete" = "complete", "Average" = "average",
                    "Single" = "single"), selected = "average"),
          sliderInput("hk", "Cut dendrogram at k groups", min = 2,
                      max = 6, value = 3, step = 1),
          checkboxInput("h_same_k", "Compare with K-means at the same k", TRUE),
          div(class="panel-note", HTML(
            "<b>How to read a dendrogram</b><ol><li>Leaves (bottom): individual regions.</li><li>Branches: merging groups.</li><li>Vertical height: linkage-dependent dissimilarity at merging.</li><li>Dashed gold line: a cut producing the chosen number of groups.</li></ol>")),
          div(class="panel-caution", HTML(
            "<b>Important:</b> Heights are not geographic kilometers and are not directly comparable across linkage methods. Cluster numbers are arbitrary. Ward.D2 and Average can give different trees."))
        )),
        column(9,
          h4("Dendrogram and selected cut"), plotOutput("dendro", height="420px"),
          div(class="small-muted", "Drag the k slider or switch the linkage to see how membership and joining heights change."))
      ),
      fluidRow(
        column(4, h4("Hierarchical group sizes"), tableOutput("hsizes")),
        column(4, h4("Comparison diagnostics"), tableOutput("hsummary")),
        column(4, h4("How to interpret the match"), uiOutput("hinsight"))
      ),
      fluidRow(
        column(6, h4("Regional economic profiles: standardized"),
               plotOutput("hheatmap", height="365px")),
        column(6, h4("Hierarchical groups on PCA dimensions"),
               plotOutput("hpca", height="365px"))
      ),
      fluidRow(
        column(6, h4("Original-unit economic means per group"),
               tableOutput("hprofiles_raw")),
        column(6, h4("K-means versus hierarchical overlap (counts)"),
               tableOutput("hcompare"),
               h4("Percent of each K-means group assigned to hierarchical groups"),
               tableOutput("hcompare_pct"))
      ),
      div(class="panel-note", HTML(
        "<b>Discussion:</b> if hierarchical k=3 merges two of the K-means k=4 groups, that reflects the requested resolution of the tree, not an estimation failure. Choose the <i>same-k</i> checkbox for an algorithm-to-algorithm comparison; compare the membership table and the Adjusted Rand Index (ARI, where 1 means identical partitioning up to relabeling). Cluster profiles explain their economic characteristics, not causal effects."))
    )
  ),

  tabPanel("4. MCA Explorer",
    fluidPage(
      h2("MCA | Explore categories rather than continuous measurements"),
      uiOutput("active_scenario_banner"),
      div(class="panel-caution", HTML(
        "<b>Teaching illustration:</b> Low/Mid/High categories here are created from numeric economic data. Turning continuous variables into categories discards information. For applied MCA, genuine categorical data are preferable.")),
      fluidRow(
        column(4, wellPanel(
          checkboxGroupInput("mca_features", "Categorical indicators to include",
            choices = stats::setNames(names(feature_labels),
                                      unname(feature_labels)),
            selected = c("schooling_years", "internet_access_pct",
                         "manufacturing_share_pct")),
          p(class="small-muted", "Choose at least two indicators. Values are divided into three rank-based categories: Low, Mid, High."),
          div(class="panel-note", "Category-map proximity can suggest category associations. Axis directions are arbitrary. MCA inertia is not PCA variance explained or prediction accuracy."),
          div(class="small-muted", "Optional package: FactoMineR. Install it once to enable MCA."))
        ),
        column(8,
          h4("MCA category factor map"), plotOutput("mca_map", height="390px"),
          h4("Inertia of MCA dimensions"), plotOutput("mca_inertia_plot", height="245px"))
      ),
      fluidRow(
        column(6, h4("MCA inertia"), tableOutput("mca_inertia")),
        column(6, h4("Categories and coordinates"), tableOutput("mca_coords"))
      )
    )
  ),

  tabPanel("5. Post-Hoc Interpretation",
    fluidPage(
      h2("Post-hoc interpretation | What do the discovered groups mean?"),
      uiOutput("active_scenario_banner"),
      div(class="panel-caution", HTML(
        "<b>Not supervised learning:</b> Cluster membership was determined using six 2024 economic indicators. <code>economic_zone</code> and 2025 poverty are added only afterward to describe groups.")),
      fluidRow(
        column(6, h4("2025 poverty by 2024 cluster"),
               plotOutput("post_poverty", height="410px")),
        column(6, h4(textOutput("post_zone_heading", inline = TRUE)),
               plotOutput("post_zone", height="410px"))
      ),
      fluidRow(
        column(6, h4("Poverty summary by cluster"), tableOutput("post_poverty_table")),
        column(6, h4("Cluster vs economic-zone cross-tabulation"),
               tableOutput("post_zone_table"))
      ),
      div(class="panel-note", "Different poverty distributions across clusters are descriptive associations. Do not interpret them as the effect of cluster membership or as forecast accuracy.")
    )
  ),

  tabPanel("6. Export & Guide",
    fluidPage(
      h2("Save and teach from your current interactive analysis"),
      uiOutput("active_scenario_banner"),
      fluidRow(
        column(5, wellPanel(
          h4("Download results"),
          downloadButton("download_excel", "Download full results (.xlsx)",
                         class = "btn-primary"),
          tags$hr(),
          downloadButton("download_clusters_csv", "Download cluster assignments (.csv)"),
          tags$hr(),
          downloadButton("download_input_csv_export", "Download active input dataset (.csv)"),
          tags$hr(),
          downloadButton("download_pca_png", "Download PCA scatter (.png)"),
          tags$br(), tags$br(),
          downloadButton("download_kmap_png", "Download cluster plot (.png)"),
          tags$br(), tags$br(),
          downloadButton("download_dendro_png", "Download hierarchy dendrogram (.png)"),
          tags$br(), tags$br(),
          downloadButton("download_hprofile_png", "Download hierarchical profile heatmap (.png)"),
          tags$br(), tags$br(),
          if (requireNamespace("FactoMineR", quietly = TRUE))
            downloadButton("download_mca_png", "Download MCA map (.png)")
          else tags$p(class="small-muted", "Install FactoMineR to enable MCA downloads."),
          p(class="small-muted", "Downloaded files reflect the current controls. Shiny does not automatically write to a local output folder."))),
        column(7,
          h4("Suggested 45–60 minute Shiny demonstration"),
          tags$ol(
            tags$li("PCA (10–12 min): standardization, scree plot, loadings and PC directions."),
            tags$li("K-means (15–18 min): compare presets, then change DGP K, separation, noise and correlation; inspect silhouette-best k."),
            tags$li("Hierarchical (10–15 min): read cut height, change linkages, inspect profiles and ARI."),
            tags$li("MCA (6–8 min): explore the categorical map and inertia."),
            tags$li("Post-hoc (5–8 min): compare groups with withheld zone labels and poverty.")),
          h4("Discussion questions"),
          tags$ol(
            tags$li("Why do PCA and K-means change after removing standardization?"),
            tags$li("Does the first principal component measure economic welfare?"),
            tags$li("Can two different values of k both be meaningful?"),
            tags$li("Does a close pair of MCA categories imply causation?"),
            tags$li("Why is 2025 poverty kept outside all unsupervised fitting?"),
            tags$li("Does a higher silhouette in simulated data prove that its economic categories are more meaningful?"),
            tags$li("Why can K-means fail to recover concentric-ring groups even with a known true K?"))
        )
      )
    )
  )
)

# =============================================================================
# SERVER
# =============================================================================
server <- function(input, output, session) {
  observeEvent(input$new_sample, {
    updateNumericInput(session, "sim_seed", value =
      if (is.null(input$sim_seed) || input$sim_seed >= 9999999L)
        1L else as.integer(input$sim_seed) + 1L)
  })

  dgp_params <- reactive({
    list(n=as.numeric(input$dgp_n), k=as.numeric(input$dgp_true_k),
         separation=as.numeric(input$dgp_separation),
         sd=as.numeric(input$dgp_sd), rho=as.numeric(input$dgp_rho),
         imbalance=as.numeric(input$dgp_imbalance),
         anisotropy=as.numeric(input$dgp_anisotropy))
  })

  observeEvent(input$data_mode, {
    opts <- c("Center separation / factor strength"="separation",
              "Noise SD"="sd", "Noise correlation (rho)"="rho")
    if (identical(input$data_mode,"dgp_elliptical"))
      opts <- c(opts,"Elliptical anisotropy"="anisotropy")
    if (identical(input$data_mode,"dgp_imbalanced"))
      opts <- c(opts,"Group size ratio"="imbalance")
    updateSelectInput(session,"sensitivity_parameter",choices=opts,
                      selected="separation")
  })

  active_bundle <- reactive({
    req(input$data_mode)
    if (identical(input$data_mode,"reference")) {
      prepare_bundle(reference_bundle)
    } else if (is_dgp_mode(input$data_mode)) {
      req(input$sim_seed)
      prepare_bundle(simulate_dgp(input$data_mode, input$sim_seed, dgp_params()))
    } else {
      req(input$sim_seed, input$sim_noise)
      prepare_bundle(simulate_profiles(scenario=input$data_mode,
                                      seed=input$sim_seed,noise=input$sim_noise))
    }
  })

  output$dgp_formula <- renderUI({
    mode <- input$data_mode
    if (!is_dgp_mode(mode)) return(NULL)
    explanation <- switch(mode,
      dgp_gaussian = "Gaussian mixture: Z = group center + correlated Gaussian noise. Control K, separation, noise and rho.",
      dgp_elliptical = "Elliptical mixture: group center + Gaussian noise with unequal variance along indicators. Try anisotropy at 1 vs 5.",
      dgp_imbalanced = "Unequal-size mixture: group probabilities have a tunable largest-to-smallest ratio; clustering may miss smaller groups.",
      dgp_continuous = "Continuous factor: Z = separation * latent score * loading vector + noise. No true discrete K exists.",
      dgp_rings = "Non-convex rings: observations lie around several concentric latent circles with added noise. K-means tends to prefer convex partitions.")
    div(class="panel-caution",tags$b("DGP interpretation: "),explanation)
  })
  output$dgp_parameters_table <- renderTable({bundle_metadata(active_bundle())},
    striped=TRUE, spacing="xs", rownames=FALSE)
  output$dgp_diagnostics <- renderTable({
    b <- active_bundle()
    res <- data.frame(measure=c("Active regions","Silhouette-best k (2:6)",
      "Maximum silhouette","Designed groups (truth)","ARI vs known groups"),
      result=rep(NA_character_,5))
    scores <- kd(); i <- which.max(scores$mean_silhouette)
    res$result[1] <- as.character(nrow(b$profiles))
    res$result[2] <- as.character(scores$k[i])
    res$result[3] <- sprintf("%.3f",scores$mean_silhouette[i])
    known <- b$true_group
    if (is.null(known) && b$is_simulated && !is_dgp_mode(b$scenario) &&
        b$scenario != "gradient") known <- as.integer(factor(b$profiles$economic_zone))
    if (!is.null(known) && all(!is.na(known))) {
      res$result[4] <- as.character(length(unique(known)))
      res$result[5] <- sprintf("%.3f",hierarchy_ari(km()$cluster,known))
    } else {
      res$result[4] <- "No designed discrete groups"
      res$result[5] <- "Not applicable"
    }
    res
  },striped=TRUE,spacing="xs",rownames=FALSE)

  model_x <- reactive({
    prepare_x(identical(input$scaling, "scaled"), active_bundle()$x_raw)
  })

  output$scenario_status <- renderUI({
    b <- active_bundle()
    tags$p(class="small-muted", paste0("Active: ",b$scenario_label,
      " | n=",nrow(b$profiles),if (b$is_simulated)
        paste0(" | seed=",b$seed," | noise=",b$noise) else
        " | reference dataset unchanged"))
  })
  output$active_scenario_banner <- renderUI({
    b <- active_bundle()
    tags$div(class=if(b$is_simulated) "panel-caution" else "panel-note",
      if(b$is_simulated) paste0("SIMULATED: ",b$scenario_label,
        " | n=",nrow(b$profiles)," | seed ",b$seed,
        " | within-group noise ",b$noise,
        ". Poverty and designed group labels are withheld from unsupervised fitting.")
      else "REFERENCE MODE: Original Week 3 workbook, n=120. Choose a configurable DGP from Start Here for alternative patterns.")
  })

  # This preview uses PCA fitted on economic indicators only. Designed
  # categories are used ONLY to color points for post-hoc teaching.
  output$dgp_preview <- renderPlot({
    b <- active_bundle()
    model <- calculate_pca(model_x())
    pts <- data.frame(PC1=model$x[,1],PC2=model$x[,2],
                      label=if (!is.null(b$true_group) && all(!is.na(b$true_group)))
                        factor(paste0("Designed ",b$true_group))
                      else if (b$is_simulated && b$scenario != "gradient" &&
                               !is_dgp_mode(b$scenario))
                        factor(b$profiles$economic_zone)
                      else factor("No designed group label"))
    ggplot(pts,aes(PC1,PC2,color=label))+
      geom_point(size=2,alpha=.8)+
      labs(title=paste0("DGP preview: ",b$scenario_label),
        subtitle=paste0("n=",nrow(b$profiles),
          "; colors are post-hoc designed labels (if available)"),
        x="PC1 score",y="PC2 score",color="Designed group")+
      theme_minimal(base_size=11)+theme(legend.position="bottom")
  })

  sensitivity_curves <- eventReactive(input$run_sensitivity, {
    req(is_dgp_mode(input$data_mode))
    params <- dgp_params(); v <- req(input$sensitivity_parameter)
    bounds <- list(separation=c(.3,5),sd=c(.15,3),rho=c(0,.9),
                   imbalance=c(1,10),anisotropy=c(1,6))
    if (!(v %in% names(bounds))) stop("Unsupported sensitivity parameter.")
    values <- seq(bounds[[v]][1],bounds[[v]][2],length.out=5)
    do.call(rbind,lapply(values,function(a){
      p2 <- params; p2[[v]] <- as.numeric(a)
      b <- prepare_bundle(simulate_dgp(input$data_mode,input$sim_seed,p2))
      X <- prepare_x(identical(input$scaling,"scaled"),b$x_raw)
      curve <- calculate_k_curve(X,input$nstart)
      curve$parameter <- v; curve$parameter_value <- a
      curve$dgp <- input$data_mode; curve$n <- nrow(X)
      curve$seed <- input$sim_seed
      curve$designed_k <- params$k
      curve$base_separation <- params$separation
      curve$base_noise_sd <- params$sd
      curve$base_rho <- params$rho
      curve
    }))
  },ignoreInit=TRUE)
  output$sensitivity_plot <- renderPlot({
    d <- sensitivity_curves()
    ggplot(d,aes(k,mean_silhouette,color=factor(round(parameter_value,3)),
                 group=parameter_value))+
      geom_line(linewidth=1)+geom_point(size=2.1)+
      scale_x_continuous(breaks=2:6)+
      labs(title=paste("Sensitivity of silhouette to",unique(d$parameter)),
           subtitle="Same seed, same data-generating family; one parameter varies",
           x="Candidate number of clusters k",y="Mean silhouette",
           color="Value")+theme_minimal(base_size=11)
  })
  output$sensitivity_best <- renderTable({
    d <- sensitivity_curves()
    do.call(rbind,lapply(unique(d$parameter_value),function(v){
      z <- d[d$parameter_value==v,]
      best <- z[which.max(z$mean_silhouette),]
      data.frame(parameter=best$parameter,value=round(v,3),n=best$n,
                 silhouette_best_k=best$k,
                 max_mean_silhouette=round(best$mean_silhouette,3))
    }))
  },striped=TRUE,spacing="xs",rownames=FALSE)

  pc <- reactive(calculate_pca(model_x()))
  pv <- reactive(pca_summary(pc()))
  km <- reactive(calculate_kmeans(model_x(), input$k, input$nstart))
  kd <- reactive(calculate_k_curve(model_x(), input$nstart))
  best_k <- reactive(kd()$k[which.max(kd()$mean_silhouette)])

  # This teaching comparison holds k-means settings constant across datasets.
  # It does not modify the currently selected scenario or cluster assignment.
  comparison_curves <- reactive({
    codes <- preset_modes
    do.call(rbind, lapply(codes, function(mode) {
      bundle <- if (mode == "reference") prepare_bundle(reference_bundle)
        else prepare_bundle(simulate_profiles(mode, input$sim_seed,
                                              input$sim_noise))
      xx <- prepare_x(identical(input$scaling, "scaled"), bundle$x_raw)
      curve <- calculate_k_curve(xx, input$nstart)
      curve$scenario <- unname(scenario_titles[[mode]])
      curve
    }))
  })
  comparison_best <- reactive({
    d <- comparison_curves()
    do.call(rbind, lapply(unique(d$scenario), function(label) {
      sample_d <- d[d$scenario == label, ]
      best <- sample_d[which.max(sample_d$mean_silhouette), , drop = FALSE]
      data.frame(scenario = label, silhouette_best_k = best$k,
                 best_mean_silhouette = round(best$mean_silhouette, 3))
    }))
  })
  # Use an explicit action button: recalculating all five DGP families can
  # involve 25 K-means fits plus silhouette distances at n up to 300.
  dgp_comparison <- eventReactive(input$run_dgp_compare, {
    req(input$sim_seed)
    params <- dgp_params()
    do.call(rbind,lapply(names(dgp_titles),function(mode) {
      b <- prepare_bundle(simulate_dgp(mode,input$sim_seed,params))
      X <- prepare_x(identical(input$scaling,"scaled"),b$x_raw)
      df <- calculate_k_curve(X,input$nstart)
      df$scenario <- unname(dgp_titles[[mode]])
      df$n <- nrow(X)
      df$seed <- input$sim_seed
      df$separation <- params$separation
      df$noise_sd <- params$sd
      df$rho <- params$rho
      df$imbalance <- params$imbalance
      df$anisotropy <- params$anisotropy
      df$designed_k <- params$k
      df
    }))
  },ignoreInit=TRUE)
  output$dgp_comparison_curves <- renderPlot({
    d <- dgp_comparison()
    ggplot(d,aes(k,mean_silhouette)) +
      geom_line(color="#2d7955",linewidth=1) +
      geom_point(color="#c08a2a",size=2.2) +
      facet_wrap(~scenario,ncol=2) +
      scale_x_continuous(breaks=2:6) +
      labs(title="Silhouette behavior across five configurable DGP families",
           subtitle=paste0("Common n=",unique(d$n),
             "; selected parameters; test only k=2 to 6"),
           x="Number of K-means clusters",y="Mean silhouette") +
      theme_minimal(base_size=11)
  })
  output$dgp_best_table <- renderTable({
    d <- dgp_comparison()
    do.call(rbind,lapply(unique(d$scenario),function(lbl) {
      z <- d[d$scenario==lbl,]
      best <- z[which.max(z$mean_silhouette),]
      data.frame(dgp=lbl,n=best$n,best_k=best$k,
                 max_silhouette=round(best$mean_silhouette,3))
    }))
  },striped=TRUE,spacing="xs",rownames=FALSE)

  output$scenario_curves <- renderPlot({
    d <- comparison_curves()
    ggplot(d, aes(k, mean_silhouette)) +
      geom_line(color = "#367b5a", linewidth = 1.05) +
      geom_point(color = "#c08a2a", size = 2.3) +
      facet_wrap(~scenario, ncol = 2) +
      scale_x_continuous(breaks = 2:6) +
      labs(title = "Silhouette curves differ across data-generating scenarios",
           subtitle = "Reference fixed; simulations share seed, noise, scaling and nstart",
           x = "Number of clusters k", y = "Mean silhouette (higher = more separated)") +
      theme_minimal(base_size = 11)
  })
  output$scenario_best_table <- renderTable({comparison_best()},
                                               striped = TRUE, spacing = "xs",
                                               rownames = FALSE)

  observeEvent(input$use_best_k, {
    updateSliderInput(session, "k", value = best_k())
  })

  hcl <- reactive(stats::hclust(stats::dist(model_x()), method = input$hmethod))
  hg <- reactive(stats::cutree(hcl(), k = input$hk))
  compare_k <- reactive(if (isTRUE(input$h_same_k)) input$hk else input$k)
  km_comparator <- reactive(calculate_kmeans(model_x(), compare_k(), input$nstart))
  overlap_counts <- reactive(table(KMeans = km_comparator()$cluster,
                                   Hierarchical = hg()))
  hierarchy_profile_z <- reactive(hierarchy_profile(hg(), TRUE, active_bundle()$x_raw))
  hierarchy_profile_raw <- reactive(hierarchy_profile(hg(), FALSE, active_bundle()$x_raw))
  hierarchy_scores <- reactive(data.frame(PC1 = pc()$x[, 1],
                                           PC2 = pc()$x[, 2],
                                           Hierarchical_Group = factor(hg())))


  # MCA deliberately uses the original numeric indicators and categorizes them.
  mca_inputs <- reactive({
    vals <- input$mca_features
    validate(need(length(vals) >= 2, "Select at least two indicators for MCA."))
    keys <- vals
    if (!all(keys %in% features)) stop("Unknown MCA predictor selected.")
    cats <- lapply(active_bundle()$x_raw[keys], make_tertile)
    names(cats) <- gsub("[[:space:]]+", "", unname(feature_labels[keys]))
    as.data.frame(cats)
  })
  mca <- reactive({
    validate(need(requireNamespace("FactoMineR", quietly = TRUE),
                  "MCA requires the optional FactoMineR package. Install it with install.packages('FactoMineR')."))
    cats <- mca_inputs()
    FactoMineR::MCA(cats, graph = FALSE, ncp = 2)
  })

  mca_coords <- reactive({
    cr <- mca()$var$coord[, 1:2, drop = FALSE]
    labels <- rownames(cr)
    parts <- strsplit(labels, "_")
    data.frame(category = labels,
               indicator = vapply(parts, function(z) z[1], character(1)),
               Dim1 = as.numeric(cr[, 1]), Dim2 = as.numeric(cr[, 2]))
  })
  mca_eigen <- reactive({
    E <- mca()$eig
    data.frame(dimension = paste0("Dim", seq_len(nrow(E))),
               eigenvalue = as.numeric(E[, 1]),
               inertia_pct = as.numeric(E[, 2]),
               cumulative_inertia_pct = as.numeric(E[, 3]))
  })

  scores <- reactive(make_clusters_data(pc(), km(), active_bundle()$profiles))
  post <- reactive(posthoc_values(km()$cluster, active_bundle()$profiles, active_bundle()$posthoc))

  output$dataset_info <- renderTable({
    data.frame(item = c("Data type", "Unit", "Year", "Regions", "Numeric indicators"),
               value = c(if (active_bundle()$is_simulated) "Random simulated cross-section"
                             else "Synthetic regional panel cross-section", "Fictitious region",
                         "2024", nrow(active_bundle()$profiles), length(features)))
  }, striped = TRUE, spacing = "xs", rownames = FALSE)
  output$indicator_table <- renderTable({
    data.frame(indicator = unname(feature_labels),
               variable_in_workbook = features)
  }, striped = TRUE, spacing = "xs", rownames = FALSE)
  output$missing_table <- renderTable({active_bundle()$missing_table},
                                      striped = TRUE, spacing="xs", rownames=FALSE)

  p_scree <- reactive({
    ggplot(pv(), aes(component, variance_pct)) +
      geom_col(fill = "#2f7355", width = .72) +
      geom_line(aes(y = cumulative_pct), group = 1,
                color = "#c18e32", linewidth = 1.05) +
      geom_point(aes(y = cumulative_pct), color = "#c18e32", size = 2.2) +
      scale_x_continuous(breaks = 1:6) +
      labs(x = "Principal component", y = "Variance explained (%)",
           title = "Individual (bars) and cumulative (line) variance") +
      theme_minimal(base_size = 12)
  })
  output$pca_scree <- renderPlot({print(p_scree())})

  p_pc_map <- reactive({
    cc <- data.frame(PC1 = pc()$x[, 1], PC2 = pc()$x[, 2])
    p <- ggplot(cc, aes(PC1, PC2)) +
      geom_point(color = "#25684a", alpha = .74, size = 2.35) +
      geom_hline(yintercept = 0, color = "grey75") +
      geom_vline(xintercept = 0, color = "grey75") +
      labs(title = paste0("PCA scores for ", nrow(active_bundle()$profiles), " synthetic regions"),
           subtitle = "Each point is one region; no poverty outcome used",
           x = paste0("PC1 (", round(pv()$variance_pct[1], 1), "% variance)"),
           y = paste0("PC2 (", round(pv()$variance_pct[2], 1), "% variance)")) +
      theme_minimal(base_size = 12)
    if (isTRUE(input$loadings_arrows)) {
      r <- pc()$rotation[, 1:2, drop = FALSE]
      # Scale directions visually. Loadings are NOT in original score units.
      stretch <- 0.75 * min(diff(range(cc$PC1)), diff(range(cc$PC2))) /
        max(sqrt(rowSums(r^2)))
      arrow_data <- data.frame(variable = unname(feature_labels),
                               a1 = r[,1] * stretch, a2 = r[,2] * stretch)
      p <- p +
        geom_segment(data = arrow_data,
                     aes(x = 0, y = 0, xend = a1, yend = a2),
                     inherit.aes = FALSE, color = "#c28b31",
                     arrow = grid::arrow(length = grid::unit(.16, "cm")),
                     linewidth = .8) +
        geom_text(data = arrow_data,
                  aes(x = a1, y = a2, label = variable),
                  inherit.aes = FALSE, color = "#805b1c", size = 3.2,
                  check_overlap = TRUE, vjust = -.4)
    }
    p
  })
  output$pca_scatter <- renderPlot({print(p_pc_map())})
  output$pca_variance_table <- renderTable({
    d <- pv(); d$variance_pct <- round(d$variance_pct, 2)
    d$cumulative_pct <- round(d$cumulative_pct, 2)
    d[seq_len(input$pc_count),c("PC","variance_pct","cumulative_pct")]
  }, striped = TRUE, spacing="xs", rownames=FALSE)
  output$pca_loadings_table <- renderTable({
    L <- pca_loadings(pc())
    L[, 2:ncol(L)] <- round(L[, 2:ncol(L)], 3)
    L[, c("variable", paste0("PC", seq_len(input$pc_count))), drop = FALSE]
  }, striped = TRUE, spacing="xs", rownames=FALSE)

  p_cluster_map <- reactive({
    ggplot(scores(), aes(PC1, PC2, color = cluster)) +
      geom_point(size = 2.85, alpha = .88) +
      labs(title = paste("K-means regions (k =", input$k, ")"),
           subtitle = "Groups fitted on all six indicators; PCs used only as a 2D display",
           x = paste0("PC1 (", round(pv()$variance_pct[1],1), "%)"),
           y = paste0("PC2 (", round(pv()$variance_pct[2],1), "%)"),
           color = "Cluster") +
      theme_minimal(base_size=12)
  })
  output$kmap <- renderPlot({print(p_cluster_map())})

  p_kcurve <- reactive({
    d <- kd()
    # Faceted view keeps elbow (raw withinSS) and silhouette on their own scales.
    long <- rbind(
      data.frame(k = d$k, value = d$total_withinss, metric = "Within-cluster SS (elbow)"),
      data.frame(k = d$k, value = d$mean_silhouette, metric = "Mean silhouette"))
    ggplot(long, aes(k, value)) +
      geom_line(color = "#2f7355", linewidth = 1.2) +
      geom_point(size = 2.4, color = "#c18e32") +
      facet_wrap(~metric, scales = "free_y", ncol = 1) +
      scale_x_continuous(breaks = 2:6) +
      labs(title = paste("Cluster-count diagnostics | silhouette best k =", best_k()),
           x = "Number of clusters k", y = "Diagnostic value") +
      theme_minimal(base_size = 12)
  })
  output$kcurve <- renderPlot({print(p_kcurve())})

  p_heat <- reactive({
    df <- cluster_profiles(km(), standardized = TRUE, x_data = active_bundle()$x_raw)
    out <- do.call(rbind, lapply(features, function(v) {
      data.frame(cluster = factor(df$cluster),
                 indicator = unname(feature_labels[v]),
                 avg_z = df[[v]])
    }))
    ggplot(out, aes(indicator, cluster, fill = avg_z)) +
      geom_tile(color = "white", linewidth = 1) +
      geom_text(aes(label = sprintf("%.2f", avg_z)), size=3.5) +
      scale_fill_gradient2(low = "#c28b32", mid = "#f7f7f3",
                           high = "#287858", midpoint = 0) +
      labs(title = "Cluster profile: mean standardized indicator",
           subtitle = "Positive means above the full-sample mean",
           x = NULL, y = "Cluster", fill = "Mean z") +
      theme_minimal(base_size = 11) +
      theme(axis.text.x = element_text(angle = 30, hjust = 1))
  })
  output$kheatmap <- renderPlot({print(p_heat())})

  output$kdiagnostics <- renderTable({
    data.frame(k=kd()$k,
               withinSS = round(kd()$total_withinss, 1),
               silhouette = round(kd()$mean_silhouette, 3))
  }, striped=TRUE, spacing="xs", rownames=FALSE)
  output$ksizes <- renderTable({
    data.frame(cluster=names(table(km()$cluster)),
               regions=as.integer(table(km()$cluster)))
  }, striped=TRUE, spacing="xs", rownames=FALSE)
  output$centers_heading <- renderText({
    if (identical(input$scaling, "scaled")) {
      "Cluster centroids (standardized inputs)"
    } else "Cluster centroids (centered original units)"
  })
  output$kcenters <- renderTable({
    # The standard choice is z-scored input; when unscaled, these are centered
    # raw-unit values and the displayed heading warns via the scaling control.
    out <- as.data.frame(km()$centers)
    out <- cbind(cluster = seq_len(nrow(out)), out)
    out[, -1] <- lapply(out[, -1, drop=FALSE], round, digits=2)
    out
  }, striped=TRUE, spacing="xs", rownames=FALSE)

  output$dendro <- renderPlot({
    draw_hierarchy(hcl(), input$hk, input$hmethod)
  })
  output$hsizes <- renderTable({
    dd <- table(hg())
    data.frame(group = names(dd), regions = as.integer(dd))
  }, striped=TRUE, spacing="xs", rownames=FALSE)
  output$hsummary <- renderTable({
    data.frame(item = c("Linkage", "Hierarchical k", "Compared K-means k",
                        "Adjusted Rand Index", "Cut height"),
               value = c(input$hmethod, input$hk, compare_k(),
                         sprintf("%.3f", hierarchy_ari(km_comparator()$cluster, hg())),
                         sprintf("%.3f", hierarchy_cut_height(hcl(), input$hk))))
  }, striped = TRUE, spacing="xs", rownames = FALSE)
  output$hinsight <- renderUI({
    T <- overlap_counts()
    # Build sentence from the overlap, not from the arbitrary names of clusters.
    sentences <- vapply(seq_len(ncol(T)), function(j) {
      by_col <- T[, j]
      src <- paste(rownames(T)[by_col > 0], collapse = ", ")
      paste0("Hierarchical group ", colnames(T)[j], " contains ",
             sum(by_col), " regions from K-means group(s): ", src, ".")
    }, character(1))
    tags$div(class="panel-note", tags$ul(lapply(sentences, tags$li)))
  })
  output$hcompare <- renderTable({
    x <- as.data.frame.matrix(overlap_counts())
    data.frame(KMeans_Group = rownames(x), x, row.names = NULL,
               check.names = FALSE)
  }, striped=TRUE, spacing="xs", rownames=FALSE)
  output$hcompare_pct <- renderTable({
    T <- overlap_counts()
    P <- 100 * prop.table(T, margin = 1)
    data.frame(KMeans_Group = rownames(P),
               round(as.data.frame.matrix(P), 1), row.names = NULL,
               check.names = FALSE)
  }, striped=TRUE, spacing="xs", rownames=FALSE)
  output$hprofiles_raw <- renderTable({
    d <- hierarchy_profile_raw()
    d[, -1] <- lapply(d[, -1, drop=FALSE], round, 2)
    names(d)[-1] <- unname(feature_labels)
    d
  }, striped=TRUE, spacing="xs", rownames=FALSE)
  p_hheat <- reactive({
    z <- hierarchy_heatmap_data(hg(), active_bundle()$x_raw)
    ggplot(z, aes(indicator, group, fill=mean_z)) +
      geom_tile(color="white",linewidth=1) +
      geom_text(aes(label=sprintf("%+.2f", mean_z)),size=3.3) +
      scale_fill_gradient2(low="#c18e32",mid="#f7f7f3",high="#287858",midpoint=0) +
      labs(x=NULL,y="Hierarchical group",fill="Mean z",
           title="Economic characteristics by hierarchical group",
           subtitle="Positive = above the full-sample indicator mean") +
      theme_minimal(base_size=11) +
      theme(axis.text.x=element_text(angle=25,hjust=1))
  })
  output$hheatmap <- renderPlot({print(p_hheat())})
  p_hpca <- reactive({
    ggplot(hierarchy_scores(),aes(PC1,PC2,color=Hierarchical_Group)) +
      geom_point(size=2.8,alpha=.85) +
      labs(title="Hierarchical groups in PCA space",
           subtitle="PCA axes are a display; clustering uses all six economic inputs",
           x=paste0("PC1 (", round(pv()$variance_pct[1],1),"%)"),
           y=paste0("PC2 (", round(pv()$variance_pct[2],1),"%)"),
           color="Group") + theme_minimal(base_size=11)
  })
  output$hpca <- renderPlot({print(p_hpca())})

  p_mca <- reactive({
    cc <- mca_coords()
    ggplot(cc, aes(Dim1, Dim2, color = indicator, label = category)) +
      geom_hline(yintercept = 0, color = "grey75") +
      geom_vline(xintercept = 0, color = "grey75") +
      geom_point(size=3.1) +
      geom_text(vjust = -.8, check_overlap = TRUE, show.legend = FALSE,
                size = 3.5) +
      labs(title="MCA factor map (category coordinates)",
           subtitle="Low/Mid/High are artificial tertiles; not real economic classifications",
           x = paste0("Dim 1 (", round(mca_eigen()$inertia_pct[1],1), "% raw inertia)"),
           y = paste0("Dim 2 (", round(mca_eigen()$inertia_pct[2],1), "% raw inertia)"),
           color="Indicator") +
      theme_minimal(base_size=12)
  })
  output$mca_map <- renderPlot({print(p_mca())})

  p_inertia <- reactive({
    ee <- mca_eigen()
    ggplot(ee, aes(seq_along(inertia_pct), inertia_pct)) +
      geom_col(fill = "#317657", width=.75) +
      scale_x_continuous(breaks = seq_len(nrow(ee))) +
      labs(title="MCA: raw inertia per dimension",
           x="Dimension", y="Inertia (% of total)") +
      theme_minimal(base_size=12)
  })
  output$mca_inertia_plot <- renderPlot({print(p_inertia())})
  output$mca_inertia <- renderTable({
    d <- mca_eigen(); d[, -1] <- lapply(d[,-1,drop=FALSE], round, digits=2)
    d
  }, striped=TRUE, spacing="xs", rownames=FALSE)
  output$mca_coords <- renderTable({
    d <- mca_coords(); d$Dim1 <- round(d$Dim1,3);d$Dim2 <- round(d$Dim2,3);d
  }, striped=TRUE, spacing="xs", rownames=FALSE)

  p_post <- reactive({
    ggplot(post(), aes(cluster, poverty_2025, fill = cluster)) +
      geom_boxplot(alpha=.75, outlier.alpha=.75) +
      labs(title=if (active_bundle()$is_simulated)
             "Simulated 2025 poverty by discovered group" else
             "2025 poverty by 2024 discovered group",
           subtitle="Descriptive comparison; poverty was withheld from fitting",
           x="Cluster based on 2024 economic characteristics",
           y="Synthetic poverty rate in 2025 (%)") +
      theme_minimal(base_size=12) + theme(legend.position="none")
  })
  output$post_poverty <- renderPlot({print(p_post())})
  output$post_zone_heading <- renderText({
    if (active_bundle()$is_simulated)
      "Designed scenario groups versus discovered clusters"
    else
      "External economic-zone labels versus discovered clusters"
  })
  p_zone <- reactive({
    dd <- as.data.frame(table(cluster = post()$cluster,
                              economic_zone = post()$economic_zone))
    ggplot(dd, aes(cluster, Freq, fill=economic_zone)) +
      geom_col() +
      labs(title=if (active_bundle()$is_simulated)
             "Designed scenario labels by discovered cluster" else
             "External zone labels by cluster",
           x="Discovered cluster",y="Number of synthetic regions",
           fill="Economic zone") + theme_minimal(base_size=12)
  })
  output$post_zone <- renderPlot({print(p_zone())})
  output$post_poverty_table <- renderTable({
    d <- post()
    z <- aggregate(d$poverty_2025, list(cluster = d$cluster),
                   function(x) c(n=length(x), mean=mean(x), median=median(x)))
    data.frame(cluster=z$cluster, n=z$x[,"n"],
               mean_poverty_2025=round(z$x[,"mean"],2),
               median_poverty_2025=round(z$x[,"median"],2))
  }, striped=TRUE, spacing="xs", rownames=FALSE)
  output$post_zone_table <- renderTable({
    as.data.frame.matrix(table(cluster=post()$cluster,
                               economic_zone=post()$economic_zone))
  }, striped=TRUE, spacing="xs", rownames=TRUE)

  make_input_csv <- function(file) {
    dat <- active_bundle()$profiles
    dat$scenario_id <- active_bundle()$scenario
    dat$simulation_seed <- if (active_bundle()$is_simulated)
      active_bundle()$seed else NA_integer_
    dat$noise_multiplier <- if (active_bundle()$is_simulated)
      active_bundle()$noise else NA_real_
    if (!is.null(active_bundle()$true_group))
      dat$designed_group_posthoc <- active_bundle()$true_group
    if (!is.null(active_bundle()$dgp_parameters)) {
      for (i in seq_len(nrow(active_bundle()$dgp_parameters))) {
        q <- active_bundle()$dgp_parameters[i,]
        dat[[paste0("DGP_",q$parameter)]] <- as.character(q$value)
      }
    }
    utils::write.csv(dat, file, row.names = FALSE)
  }
  output$download_input_csv <- downloadHandler(
    filename = function() paste0("Week3_Input_", active_bundle()$scenario,
                                  if (active_bundle()$is_simulated)
                                    paste0("_seed", active_bundle()$seed)
                                  else "", ".csv"),
    content = make_input_csv
  )
  output$download_input_csv_export <- downloadHandler(
    filename = function() paste0("Week3_Input_", active_bundle()$scenario,
                                  if (active_bundle()$is_simulated)
                                    paste0("_seed", active_bundle()$seed)
                                  else "", ".csv"),
    content = make_input_csv
  )

  output$download_dgp_parameters <- downloadHandler(
    filename=function() paste0("Week3_DGP_Parameters_",active_bundle()$scenario,".csv"),
    content=function(file) utils::write.csv(bundle_metadata(active_bundle()),
                                            file,row.names=FALSE)
  )
  output$download_clusters_csv <- downloadHandler(
    filename = function() paste0("Week3_Clusters_k",input$k,".csv"),
    content = function(file) {
      x <- cbind(scores(), active_bundle()$x_raw)
      x$data_scenario <- active_bundle()$scenario
      x$sim_seed <- if (active_bundle()$is_simulated) active_bundle()$seed
                        else NA_integer_
      x$sim_noise <- if (active_bundle()$is_simulated) active_bundle()$noise
                        else NA_real_
      if (!is.null(active_bundle()$true_group)) x$designed_group_posthoc <- active_bundle()$true_group
      utils::write.csv(x, file, row.names = FALSE)
    }
  )
  output$download_pca_png <- downloadHandler(
    filename = function() "Week3_PCA_Scores.png",
    content = function(file) ggplot2::ggsave(file, p_pc_map(),
                                             width=10, height=6, dpi=180)
  )
  output$download_kmap_png <- downloadHandler(
    filename = function() paste0("Week3_Cluster_k",input$k,".png"),
    content = function(file) ggplot2::ggsave(file, p_cluster_map(),
                                             width=10, height=6, dpi=180)
  )
  output$download_dendro_png <- downloadHandler(
    filename=function() paste0("Week3_Hierarchical_",input$hmethod,"_k",input$hk,".png"),
    content=function(file){
      grDevices::png(file,width=1600,height=820,res=150)
      on.exit(grDevices::dev.off())
      draw_hierarchy(hcl(),input$hk,input$hmethod)
    }
  )
  output$download_hprofile_png <- downloadHandler(
    filename=function() paste0("Week3_Hierarchical_Profiles_k",input$hk,".png"),
    content=function(file) ggplot2::ggsave(file,p_hheat(),width=11,height=6,dpi=180)
  )
  output$download_mca_png <- downloadHandler(
    filename = function() "Week3_MCA_Category_Map.png",
    content = function(file) ggplot2::ggsave(file, p_mca(),
                                             width=10, height=6, dpi=180)
  )
  output$download_excel <- downloadHandler(
    filename = function() paste0("Week3_Shiny_Results_k",input$k,".xlsx"),
    content = function(file) {
      sheets <- list(
        Read_Me = data.frame(
          item = c("Workshop", "Dataset", "Unit", "Year", "Input indicators",
                   "Scaling", "K-means k", "Hierarchical method", "Hierarchical k",
                   "K-means k for overlap", "ARI", "MCA categorical input",
                   "Poverty/economic_zone", "Caution", "Data scenario", "Simulation seed",
                   "Noise multiplier", "Observation count"),
          value = c("Pattern Discovery: Unsupervised ML",
                    if (active_bundle()$is_simulated) "Randomly simulated in Shiny"
                      else basename(input_file),
                    paste(nrow(active_bundle()$profiles),"fictional regions"), "2024", paste(features,collapse=", "),
                    if(identical(input$scaling,"scaled")) "z-score" else "center only",
                    input$k, input$hmethod, input$hk, compare_k(),
                    sprintf("%.4f", hierarchy_ari(km_comparator()$cluster,hg())),
                    "rank-based Low / Mid / High tertiles for illustration",
                    "post-hoc only, never used in fitting or k selection",
                    "Cluster ID and PCA/MCA axis signs have no ordered meaning",
                    active_bundle()$scenario_label,
                    if (active_bundle()$is_simulated) as.character(active_bundle()$seed)
                      else "Not applicable",
                    if (active_bundle()$is_simulated) as.character(active_bundle()$noise)
                      else "Not applicable",
                    nrow(active_bundle()$profiles))),
        Input_2024 = active_bundle()$profiles,
        DGP_Parameters = bundle_metadata(active_bundle()),
        Missing_Audit = active_bundle()$missing_table,
        PCA_Variance = pv(),
        PCA_Loadings = pca_loadings(pc()),
        PCA_Scores = data.frame(region_id = active_bundle()$profiles$region_id,
                                PC1=pc()$x[,1], PC2=pc()$x[,2]),
        K_Diagnostics = kd(),
        Scenario_Silhouettes = comparison_curves(),
        Scenario_Best_k = comparison_best(),
        Cluster_Assignments = cbind(scores(), active_bundle()$x_raw),
        Cluster_Profile_Raw = cluster_profiles(km(), FALSE, active_bundle()$x_raw),
        Cluster_Profile_Z = cluster_profiles(km(), TRUE, active_bundle()$x_raw),
        Hierarchical_Assignments = data.frame(region_id=active_bundle()$profiles$region_id,
                           KMeans_Compared=km_comparator()$cluster,
                           Hierarchical_Group=hg()),
        Hierarchical_Sizes = data.frame(group=names(table(hg())),
                                         n=as.integer(table(hg()))),
        Hierarchical_Profile_Raw = hierarchy_profile_raw(),
        Hierarchical_Profile_Z = hierarchy_profile_z(),
        Hierarchical_Comparison = data.frame(KMeans_Group=rownames(overlap_counts()),
                          as.data.frame.matrix(overlap_counts()),check.names=FALSE,
                          row.names=NULL),
        Hierarchical_Overlap_Pct = data.frame(KMeans_Group=rownames(overlap_counts()),
                          round(as.data.frame.matrix(100*prop.table(overlap_counts(),1)),1),
                          check.names=FALSE,row.names=NULL),
        Hierarchical_Diagnostics = data.frame(method=input$hmethod,
                           hierarchical_k=input$hk,
                           kmeans_reference_k=compare_k(),
                           cut_height=hierarchy_cut_height(hcl(),input$hk),
                           adjusted_rand_index=hierarchy_ari(km_comparator()$cluster,hg())),
        Posthoc_2025 = post(),
        Withheld_Outcome_Data = active_bundle()$posthoc,
        Economic_Zone_Comparison = as.data.frame.matrix(table(
          Cluster=post()$cluster, EconomicZone=post()$economic_zone))
      )
      if (!is.null(active_bundle()$true_group)) {
        sheets$Designed_Group_Posthoc <- data.frame(
          region_id=active_bundle()$profiles$region_id,
          designed_group=active_bundle()$true_group,
          kmeans_cluster=km()$cluster)
      }
      if (!is.null(input$run_dgp_compare) && input$run_dgp_compare > 0) {
        # This comparison is optional; the workbook otherwise exports active data.
        sheets$DGP_Silhouette_Comparison <- dgp_comparison()
      }
      if (!is.null(input$run_sensitivity) && input$run_sensitivity > 0) {
        sheets$DGP_Parameter_Sensitivity <- sensitivity_curves()
      }
      if (requireNamespace("FactoMineR", quietly=TRUE) &&
          length(input$mca_features) >= 2) {
        sheets$MCA_Inputs <- mca_inputs()
        sheets$MCA_Inertia <- mca_eigen()
        sheets$MCA_Category_Coordinates <- mca_coords()
      }
      wb <- openxlsx::createWorkbook()
      for (n in names(sheets)) {
        openxlsx::addWorksheet(wb,n)
        openxlsx::writeDataTable(wb, sheet=n, x=sheets[[n]],
                                 tableStyle = "TableStyleMedium2")
        openxlsx::freezePane(wb, n, firstRow = TRUE)
        openxlsx::setColWidths(wb,n,cols=seq_len(ncol(sheets[[n]])),widths=20)
      }
      openxlsx::setColWidths(wb,"Read_Me",cols=2,widths=75)
      openxlsx::saveWorkbook(wb, file=file, overwrite=TRUE)
    }
  )
}

shinyApp(ui = ui, server = server)
