# =============================================================================
# WEEK 3 | CLASSROOM SIMPLIFIED R CODE (EXACTLY THE CODE SHOWN ON THE SLIDES)
# Pattern Discovery from Unsupervised Machine Learning
# Instructor: Gigih Fitrianto
# Run from RStudio in the extracted folder with the 2024 input workbook.
# All data are synthetic. PCA and clustering do not use a target outcome.
# =============================================================================

# Install packages once if required:
# install.packages(c("readxl", "ggplot2", "cluster", "openxlsx"))
library(readxl)
library(ggplot2)
input_file <- file.path(getwd(), "ML3_Regional_Profiles_2024.xlsx")
output_dir <- file.path(getwd(), "ML3_Student_Outputs")
if (!dir.exists(output_dir)) dir.create(output_dir, recursive = TRUE)

# ================================================================
# 1. READ THE SAME 2024 REGIONAL ECONOMIC DATA
# ================================================================
# SLIDE_CODE_START: import
profiles <- read_excel(input_file, sheet = "Profiles_2024")
features <- c("grdp_pc_million_idr", "unemployment_pct", "schooling_years",
              "internet_access_pct", "manufacturing_share_pct",
              "investment_pc_million_idr")
print(dim(profiles))    # Expect 120 rows x 9 columns
print(head(profiles, 3))
# SLIDE_CODE_END: import

# ================================================================
# 2. SCALE NUMERIC INDICATORS
# ================================================================
# SLIDE_CODE_START: scale
X <- profiles[, features]
medians <- vapply(X, function(v) median(v, na.rm = TRUE), numeric(1))
for (v in features) X[[v]][is.na(X[[v]])] <- medians[v]
X_scaled <- scale(as.matrix(X))
print(round(colMeans(X_scaled), 3))
print(round(apply(X_scaled, 2, sd), 3))
# SLIDE_CODE_END: scale

# ================================================================
# 3. PRINCIPAL COMPONENT ANALYSIS
# ================================================================
# SLIDE_CODE_START: pca
pca <- prcomp(X_scaled, center = FALSE, scale. = FALSE)
variance <- pca$sdev^2 / sum(pca$sdev^2)
pc_var <- data.frame(component = 1:6, variance_pct = 100*variance,
                     cumulative_pct = cumsum(100*variance))
print(round(100 * variance, 1))
print(round(pca$rotation[, 1:2], 3))
# SLIDE_CODE_END: pca

# ================================================================
# 4. VISUALIZE EXPLAINED VARIANCE
# ================================================================
# SLIDE_CODE_START: scree
p_scree <- ggplot(pc_var, aes(component, variance_pct)) +
  geom_col(fill = "#326B54", width = .7) +
  geom_line(aes(y = cumulative_pct), color = "#C09135", linewidth = 1) +
  geom_point(aes(y = cumulative_pct), color = "#C09135", size = 2) +
  scale_x_continuous(breaks = 1:6) +
  labs(x = "Principal component", y = "Percent (%)",
       title = "Variance explained (bars) and cumulative variance (line)") +
  theme_minimal(base_size = 12)
print(p_scree)
# SLIDE_CODE_END: scree

# ================================================================
# 5. RUN K-MEANS AS A FIRST EXAMPLE
# ================================================================
# SLIDE_CODE_START: kmeans
set.seed(20261104)
km3 <- kmeans(X_scaled, centers = 3, nstart = 50)
print(table(km3$cluster))
print(round(km3$centers, 2))
# SLIDE_CODE_END: kmeans

# ================================================================
# 6. TRY SEVERAL NUMBERS OF CLUSTERS
# ================================================================
# SLIDE_CODE_START: select_k
D <- dist(X_scaled)
k_candidates <- 2:6
k_diagnostics <- do.call(rbind, lapply(k_candidates, function(k) {
  set.seed(20261104 + k)
  fit <- kmeans(X_scaled, centers = k, nstart = 50)
  sil <- cluster::silhouette(fit$cluster, D)
  data.frame(k = k, withinss = fit$tot.withinss,
             avg_silhouette = mean(sil[, "sil_width"]))
}))
best_k <- k_diagnostics$k[which.max(k_diagnostics$avg_silhouette)]
set.seed(20261104 + best_k)
km <- kmeans(X_scaled, centers = best_k, nstart = 50)
print(k_diagnostics)
# SLIDE_CODE_END: select_k

# ================================================================
# 7. PLOT THE FINAL CLUSTERS ON PCA AXES
# ================================================================
# SLIDE_CODE_START: scatter
cluster_profiles <- data.frame(region_id = profiles$region_id,
  economic_zone = profiles$economic_zone, year = profiles$year,
  cluster = km$cluster, PC1 = pca$x[, 1], PC2 = pca$x[, 2], X)
p_clusters <- ggplot(cluster_profiles,
                     aes(PC1, PC2, color = factor(cluster))) +
  geom_point(size = 2.7, alpha = .85) +
  labs(title = "Economic profiles in PCA space",
       subtitle = "Colors: K-means clusters based on all six standardized inputs",
       color = "Cluster") +
  theme_minimal(base_size = 12)
print(p_clusters)
# SLIDE_CODE_END: scatter

# ================================================================
# 8. HIERARCHICAL CLUSTERING
# ================================================================
# SLIDE_CODE_START: hierarchical
hc <- hclust(dist(X_scaled), method = "ward.D2")
plot(hc, labels = FALSE, hang = -1,
     main = "Hierarchical clustering: Ward.D2")
rect.hclust(hc, k = best_k, border = "#326B54")
# SLIDE_CODE_END: hierarchical

# Guided demonstration: average linkage, k=3, as in the Shiny screenshot.
# SLIDE_CODE_START: hierarchical_interpret
hc_avg <- hclust(dist(X_scaled), method = "average")
hc_avg_groups <- cutree(hc_avg, k = 3)
print(table(hc_avg_groups))
print(table(KMeans = km$cluster, Hierarchical = hc_avg_groups))
hc_avg_profile <- aggregate(as.data.frame(X_scaled),
  by = list(group = hc_avg_groups), FUN = mean)
print(round(hc_avg_profile, 2))
# SLIDE_CODE_END: hierarchical_interpret


# The group-profile table uses standardized inputs and contains no poverty target.
# 9. SAVE TABLES AND GRAPHICS (SUPPORTING CODE NOT SHOWN ON THE SLIDES) ------
# No 2025 poverty outcomes were used to fit PCA or K-means.
pca_scores <- data.frame(region_id = profiles$region_id,
                         PC1 = pca$x[, 1], PC2 = pca$x[, 2],
                         cluster = km$cluster)
pca_loadings <- data.frame(feature = features, pca$rotation)
cluster_means <- aggregate(as.data.frame(X),
                           by = list(cluster = km$cluster), FUN = mean)

write.csv(pc_var, file.path(output_dir, "01_pca_variance.csv"), row.names = FALSE)
write.csv(pca_loadings, file.path(output_dir, "02_pca_loadings.csv"), row.names = FALSE)
write.csv(k_diagnostics, file.path(output_dir, "03_k_diagnostics.csv"), row.names = FALSE)
write.csv(pca_scores, file.path(output_dir, "04_pca_cluster_scores.csv"), row.names = FALSE)
write.csv(cluster_means, file.path(output_dir, "05_cluster_profiles.csv"), row.names = FALSE)

ggsave(file.path(output_dir, "01_scree_plot.png"), p_scree,
       width = 9, height = 5, dpi = 180)
ggsave(file.path(output_dir, "02_cluster_scatter.png"), p_clusters,
       width = 9, height = 5, dpi = 180)

png(file.path(output_dir, "03_hierarchical_dendrogram.png"),
    width = 1200, height = 700, res = 150)
plot(hc, labels = FALSE, hang = -1, main = "Hierarchical clustering: Ward.D2")
rect.hclust(hc, k = best_k, border = "#326B54")
dev.off()

openxlsx::write.xlsx(list(
  PCA_Variance = pc_var,
  PCA_Loadings = pca_loadings,
  PCA_Scores = pca_scores,
  K_Selection = k_diagnostics,
  Cluster_Profiles = cluster_means),
  file = file.path(output_dir, "04_ML3_Student_Results.xlsx"),
  overwrite = TRUE)

cat("\nFinished. Selected k =", best_k, "\n")
cat("Outputs saved to:", normalizePath(output_dir), "\n")
cat("Remember: cluster numbers and PCA signs have no fixed meaning.\n")


# 10 | OPTIONAL MCA: CATEGORICAL PROFILES (NOT REQUIRED FOR PCA/CLUSTERING) -----
# PCA and K-means continue to use the ORIGINAL numeric indicators.
# These artificial tertiles are for learning MCA only. Exclude poverty/zone.
if (exists("mca_fit", inherits = FALSE)) rm(mca_fit)
# SLIDE_CODE_START: mca
if (requireNamespace("FactoMineR", quietly = TRUE)) {
  mca_tertile <- function(z) cut(rank(z, ties.method = "average"),
    breaks = c(-Inf, length(z)/3, 2*length(z)/3, Inf),
    labels = c("Low", "Mid", "High"))
  mca_inputs <- data.frame(
    Schooling = mca_tertile(X$schooling_years),
    Internet = mca_tertile(X$internet_access_pct),
    Manufacturing = mca_tertile(X$manufacturing_share_pct))
  mca_fit <- FactoMineR::MCA(mca_inputs, graph = FALSE)
  plot(mca_fit, choix = "var", graph.type = "classic")
} else message("Optional MCA: install.packages('FactoMineR')")
# SLIDE_CODE_END: mca
if (exists("mca_fit", inherits = FALSE)) {
  mca_out_dir <- output_dir
  write.csv(mca_inputs, file.path(mca_out_dir, "23_mca_categorical_inputs.csv"),
            row.names = FALSE)
  write.csv(data.frame(category = rownames(mca_fit$var$coord),
                       mca_fit$var$coord[, 1:2], check.names = FALSE),
            file.path(mca_out_dir, "24_mca_category_coordinates.csv"),
            row.names = FALSE)
  write.csv(data.frame(dimension = seq_len(nrow(mca_fit$eig)),
                       mca_fit$eig),
            file.path(mca_out_dir, "25_mca_inertia.csv"), row.names = FALSE)
  png(file.path(mca_out_dir, "26_mca_category_map.png"),
      width = 1200, height = 750, res = 150)
  plot(mca_fit, choix = "var", graph.type = "classic")
  dev.off()
  cat("Optional MCA outputs saved in:", mca_out_dir, "\n")
}
