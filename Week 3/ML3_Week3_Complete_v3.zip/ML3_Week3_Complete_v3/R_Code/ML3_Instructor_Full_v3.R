# =============================================================================
# WEEK 3 | PATTERN DISCOVERY FROM UNSUPERVISED MACHINE LEARNING
# PCA, K-means and hierarchical clustering for synthetic economic indicators
# Instructor: Gigih Fitrianto | Undergraduate Economics
# =============================================================================
# Context: Same 120 fictional regions and six economic indicators as Weeks 1–2.
# Key difference: NO poverty target is used to fit PCA or clusters.
# Economic zone and 2025 poverty are examined ONLY after model fitting.
# Run in RStudio: source('ML3_Unsupervised_PCA_Clustering.R')
# =============================================================================

# 0 | SETUP -------------------------------------------------------------------
required <- c("readxl", "dplyr", "ggplot2", "openxlsx", "cluster")
missing <- required[!vapply(required, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing)) stop("Install packages: install.packages(c('", paste(missing, collapse = "', '"), "'))")
suppressPackageStartupMessages({
  library(readxl)
  library(dplyr)
  library(ggplot2)
})
input_file <- file.path(getwd(), "ML3_Regional_Profiles_2024.xlsx")
out_dir <- file.path(getwd(), "ML3_outputs")
if (!file.exists(input_file)) stop("Input file not found: ", input_file)
if (!dir.exists(out_dir)) dir.create(out_dir, recursive = TRUE)
set.seed(20261104)

save_fig <- function(p, name, width = 9, height = 5.4) {
  ggplot2::ggsave(file.path(out_dir, name), p, width = width,
                  height = height, dpi = 180, bg = "white")
  print(p)
}
write_csv <- function(d, name) utils::write.csv(d, file.path(out_dir, name), row.names = FALSE)

# 1 | IMPORT: ECONOMIC PROFILES, NO TARGET -------------------------------------
# SLIDE_CODE_START: import
profiles <- read_excel(input_file, sheet = "Profiles_2024")
features <- c("grdp_pc_million_idr", "unemployment_pct", "schooling_years",
              "internet_access_pct", "manufacturing_share_pct",
              "investment_pc_million_idr")
print(dim(profiles))    # Expect 120 rows x 9 columns
print(head(profiles, 3))
# SLIDE_CODE_END: import
stopifnot(nrow(profiles) == 120, !anyDuplicated(profiles$region_id),
          all(profiles$year == 2024), all(features %in% names(profiles)))
# region_id, year, economic_zone, poverty_rate_pct are NOT model features.

# 2 | IMPUTATION AND STANDARDIZATION -------------------------------------------
# SLIDE_CODE_START: scale
X <- profiles[, features]
medians <- vapply(X, function(v) median(v, na.rm = TRUE), numeric(1))
for (v in features) X[[v]][is.na(X[[v]])] <- medians[v]
X_scaled <- scale(as.matrix(X))
print(round(colMeans(X_scaled), 3))
print(round(apply(X_scaled, 2, sd), 3))
# SLIDE_CODE_END: scale
stopifnot(all(is.finite(X_scaled)), all(apply(X_scaled, 2, sd) > 0))
missing_audit <- data.frame(feature = features,
                            missing_before = vapply(profiles[, features],
                              function(x) sum(is.na(x)), integer(1)),
                            median_2024 = unname(medians))
write_csv(missing_audit, "01_missing_values_and_medians.csv")
scaled_features <- data.frame(region_id = profiles$region_id, X_scaled,
                              check.names = FALSE)
write_csv(scaled_features, "02_scaled_economic_indicators.csv")

# 3 | PCA: FIND MAIN AXES OF VARIATION ----------------------------------------
# SLIDE_CODE_START: pca
pca <- prcomp(X_scaled, center = FALSE, scale. = FALSE)
variance <- pca$sdev^2 / sum(pca$sdev^2)
pc_var <- data.frame(component = 1:6, variance_pct = 100*variance,
                     cumulative_pct = cumsum(100*variance))
print(round(100 * variance, 1))
print(round(pca$rotation[, 1:2], 3))
# SLIDE_CODE_END: pca
pc_loadings <- data.frame(feature = rownames(pca$rotation), pca$rotation,
                          check.names = FALSE)
pc_scores <- data.frame(region_id = profiles$region_id,
                         PC1 = pca$x[, 1], PC2 = pca$x[, 2])
write_csv(pc_var, "03_pca_variance.csv")
write_csv(pc_loadings, "04_pca_loadings.csv")
write_csv(pc_scores, "05_pca_scores.csv")

# SLIDE_CODE_START: scree
p_scree <- ggplot(pc_var, aes(component, variance_pct)) +
  geom_col(fill = "#326B54", width = .7) +
  geom_line(aes(y = cumulative_pct), color = "#C09135", linewidth = 1) +
  geom_point(aes(y = cumulative_pct), color = "#C09135", size = 2) +
  scale_x_continuous(breaks = 1:6) +
  labs(x = "Principal component", y = "Percent (%)",
       title = "Variance explained (bars) and cumulative variance (line)") +
  theme_minimal(base_size = 12)
print(p_scree)
# SLIDE_CODE_END: scree
save_fig(p_scree, "06_pca_scree_plot.png")

p_load <- ggplot(pc_loadings, aes(x = PC1, y = PC2, label = feature)) +
  geom_hline(yintercept = 0, color = "grey70") +
  geom_vline(xintercept = 0, color = "grey70") +
  geom_point(size = 3, color = "#326B54") +
  geom_text(hjust = -0.06, vjust = -0.3, size = 3, check_overlap = TRUE) +
  coord_equal() + labs(title = "PCA loadings: direction and strength",
                        subtitle = "Component signs can flip without changing the analysis",
                        x = "Loading on PC1", y = "Loading on PC2") +
  theme_minimal(base_size = 12)
save_fig(p_load, "07_pca_loadings.png", 10, 6)

# 4 | K-MEANS: GROUP SIMILAR ECONOMIC PROFILES ---------------------------------
# The same standardized six features are used for PCA and clustering.
# SLIDE_CODE_START: kmeans
set.seed(20261104)
km3 <- kmeans(X_scaled, centers = 3, nstart = 50)
print(table(km3$cluster))
print(round(km3$centers, 2))
# SLIDE_CODE_END: kmeans

# 5 | CHOOSE k FROM 2–6 USING ELBOW AND AVERAGE SILHOUETTE ---------------------
# A cluster count is a modeling choice, not an objectively known category.
# SLIDE_CODE_START: select_k
D <- dist(X_scaled)
k_candidates <- 2:6
k_diagnostics <- do.call(rbind, lapply(k_candidates, function(k) {
  set.seed(20261104 + k)
  fit <- kmeans(X_scaled, centers = k, nstart = 50)
  sil <- cluster::silhouette(fit$cluster, D)
  data.frame(k = k, withinss = fit$tot.withinss,
             avg_silhouette = mean(sil[, "sil_width"]))
}))
best_k <- k_diagnostics$k[which.max(k_diagnostics$avg_silhouette)]
set.seed(20261104 + best_k)
km <- kmeans(X_scaled, centers = best_k, nstart = 50)
print(k_diagnostics)
# SLIDE_CODE_END: select_k
write_csv(k_diagnostics, "08_k_selection_diagnostics.csv")

p_elbow <- ggplot(k_diagnostics, aes(k, withinss)) +
  geom_line(color = "#326B54", linewidth = 1) +
  geom_point(color = "#326B54", size = 2.5) +
  scale_x_continuous(breaks = k_candidates) +
  labs(title = "Elbow: within-cluster sum of squares",
       subtitle = "Always declines as k grows; inspect the bend, not the absolute minimum",
       x = "Number of clusters (k)", y = "Total within-cluster sum of squares") +
  theme_minimal(base_size = 12)
save_fig(p_elbow, "09_elbow_curve.png")

p_sil <- ggplot(k_diagnostics, aes(k, avg_silhouette)) +
  geom_line(color = "#C09135", linewidth = 1) +
  geom_point(color = "#C09135", size = 2.8) +
  geom_vline(xintercept = best_k, linetype = "dashed", color = "#326B54") +
  scale_x_continuous(breaks = k_candidates) +
  labs(title = "Average silhouette for k = 2 to 6",
       subtitle = "Higher is better; dashed line = selected k for this exercise",
       x = "Number of clusters (k)", y = "Average silhouette") +
  theme_minimal(base_size = 12)
save_fig(p_sil, "10_silhouette_curve.png")

# 6 | INTERPRET CLUSTERS USING PCA AND ECONOMIC INDICATORS ---------------------
# SLIDE_CODE_START: scatter
cluster_profiles <- data.frame(region_id = profiles$region_id,
  economic_zone = profiles$economic_zone, year = profiles$year,
  cluster = km$cluster, PC1 = pca$x[, 1], PC2 = pca$x[, 2], X)
p_clusters <- ggplot(cluster_profiles,
                     aes(PC1, PC2, color = factor(cluster))) +
  geom_point(size = 2.7, alpha = .85) +
  labs(title = "Economic profiles in PCA space",
       subtitle = "Colors: K-means clusters based on all six standardized inputs",
       color = "Cluster") +
  theme_minimal(base_size = 12)
print(p_clusters)
# SLIDE_CODE_END: scatter
write_csv(cluster_profiles, "11_cluster_assignments.csv")
save_fig(p_clusters, "12_pca_cluster_map.png", 9.5, 5.8)

profile_raw <- cluster_profiles %>% group_by(cluster) %>%
  summarise(n = n(), across(all_of(features), mean), .groups = "drop")
profile_std <- as.data.frame(X_scaled)
profile_std$cluster <- km$cluster
profile_std <- profile_std %>% group_by(cluster) %>%
  summarise(across(all_of(features), mean), .groups = "drop")
write_csv(profile_raw, "13_cluster_profiles_original_units.csv")
write_csv(profile_std, "14_cluster_profiles_standardized.csv")

heat_long <- do.call(rbind, lapply(features, function(v)
  data.frame(cluster = factor(profile_std$cluster),
             feature = v, mean_z = profile_std[[v]])))
p_heat <- ggplot(heat_long, aes(feature, cluster, fill = mean_z)) +
  geom_tile(color = "white") +
  geom_text(aes(label = sprintf("%.2f", mean_z)), size = 3) +
  scale_fill_gradient2(low = "#547FA0", mid = "white", high = "#BE8A35",
                       midpoint = 0) +
  labs(title = "Cluster characteristics in standardized units",
       subtitle = "Positive = above the 2024 sample mean for that indicator",
       x = NULL, y = "Cluster", fill = "Mean z-score") +
  theme_minimal(base_size = 11) +
  theme(axis.text.x = element_text(angle = 25, hjust = 1))
save_fig(p_heat, "15_cluster_profile_heatmap.png", 11.5, 5.6)

# 7 | HIERARCHICAL CLUSTERING: ANOTHER WAY TO GROUP REGIONS --------------------
# SLIDE_CODE_START: hierarchical
hc <- hclust(dist(X_scaled), method = "ward.D2")
plot(hc, labels = FALSE, hang = -1,
     main = "Hierarchical clustering: Ward.D2")
rect.hclust(hc, k = best_k, border = "#326B54")
# SLIDE_CODE_END: hierarchical

# Guided demonstration: average linkage, k=3, as in the Shiny screenshot.
# SLIDE_CODE_START: hierarchical_interpret
hc_avg <- hclust(dist(X_scaled), method = "average")
hc_avg_groups <- cutree(hc_avg, k = 3)
print(table(hc_avg_groups))
print(table(KMeans = km$cluster, Hierarchical = hc_avg_groups))
hc_avg_profile <- aggregate(as.data.frame(X_scaled),
  by = list(group = hc_avg_groups), FUN = mean)
print(round(hc_avg_profile, 2))
# SLIDE_CODE_END: hierarchical_interpret

png(file.path(out_dir, "16_hierarchical_dendrogram.png"),
    width = 1200, height = 700, res = 150)
plot(hc, labels = FALSE, hang = -1, main = "Hierarchical clustering: Ward.D2",
     xlab = "Fictitious regions", sub = "2024 economic indicators, standardized")
rect.hclust(hc, k = best_k, border = "#326B54")
dev.off()
# Additional hierarchical interpretation outputs (Average linkage, k=3).
hc_avg_profile_raw <- aggregate(as.data.frame(X),
  by = list(group = hc_avg_groups), FUN = mean)
hc_avg_profile_z <- hc_avg_profile
hc_avg_sizes <- data.frame(group = as.integer(names(table(hc_avg_groups))),
                           n = as.integer(table(hc_avg_groups)))
hc_avg_overlap <- as.data.frame.matrix(table(KMeans = km$cluster,
                                                Hierarchical = hc_avg_groups))
hc_avg_overlap <- data.frame(KMeans_Group = rownames(hc_avg_overlap),
                             hc_avg_overlap, check.names = FALSE, row.names = NULL)
write_csv(hc_avg_sizes, "29_hierarchical_average_group_sizes.csv")
write_csv(hc_avg_profile_raw, "30_hierarchical_average_profiles_raw.csv")
write_csv(hc_avg_profile_z, "31_hierarchical_average_profiles_z.csv")
write_csv(hc_avg_overlap, "32_kmeans_average_overlap.csv")
png(file.path(out_dir, "33_hierarchical_average_k3_dendrogram.png"),
    width = 1500, height = 720, res = 145)
plot(hc_avg, labels=FALSE, hang=-1, main="Average linkage: k = 3",
     xlab="Fictitious regions", sub="2024 economic profiles, standardized")
rect.hclust(hc_avg,k=3,border="#326B54")
dev.off()

hc_groups <- cutree(hc, k = best_k)
hc_comparison <- as.data.frame.matrix(table(KMeans = km$cluster,
                                              Hierarchical = hc_groups))
hc_comparison <- cbind(KMeans = seq_len(nrow(hc_comparison)), hc_comparison)
write_csv(hc_comparison, "17_kmeans_hierarchical_cross_tab.csv")

# 8 | EXTERNAL LABELS AND 2025 OUTCOMES: POSTHOC ONLY --------------------------
# This sheet is loaded AFTER fitting; neither zone nor poverty set the clusters.
posthoc <- read_excel(input_file, sheet = "Posthoc_2025")
posthoc_table <- cluster_profiles %>%
  select(region_id, economic_zone, cluster) %>%
  left_join(posthoc %>% select(region_id, poverty_rate_pct), by = "region_id")
stopifnot(nrow(posthoc_table) == 120, !anyNA(posthoc_table$poverty_rate_pct))
zone_tab <- as.data.frame.matrix(table(cluster = km$cluster,
                                        source_zone = profiles$economic_zone))
zone_tab <- cbind(cluster = seq_len(nrow(zone_tab)), zone_tab)
posthoc_summary <- posthoc_table %>% group_by(cluster) %>%
  summarise(n = n(), mean_poverty_2025 = mean(poverty_rate_pct),
            median_poverty_2025 = median(poverty_rate_pct), .groups = "drop")
write_csv(zone_tab, "18_posthoc_zone_cross_tab.csv")
write_csv(posthoc_summary, "19_posthoc_2025_poverty_summary.csv")

p_post <- ggplot(posthoc_table, aes(factor(cluster), poverty_rate_pct,
                                    fill = factor(cluster))) +
  geom_boxplot(alpha = .7, outlier.alpha = .7) +
  labs(title = "2025 poverty by 2024 cluster: descriptive only",
       subtitle = "2025 poverty was NOT used for PCA, clustering or choosing k",
       x = "2024 economic profile cluster", y = "2025 poverty (%)") +
  theme_minimal(base_size = 12) + theme(legend.position = "none")
save_fig(p_post, "20_posthoc_poverty_by_cluster.png")

# 9 | SAVE EVERYTHING AS EDITABLE DATA IN ONE WORKBOOK ------------------------
# Figures are available as separate high-resolution PNG files.
wb <- openxlsx::createWorkbook()
sheets <- list(
  Read_Me = data.frame(field = c("Data", "Status", "Year", "Features", "Supervised target",
    "PCA", "K-means", "Cluster selection", "Posthoc outcomes", "Cautions"),
    description = c("ML3_Regional_Profiles_2024.xlsx", "Synthetic, fictitious regions",
      "2024 cross-section: 120 regions", paste(features, collapse = ", "),
      "None used to fit PCA/clusters", "prcomp of standardized 2024 indicators",
      "K-means on all six standardized indicators", "Largest mean silhouette for k=2..6",
      "2025 poverty and economic_zone viewed only after clustering",
      "PCA signs and cluster numbers arbitrary; no causal interpretation")),
  Input_2024 = profiles,
  Missing_Audit = missing_audit,
  Standardized_X = scaled_features,
  PCA_Variance = pc_var,
  PCA_Loadings = pc_loadings,
  PCA_Scores = pc_scores,
  K_Selection = k_diagnostics,
  Cluster_Assignments = cluster_profiles,
  Cluster_Profiles_Raw = profile_raw,
  Cluster_Profiles_Z = profile_std,
  Hclust_Comparison = hc_comparison,
  Hier_Average_Sizes = hc_avg_sizes,
  Hier_Average_Profiles_Raw = hc_avg_profile_raw,
  Hier_Average_Profiles_Z = hc_avg_profile_z,
  Kmeans_Average_Overlap = hc_avg_overlap,
  Zone_Posthoc = zone_tab,
  Poverty_2025_Posthoc = posthoc_summary)
for (nm in names(sheets)) {
  openxlsx::addWorksheet(wb, nm)
  openxlsx::writeDataTable(wb, nm, sheets[[nm]], tableStyle = "TableStyleMedium2")
  openxlsx::freezePane(wb, nm, firstRow = TRUE)
  openxlsx::setColWidths(wb, nm, cols = 1:ncol(sheets[[nm]]), widths = 20)
}
openxlsx::setColWidths(wb, "Read_Me", cols = 2, widths = 90)
openxlsx::addWorksheet(wb, "Figures")
openxlsx::writeData(wb, "Figures", "See separate PNG files for all figures.")
for (spec in list(
  list(file = "06_pca_scree_plot.png", row = 3),
  list(file = "10_silhouette_curve.png", row = 32),
  list(file = "12_pca_cluster_map.png", row = 61),
  list(file = "15_cluster_profile_heatmap.png", row = 90))) {
  openxlsx::insertImage(wb, "Figures", file = file.path(out_dir, spec$file),
                        startRow = spec$row, startCol = 1, width = 9, height = 5,
                        units = "in")
}
openxlsx::saveWorkbook(wb, file.path(out_dir, "21_ML3_PCA_Clustering_Results.xlsx"),
                       overwrite = TRUE)
writeLines(capture.output(sessionInfo()), file.path(out_dir, "22_session_info.txt"))
cat("\nDONE | k selected:", best_k, "| PC1 variance (%):",
    round(pc_var$variance_pct[1], 1), "\n")
cat("Outputs:", normalizePath(out_dir), "\n")
cat("REMEMBER: Clusters are descriptive, and 2025 poverty is posthoc only.\n")


# 10 | OPTIONAL MCA: CATEGORICAL PROFILES (NOT REQUIRED FOR PCA/CLUSTERING) -----
# PCA and K-means continue to use the ORIGINAL numeric indicators.
# These artificial tertiles are for learning MCA only. Exclude poverty/zone.
if (exists("mca_fit", inherits = FALSE)) rm(mca_fit)
# SLIDE_CODE_START: mca
if (requireNamespace("FactoMineR", quietly = TRUE)) {
  mca_tertile <- function(z) cut(rank(z, ties.method = "average"),
    breaks = c(-Inf, length(z)/3, 2*length(z)/3, Inf),
    labels = c("Low", "Mid", "High"))
  mca_inputs <- data.frame(
    Schooling = mca_tertile(X$schooling_years),
    Internet = mca_tertile(X$internet_access_pct),
    Manufacturing = mca_tertile(X$manufacturing_share_pct))
  mca_fit <- FactoMineR::MCA(mca_inputs, graph = FALSE)
  plot(mca_fit, choix = "var", graph.type = "classic")
} else message("Optional MCA: install.packages('FactoMineR')")
# SLIDE_CODE_END: mca
if (exists("mca_fit", inherits = FALSE)) {
  mca_out_dir <- out_dir
  write.csv(mca_inputs, file.path(mca_out_dir, "23_mca_categorical_inputs.csv"),
            row.names = FALSE)
  write.csv(data.frame(category = rownames(mca_fit$var$coord),
                       mca_fit$var$coord[, 1:2], check.names = FALSE),
            file.path(mca_out_dir, "24_mca_category_coordinates.csv"),
            row.names = FALSE)
  write.csv(data.frame(dimension = seq_len(nrow(mca_fit$eig)),
                       mca_fit$eig),
            file.path(mca_out_dir, "25_mca_inertia.csv"), row.names = FALSE)
  png(file.path(mca_out_dir, "26_mca_category_map.png"),
      width = 1200, height = 750, res = 150)
  plot(mca_fit, choix = "var", graph.type = "classic")
  dev.off()
  cat("Optional MCA outputs saved in:", mca_out_dir, "\n")
}
