# Week 3 Shiny app | lightweight computational checks
# In RStudio, set working directory to the extracted app folder, then run:
# source("smoke_test.R")
# Tests use the same input workbook and functions that the Shiny app uses.

stopifnot(file.exists("app.R"), file.exists("ML3_Regional_Profiles_2024.xlsx"))
stopifnot(all(vapply(c("shiny", "readxl", "ggplot2", "cluster", "openxlsx"),
                     requireNamespace, logical(1), quietly = TRUE)))

# Sourcing an app object does not launch an interactive browser session.
app_env <- new.env(parent = globalenv())
sys.source("app.R", envir = app_env)
cat("[1/9] Loaded Shiny app functions and dataset.\n")

stopifnot(nrow(app_env$profiles) == 120,
          ncol(app_env$X_raw) == 6,
          !anyNA(app_env$X_raw),
          all(app_env$profiles$year == 2024))
cat("[2/9] Data dimensions and imputation checks passed.\n")

z <- app_env$prepare_x(TRUE)
stopifnot(nrow(z) == 120L, ncol(z) == 6L,
          max(abs(colMeans(z))) < 1e-10,
          max(abs(apply(z, 2, sd) - 1)) < 1e-10)
cat("[3/9] Standardization passed.\n")

pc <- app_env$calculate_pca(z)
pv <- app_env$pca_summary(pc)
stopifnot(nrow(pv) == 6L, all(is.finite(pc$x)),
          abs(sum(pv$variance_pct) - 100) < 1e-8)
cat("[4/9] PCA variance and scores passed.\n")

D <- app_env$calculate_k_curve(z, 50L)
km <- app_env$calculate_kmeans(z, 4L, 50L)
stopifnot(identical(as.integer(D$k), 2:6),
          all(is.finite(D$mean_silhouette)),
          length(km$cluster) == 120L,
          length(unique(km$cluster)) == 4L)
cat("[5/9] Silhouette and reproducible K-means fitting passed.\n")

hc <- stats::hclust(stats::dist(z), method = "ward.D2")
g <- stats::cutree(hc, 4L)
stopifnot(length(g) == 120L, length(unique(g)) == 4L)
cat("[6/9] Hierarchical clustering passed.\n")

stopifnot(all(table(app_env$posthoc_values(km$cluster)$cluster) > 0),
          nrow(app_env$posthoc_values(km$cluster)) == 120L)
if (requireNamespace("FactoMineR", quietly = TRUE)) {
  cats <- data.frame(Schooling=app_env$make_tertile(app_env$X_raw$schooling_years),
                     Internet=app_env$make_tertile(app_env$X_raw$internet_access_pct),
                     Manufacturing=app_env$make_tertile(app_env$X_raw$manufacturing_share_pct))
  fit <- FactoMineR::MCA(cats, ncp = 2, graph = FALSE)
  stopifnot(ncol(fit$var$coord) >= 2L,
            all(is.finite(fit$var$coord[, 1:2])))
  cat("[7/9] Post-hoc separation and MCA passed.\n")
} else {
  cat("[7/9] Post-hoc checks passed. MCA skipped (FactoMineR optional).\n")
}
# Extensions for v2.0: hierarchy cut, profiles, and permutation-invariant ARI.
ha <- stats::hclust(stats::dist(z), method = "average")
h3 <- stats::cutree(ha, 3L)
stopifnot(length(unique(h3)) == 3L,
          sum(table(h3)) == 120L,
          all(sort(as.integer(table(h3))) == c(30L, 30L, 60L)))

cut_h <- app_env$hierarchy_cut_height(ha, 3L)
stopifnot(is.finite(cut_h), cut_h > 0,
          identical(as.integer(stats::cutree(ha, h = cut_h)), as.integer(h3)))
raw_profile <- app_env$hierarchy_profile(h3, standardized = FALSE)
z_profile <- app_env$hierarchy_profile(h3, standardized = TRUE)
stopifnot(nrow(raw_profile) == 3L, nrow(z_profile) == 3L,
          ncol(raw_profile) == 7L, all(is.finite(as.matrix(z_profile[,-1]))))

# ARI must ignore a relabeling of the SAME partition.
stopifnot(abs(app_env$hierarchy_ari(g, as.integer(factor(g, levels = rev(sort(unique(g)))))) - 1) < 1e-12)
stopifnot(abs(app_env$hierarchy_ari(km$cluster, g)) <= 1 + 1e-12)
cat("[8/9] Hierarchical cut, group profiles, and ARI checks passed.\n")

# v2.1 regression: reproduce the former row-name recycling warning under
# warning-as-error mode, across all supported linkage, k and scaling choices.
# This checks exactly the tabular data consumed by the hierarchical heatmap.
original_warn <- getOption("warn")
tryCatch({
  options(warn = 2)
  for (use_scaling in c(TRUE, FALSE)) {
    xx <- app_env$prepare_x(use_scaling)
    for (linkage in c("average", "ward.D2", "complete", "single")) {
      tree <- stats::hclust(stats::dist(xx), method = linkage)
      for (number_of_groups in 2:6) {
        groups <- stats::cutree(tree, k = number_of_groups)
        long_data <- app_env$hierarchy_heatmap_data(groups)
        stopifnot(nrow(long_data) == 6L * number_of_groups,
                  all(c("group", "indicator", "mean_z") %in% names(long_data)),
                  length(unique(long_data$group)) == number_of_groups,
                  length(unique(long_data$indicator)) == 6L,
                  all(is.finite(long_data$mean_z)),
                  !anyNA(long_data$indicator),
                  is.null(rownames(long_data)) ||
                    identical(rownames(long_data), as.character(seq_len(nrow(long_data)))))
      }
    }
  }
  # Also check the exact ggplot operation on the former warning-producing data.
  example_data <- app_env$hierarchy_heatmap_data(h3)
  check_plot <- ggplot2::ggplot(example_data,
                 ggplot2::aes(indicator, group, fill = mean_z)) +
    ggplot2::geom_tile(color = "white")
  stopifnot(nrow(ggplot2::ggplot_build(check_plot)$data[[1]]) == 18L)
}, finally = options(warn = original_warn))
cat("[9/9] Hierarchical heatmap (40 settings) builds without row-name warnings.\n")
cat("\nAll available computational smoke tests passed.\n")
cat("Note: this is not a substitute for viewing all tabs in a browser.\n")

