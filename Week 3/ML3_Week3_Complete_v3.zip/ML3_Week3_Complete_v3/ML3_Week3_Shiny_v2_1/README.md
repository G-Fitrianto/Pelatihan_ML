# WEEK 3 | ECONOMIC PATTERN DISCOVERY LAB
## Complete Workshop Package v3.0 (PCA, MCA, K-Means, Hierarchical)

**Status:** classroom artifact bundle; all data are **synthetic**. Updated on November 5, 2026.

This self-contained Week 3 release keeps the original six economic indicators for 120 fictitious regions in 2024, together with the same conceptual sequence as Weeks 1 and 2. No 2025 poverty value or external `economic_zone` label enters fitting, PCA, clustering, MCA, or cluster-count selection. Those fields are reserved for optional *post-hoc description*.

## Structure and files

| Path | Function |
|---|---|
| `Slides/ML3_Pattern_Discovery_Unsupervised_v3.pdf` | Revised **65-slide** teaching presentation (Beamer AnnArbor, 16:9) |
| `Slides/ML3_Pattern_Discovery_Unsupervised_v3.tex` | Editable LaTeX source; requires the adjacent `Slides/figures/` |
| `R_Code/ML3_Student_Simplified_v3.R` | Simplified R code, 10 verbatim code blocks synchronized to the PDF |
| `R_Code/ML3_Instructor_Full_v3.R` | Full workshop R script with more PNGs, statistics, CSVs and an XLSX output |
| `Shiny_Lab/app.R` | Interactive six-tab Shiny application, updated Hierarchical interpretation |
| `Shiny_Lab/smoke_test.R` | Local numeric and consistency checks |
| `Datasets/ML3_Regional_Profiles_2024.xlsx` | Main 120-region cross-sectional workbook |
| `Datasets/ML1_Economic_Panel_Synthetic.xlsx` | Original Week 1/2 synthetic panel, supplied for continuity |
| `Reference_Outputs/ML3_Illustrative_Reference_Results.xlsx` | Previous PCA/K-means reference workbook |
| `Reference_Outputs/ML3_Hierarchical_Reference_Results_v3.xlsx` | New hierarchical group assignments, profile means, overlap and ARI (independently computed) |

The input workbook is also duplicated in `R_Code` and `Shiny_Lab` so students can run those examples directly from their respective folders.

## Installing R packages

Run once in RStudio:

```r
install.packages(c("shiny", "readxl", "dplyr", "ggplot2",
                   "cluster", "openxlsx", "FactoMineR"))
```

`FactoMineR` is only needed for the optional MCA demonstration. The packages required for the other scripts are listed at the start of each file.

### Run the classroom R code

In RStudio set the working directory to `.../ML3_Week3_Complete_v3/R_Code`, then:

```r
source("ML3_Student_Simplified_v3.R", echo = TRUE)
```

The student script follows the slide demonstrations exactly. The optional **Demo 8b** explains an Average-linkage hierarchical cut at `k=3`. It shows group sizes, the membership overlap table, and the standardized economic profiles. Expected values can be verified against the new reference workbook; group labels can be permuted.

For complete instructor output:

```r
source("ML3_Instructor_Full_v3.R")
```

This creates `R_Code/ML3_outputs/` containing the legacy PCA, K-means and MCA outputs plus extra hierarchical CSV and PNG files.

### Run the Shiny app

Set the working directory to `.../ML3_Week3_Complete_v3/Shiny_Lab`:

```r
source("smoke_test.R")
shiny::runApp(".", launch.browser = TRUE)
```

## Interactive hierarchical module changes

1. **Dendrogram reading instructions**: leaves, branch mergers, linkage height, and the dashed horizontal `k` cut line.
2. **Linkage comparison**: Average (default), Ward.D2, Complete and Single; merge heights are *not* geographic distances and should not be interpreted on identical scales across linkage types.
3. **Economic profiles**: standardized heatmap and six-feature means in original units for the hierarchical groups; plus a PCA display colored by membership.
4. **K-means overlap**: absolute and within-K-means percentages; counts are tied to actual model settings, not copied from the teaching screenshot.
5. **Adjusted Rand Index (ARI)**: permutation-invariant partition similarity. One means identical grouping up to label assignment; zero is chance-level agreement. If `Compare with K-means at the same k` is checked, the app refits its comparison K-means at the chosen hierarchical `k`. This may differ from the K-means tab's current `k`.
6. **Workbook/PNG exports** include hierarchical memberships, group sizes, profiles, overlaps, ARI, an exported dendrogram and a heatmap.

The screenshot's case (Average linkage, `k=3`) yields **30, 60 and 30** regions in the independent reference calculation. Comparisons with K-means at `k=4` demonstrate the effect of cutting a tree at a different cluster count. Separately, when both use `k=4`, Ward.D2 and K-means produce the same partition in the independent reference calculation (ARI=1). These outputs should be treated as a property of this **synthetic instructional data**, not as general algorithm equivalence.

## Slide changes

- 2 new slides explain a PCA regional biplot (scores + scaled loading arrows) and reading its economic axes.
- 5 new slides explain hierarchical dendrogram cuts, group profiles, PCA projection, linkage methods, unequal-`k` versus same-`k` K-means comparisons.
- A new R demonstration slide (`Demo 8b`) contains the **exact same R code** as the student/instructor scripts.
- Prior PCA, MCA, K-means, clustering, and post-hoc material is preserved.

## Class schedule (180 minutes)

- 25 min: Supervised-to-unsupervised recap, data and preprocessing.
- 45 min: PCA and the biplot; MCA overview.
- 10 min: Break.
- 35 min: K-means diagnostics and choosing k.
- 30 min: Hierarchical interpretation, linkage methods, and profiles.
- 25 min: Code/Shiny exercises; post-hoc interpretation.
- 10 min: Reflection and questions.

## Method and validation notes

- **The PCA projection is not a physical map.** Biplot loading arrows are visually rescaled; axis signs may flip, and distances in the first two PCs omit remaining components.
- K-means cluster numbers and hierarchical group numbers are arbitrary. **Use the overlap and ARI**, not equality of numeric labels, to assess similarity.
- Hierarchical linkage height is method-dependent. Ward.D2 merges are not measured by the same function as Average linkage heights.
- MCA uses **artificial Low/Mid/High tertiles** for pedagogy. Genuine categorical variables are more appropriate for substantive MCA research.
- Comparison with 2025 poverty and `economic_zone` labels is descriptive only and cannot establish prediction accuracy or causal effects.
- PCA and clustering on the synthetic panel have well-defined geometry by design. Do not generalize directly to Indonesian regional data.

## Verification and limitations

The source files, all code blocks, the slide deck and ZIP packaging were checked for consistency, including a static scan of R delimiters, UI-server output mapping, and slide-to-R code identity. The synthetic PCA, hierarchical assignments, overlap and ARI were independently recalculated in Python. **R / Shiny could not be executed in this creation environment.** Use the bundled smoke test and visually check all app tabs in RStudio before the workshop. Exact R cluster labels may differ from the independently calculated reference labels.

## Version 2.1: Hierarchical heatmap warning corrected (6 November 2026)

**Reported R warning:**

```text
Warning in data.frame(group = factor(d$group), indicator = feature_labels[v], ...):
  row names were found from a short variable and have been discarded
```

**Cause:** `feature_labels` is a *named* character vector. In the Hierarchical
heatmap, `feature_labels[v]` preserved its single name, while the other columns
had one value per hierarchical group. R discarded the name while building
`data.frame()`, issuing a repeated warning when the plot recalculated.

**Change:** `app.R` now creates the long-form heatmap data through
`hierarchy_heatmap_data(hg())`. This function uses
`rep(unname(feature_labels[[v]]), nrow(d))`, creates unnamed numeric mean
values, and sets ordinary sequential row names. The K-means heatmap already
used `unname()` and is unchanged.

**Smoke test:** `smoke_test.R` checks the hierarchy heatmap data for 40 combinations
(4 linkage methods × 5 choices of k × 2 scaling modes), with R warnings treated
as errors for that section. It also checks construction of a ggplot heatmap.
The original PCA/K-means/MCA tests are retained.

**Compatibility:** No changes to the dataset, PCA, K-means, MCA, dendrogram
cutting, cluster memberships, or the exported workbook. This is a warning fix
for the hierarchical profile plot. R execution has **not** been performed in
the development environment; run the local smoke test before the workshop.

To run from the extracted folder:

```r
setwd("F:/MACHINE LEARNING WORKSHOP/ML3_Week3_Shiny_v2_1") # edit path
source("smoke_test.R")
shiny::runApp(".", launch.browser = TRUE)
```
