# =============================================================================
# WEEK 3 | ECONOMIC PATTERN DISCOVERY LAB
# Interactive unsupervised machine learning: PCA, K-means, hierarchical, MCA
# Instructor: Gigih Fitrianto | Undergraduate Economics workshop
# Version 2.1 | Warning-free hierarchical profiles; synthetic regions, 2024
# =============================================================================
# HOW TO USE
# 1. Place this app.R beside ML3_Regional_Profiles_2024.xlsx.
# 2. Install packages listed in README.md and open app.R in RStudio.
# 3. Click "Run App", or run shiny::runApp("path/to/this/folder").
# 4. Poverty in 2025 and economic_zone NEVER enter fitting or k selection.
# =============================================================================

required_packages <- c("shiny", "readxl", "ggplot2", "cluster", "openxlsx")
not_installed <- required_packages[
  !vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)
]
if (length(not_installed)) {
  stop("Missing required R packages: ", paste(not_installed, collapse = ", "),
       "\nRun install.packages(c(",
       paste(sprintf('"%s"', not_installed), collapse = ", "), "))")
}

library(shiny)
library(ggplot2)

# This file locates its bundled workbook when launched from within its folder.
# If you launch the script from elsewhere, change the following line.
input_file <- file.path(getwd(), "ML3_Regional_Profiles_2024.xlsx")
if (!file.exists(input_file)) {
  stop("Cannot locate ML3_Regional_Profiles_2024.xlsx in: ", getwd(),
       "\nRun the app from the extracted folder.")
}

features <- c("grdp_pc_million_idr", "unemployment_pct", "schooling_years",
              "internet_access_pct", "manufacturing_share_pct",
              "investment_pc_million_idr")
feature_labels <- c("GRDP per capita", "Unemployment", "Schooling",
                    "Internet access", "Manufacturing", "Investment per capita")
names(feature_labels) <- features
base_seed <- 20261104L

profiles <- as.data.frame(readxl::read_excel(input_file, sheet = "Profiles_2024"))
needed <- c("region_id", "economic_zone", "year", features)
if (!all(needed %in% names(profiles))) {
  stop("The Profiles_2024 worksheet lacks: ",
       paste(setdiff(needed, names(profiles)), collapse = ", "))
}
if (nrow(profiles) != 120 || anyDuplicated(profiles$region_id) ||
    !all(profiles$year == 2024)) {
  stop("Expected 120 unique synthetic regions for year 2024.")
}
for (v in features) {
  profiles[[v]] <- as.numeric(profiles[[v]])
  if (any(!is.finite(profiles[[v]]) & !is.na(profiles[[v]]))) {
    stop("Non-finite value in feature: ", v)
  }
}

# Model input: ONLY six economic predictors. Neither poverty nor economic_zone
# is ever passed into scale(), prcomp(), kmeans(), dist(), hclust(), or MCA().
missing_table <- data.frame(
  predictor = unname(feature_labels),
  missing_count = vapply(profiles[features], function(z) sum(is.na(z)), integer(1))
)
X_raw <- profiles[features]
medians <- vapply(X_raw, function(x) median(x, na.rm = TRUE), numeric(1))
if (!all(is.finite(medians))) stop("A numeric predictor has no finite median.")
for (v in features) X_raw[[v]][is.na(X_raw[[v]])] <- medians[[v]]
if (any(vapply(X_raw, sd, numeric(1)) <= 0)) {
  stop("At least one predictor has zero variance.")
}

prepare_x <- function(standardize = TRUE) {
  # Center always; scale by the sample SD in the standard version.
  ans <- scale(as.matrix(X_raw), center = TRUE, scale = standardize)
  colnames(ans) <- features
  ans
}

calculate_pca <- function(X) {
  stats::prcomp(X, center = FALSE, scale. = FALSE)
}

calculate_kmeans <- function(X, k, nstart = 50L) {
  set.seed(base_seed + as.integer(k))
  stats::kmeans(X, centers = as.integer(k), nstart = as.integer(nstart),
                iter.max = 100L)
}

calculate_k_curve <- function(X, nstart = 50L) {
  D <- stats::dist(X)
  do.call(rbind, lapply(2:6, function(k) {
    fit <- calculate_kmeans(X, k, nstart)
    ss <- cluster::silhouette(fit$cluster, D)
    data.frame(k = k, total_withinss = fit$tot.withinss,
               mean_silhouette = mean(ss[, "sil_width"]))
  }))
}

# Rank-based illustrative tertiles, mirroring the optional Week 3 MCA code.
# For genuine categorical economics research, use real category variables.
make_tertile <- function(z) {
  stopifnot(all(is.finite(z)))
  n <- length(z)
  cut(rank(z, ties.method = "average"),
      breaks = c(-Inf, n/3, 2*n/3, Inf),
      labels = c("Low", "Mid", "High"))
}

pca_summary <- function(pc) {
  v <- 100 * pc$sdev^2 / sum(pc$sdev^2)
  data.frame(PC = paste0("PC", seq_along(v)),
             component = seq_along(v),
             variance_pct = v,
             cumulative_pct = cumsum(v))
}

pca_loadings <- function(pc) {
  r <- as.data.frame(pc$rotation)
  data.frame(variable = rownames(r), r,
             row.names = NULL, check.names = FALSE)
}

make_clusters_data <- function(pc, km) {
  data.frame(region_id = profiles$region_id,
             economic_zone = profiles$economic_zone,
             PC1 = pc$x[, 1], PC2 = pc$x[, 2],
             cluster = factor(km$cluster), stringsAsFactors = FALSE)
}

cluster_profiles <- function(km, standardized = FALSE) {
  Z <- if (standardized) as.data.frame(prepare_x(TRUE)) else X_raw
  aggregate(Z, by = list(cluster = as.integer(km$cluster)), FUN = mean)
}

# Hierarchical clustering helpers. Group numeric labels have NO intrinsic order.
hierarchy_ari <- function(x, y) {
  if (length(x) != length(y) || length(x) < 2L) stop("Invalid pair of cluster labels")
  T <- table(x, y)
  comb2 <- function(z) z * (z - 1) / 2
  total <- comb2(sum(T))
  row_pairs <- sum(comb2(rowSums(T)))
  col_pairs <- sum(comb2(colSums(T)))
  observed <- sum(comb2(T))
  expected <- row_pairs * col_pairs / total
  maximum <- (row_pairs + col_pairs) / 2
  if (abs(maximum - expected) < 1e-12) {
    return(if (identical(as.integer(x == x[1]), as.integer(y == y[1]))) 1 else NA_real_)
  }
  (observed - expected) / (maximum - expected)
}

hierarchy_cut_height <- function(hc, k) {
  n <- length(hc$order)
  k <- as.integer(k)
  stopifnot(k >= 2, k < n)
  # Height strictly between the (n-k)th and (n-k+1)th merges.
  mean(hc$height[c(n - k, n - k + 1L)])
}

hierarchy_profile <- function(groups, standardized = TRUE) {
  m <- if (standardized) as.data.frame(prepare_x(TRUE)) else X_raw
  aggregate(m, by = list(group = as.integer(groups)), FUN = mean)
}

# Convert a hierarchical cluster profile from wide to long for the heatmap.
# The label lookup is a NAMED vector; data.frame() warns when a 1-element
# named value is recycled alongside multiple group rows. Remove that name
# explicitly before constructing the table, for every feature and group.
hierarchy_heatmap_data <- function(groups) {
  d <- hierarchy_profile(groups, standardized = TRUE)
  result <- do.call(rbind, lapply(features, function(v) {
    data.frame(group = factor(d$group),
               indicator = rep(unname(feature_labels[[v]]), nrow(d)),
               mean_z = as.numeric(d[[v]]),
               stringsAsFactors = FALSE,
               row.names = NULL)
  }))
  rownames(result) <- NULL
  result
}

draw_hierarchy <- function(hc, k, method_name) {
  plot(hc, labels = FALSE, hang = -1,
       main = paste0("Hierarchical clustering: ", method_name),
       xlab = "120 synthetic regions (leaves)", sub = "",
       ylab = "Merge height (linkage-specific)", cex.main = 1.15)
  rect.hclust(hc, k = k, border = "#2d7955")
  abline(h = hierarchy_cut_height(hc, k), col = "#c18e32", lwd = 2, lty = 2)
}

posthoc_values <- function(clusters) {
  # Deliberately accessed only when needed for external interpretation/export.
  post <- as.data.frame(readxl::read_excel(input_file, sheet = "Posthoc_2025"))
  if (!all(c("region_id", "year", "poverty_rate_pct") %in% names(post))) {
    stop("Posthoc_2025 sheet has missing columns.")
  }
  ids <- match(profiles$region_id, post$region_id)
  if (anyNA(ids) || anyDuplicated(post$region_id) ||
      !all(post$year[ids] == 2025)) {
    stop("Posthoc_2025 does not match the 120 synthetic regions.")
  }
  data.frame(region_id = profiles$region_id,
             cluster = factor(clusters), economic_zone = profiles$economic_zone,
             poverty_2025 = as.numeric(post$poverty_rate_pct[ids]))
}

format4 <- function(x) format(round(x, 4), nsmall = 4, trim = TRUE)

# =============================================================================
# UI
# =============================================================================
ui <- navbarPage(
  title = "Week 3 | Economic Pattern Discovery Lab",
  id = "navigation",
  header = tags$head(tags$style(HTML('
    body { background: #f7f9f8; color: #21342b; }
    .navbar-default { background: #173c2d; border: none; }
    .navbar-default .navbar-brand, .navbar-default .navbar-nav > li > a
       { color: #f7fbf9 !important; }
    .navbar-default .navbar-nav > .active > a,
    .navbar-default .navbar-nav > .active > a:focus,
    .navbar-default .navbar-nav > .active > a:hover { background: #287858 !important; }
    .well { background: #edf3ef; border-color: #d9e5dd; border-radius: 9px; }
    .panel-note { background:#edf5f0; padding:13px 15px;
                  border-left:4px solid #367b5a; margin:12px 0; border-radius:4px; }
    .panel-caution { background:#fff7e9; padding:13px 15px;
                     border-left:4px solid #c08a2a; margin:12px 0; border-radius:4px; }
    .result-title { color: #194c37; font-size:21px; font-weight:600; }
    .small-muted { color: #64756b; font-size: 12px; }
    table { font-size: 12px; }
    h2,h3,h4 { color: #173f2e; }
    .btn-primary { background:#276c50; border-color:#276c50; }
    .btn-primary:hover { background:#1c553d; border-color:#1c553d; }
    .shiny-plot-output { background: white; border-radius: 8px; }
  '))),

  tabPanel("Start Here",
    fluidPage(
      h2("What patterns do economic indicators reveal?"),
      p("An interactive undergraduate workshop using 120 fictional economic regions (2024)."),
      div(class = "panel-note", HTML(
        "<b>From supervised to unsupervised:</b> Weeks 1–2 used known poverty outcomes to fit prediction rules. Week 3 discovers patterns in six economic indicators <b>without using any poverty target</b>.")),
      fluidRow(
        column(5,
          h4("Our shared dataset"),
          tableOutput("dataset_info"),
          div(class = "panel-caution", HTML(
            "<b>Important:</b> <code>economic_zone</code> and 2025 poverty are external labels for <i>post-hoc</i> interpretation only. They never enter PCA, K-means, hierarchical clustering, MCA, or the choice of k.")),
          h4("Preprocessing audit"), tableOutput("missing_table")),
        column(7,
          h4("The six economic indicators"),
          tableOutput("indicator_table"),
          h4("Learning pathway"),
          tags$ol(
            tags$li("PCA: summarize variation in numeric indicators."),
            tags$li("K-means: find groups of regions using all six indicators."),
            tags$li("Hierarchical: explore nested similarity between regions."),
            tags$li("MCA: explore profiles defined by categorical indicators."),
            tags$li("Post-hoc: interpret groups using withheld contextual labels.")),
          div(class="small-muted", "All displayed results are descriptive and cannot establish causal effects."))
      )
    )
  ),

  tabPanel("1. PCA Explorer",
    fluidPage(
      h2("PCA | From six variables to a few dimensions"),
      fluidRow(
        column(4, wellPanel(
          radioButtons("scaling", "Preprocessing for PCA and clustering",
                       choices = c("Standardize each indicator (recommended)" = "scaled",
                                   "Center only (illustrate unit sensitivity)" = "raw"),
                       selected = "scaled"),
          sliderInput("pc_count", "Number of PCs to summarize", min = 1,
                      max = 6, value = 2, step = 1),
          checkboxInput("loadings_arrows", "Show variable loading arrows", TRUE),
          div(class="panel-note", HTML(
            "<b>How to read:</b> Bars show variance explained by each component; the line is cumulative variance. PC1 and PC2 are directions of maximal variation, not economic outcomes.")),
          div(class="panel-caution", "PCA axis signs can flip while the analysis remains equivalent.")
        )),
        column(8,
          h4("Explained variance"), plotOutput("pca_scree", height = "300px"),
          h4("Regional PCA map"), plotOutput("pca_scatter", height = "365px"))
      ),
      fluidRow(
        column(6, h4("Eigenvalues and cumulative variance"), tableOutput("pca_variance_table")),
        column(6, h4("Component loadings"), tableOutput("pca_loadings_table"))
      )
    )
  ),

  tabPanel("2. K-Means Lab",
    fluidPage(
      h2("K-means | Which regions share economic characteristics?"),
      fluidRow(
        column(3, wellPanel(
          sliderInput("k", "Number of clusters (k)", min = 2, max = 6, value = 4,
                      step = 1),
          sliderInput("nstart", "Random initializations", min = 10,
                      max = 100, value = 50, step = 10),
          actionButton("use_best_k", "Use silhouette-best k", class = "btn-primary"),
          p(class="small-muted", "Fixed random seed; clusters are calculated from the six input indicators, not from PCA axes."),
          div(class = "panel-note", HTML(
            "<b>Silhouette:</b> higher values generally indicate more separated groups. <b>Elbow:</b> look for diminishing reductions in within-cluster variation. Neither plot guarantees a universally correct k."))
        )),
        column(9, tabsetPanel(
          tabPanel("Cluster map", plotOutput("kmap", height = "400px")),
          tabPanel("Elbow and silhouette", plotOutput("kcurve", height = "410px")),
          tabPanel("Economic profile heatmap", plotOutput("kheatmap", height = "400px"))
        ))
      ),
      fluidRow(
        column(4, h4("K selection diagnostics"), tableOutput("kdiagnostics")),
        column(4, h4("Cluster sizes"), tableOutput("ksizes")),
        column(4, h4(textOutput("centers_heading", inline = TRUE)),
               tableOutput("kcenters"))
      ),
      div(class="panel-caution", "Cluster labels 1, 2, ... are arbitrary identifiers, not rankings of welfare, poverty or quality.")
    )
  ),

  tabPanel("3. Hierarchical",
    fluidPage(
      h2("Hierarchical clustering | How do regions merge?"),
      div(class="panel-note", HTML(
        "<b>Why this method?</b> Hierarchical clustering builds a nested tree from distances between economic profiles. It uses the same six 2024 indicators as K-means; no poverty outcome or zone label enters the model.")),
      fluidRow(
        column(3, wellPanel(
          selectInput("hmethod", "Linkage method", c("Ward.D2" = "ward.D2",
                    "Complete" = "complete", "Average" = "average",
                    "Single" = "single"), selected = "average"),
          sliderInput("hk", "Cut dendrogram at k groups", min = 2,
                      max = 6, value = 3, step = 1),
          checkboxInput("h_same_k", "Compare with K-means at the same k", TRUE),
          div(class="panel-note", HTML(
            "<b>How to read a dendrogram</b><ol><li>Leaves (bottom): individual regions.</li><li>Branches: merging groups.</li><li>Vertical height: linkage-dependent dissimilarity at merging.</li><li>Dashed gold line: a cut producing the chosen number of groups.</li></ol>")),
          div(class="panel-caution", HTML(
            "<b>Important:</b> Heights are not geographic kilometers and are not directly comparable across linkage methods. Cluster numbers are arbitrary. Ward.D2 and Average can give different trees."))
        )),
        column(9,
          h4("Dendrogram and selected cut"), plotOutput("dendro", height="420px"),
          div(class="small-muted", "Drag the k slider or switch the linkage to see how membership and joining heights change."))
      ),
      fluidRow(
        column(4, h4("Hierarchical group sizes"), tableOutput("hsizes")),
        column(4, h4("Comparison diagnostics"), tableOutput("hsummary")),
        column(4, h4("How to interpret the match"), uiOutput("hinsight"))
      ),
      fluidRow(
        column(6, h4("Regional economic profiles: standardized"),
               plotOutput("hheatmap", height="365px")),
        column(6, h4("Hierarchical groups on PCA dimensions"),
               plotOutput("hpca", height="365px"))
      ),
      fluidRow(
        column(6, h4("Original-unit economic means per group"),
               tableOutput("hprofiles_raw")),
        column(6, h4("K-means versus hierarchical overlap (counts)"),
               tableOutput("hcompare"),
               h4("Percent of each K-means group assigned to hierarchical groups"),
               tableOutput("hcompare_pct"))
      ),
      div(class="panel-note", HTML(
        "<b>Discussion:</b> if hierarchical k=3 merges two of the K-means k=4 groups, that reflects the requested resolution of the tree, not an estimation failure. Choose the <i>same-k</i> checkbox for an algorithm-to-algorithm comparison; compare the membership table and the Adjusted Rand Index (ARI, where 1 means identical partitioning up to relabeling). Cluster profiles explain their economic characteristics, not causal effects."))
    )
  ),

  tabPanel("4. MCA Explorer",
    fluidPage(
      h2("MCA | Explore categories rather than continuous measurements"),
      div(class="panel-caution", HTML(
        "<b>Teaching illustration:</b> Low/Mid/High categories here are created from numeric economic data. Turning continuous variables into categories discards information. For applied MCA, genuine categorical data are preferable.")),
      fluidRow(
        column(4, wellPanel(
          checkboxGroupInput("mca_features", "Categorical indicators to include",
            choices = stats::setNames(names(feature_labels),
                                      unname(feature_labels)),
            selected = c("schooling_years", "internet_access_pct",
                         "manufacturing_share_pct")),
          p(class="small-muted", "Choose at least two indicators. Values are divided into three rank-based categories: Low, Mid, High."),
          div(class="panel-note", "Category-map proximity can suggest category associations. Axis directions are arbitrary. MCA inertia is not PCA variance explained or prediction accuracy."),
          div(class="small-muted", "Optional package: FactoMineR. Install it once to enable MCA."))
        ),
        column(8,
          h4("MCA category factor map"), plotOutput("mca_map", height="390px"),
          h4("Inertia of MCA dimensions"), plotOutput("mca_inertia_plot", height="245px"))
      ),
      fluidRow(
        column(6, h4("MCA inertia"), tableOutput("mca_inertia")),
        column(6, h4("Categories and coordinates"), tableOutput("mca_coords"))
      )
    )
  ),

  tabPanel("5. Post-Hoc Interpretation",
    fluidPage(
      h2("Post-hoc interpretation | What do the discovered groups mean?"),
      div(class="panel-caution", HTML(
        "<b>Not supervised learning:</b> Cluster membership was determined using six 2024 economic indicators. <code>economic_zone</code> and 2025 poverty are added only afterward to describe groups.")),
      fluidRow(
        column(6, h4("2025 poverty by 2024 cluster"),
               plotOutput("post_poverty", height="410px")),
        column(6, h4("External economic-zone labels versus discovered clusters"),
               plotOutput("post_zone", height="410px"))
      ),
      fluidRow(
        column(6, h4("Poverty summary by cluster"), tableOutput("post_poverty_table")),
        column(6, h4("Cluster vs economic-zone cross-tabulation"),
               tableOutput("post_zone_table"))
      ),
      div(class="panel-note", "Different poverty distributions across clusters are descriptive associations. Do not interpret them as the effect of cluster membership or as forecast accuracy.")
    )
  ),

  tabPanel("6. Export & Guide",
    fluidPage(
      h2("Save and teach from your current interactive analysis"),
      fluidRow(
        column(5, wellPanel(
          h4("Download results"),
          downloadButton("download_excel", "Download full results (.xlsx)",
                         class = "btn-primary"),
          tags$hr(),
          downloadButton("download_clusters_csv", "Download cluster assignments (.csv)"),
          tags$hr(),
          downloadButton("download_pca_png", "Download PCA scatter (.png)"),
          tags$br(), tags$br(),
          downloadButton("download_kmap_png", "Download cluster plot (.png)"),
          tags$br(), tags$br(),
          downloadButton("download_dendro_png", "Download hierarchy dendrogram (.png)"),
          tags$br(), tags$br(),
          downloadButton("download_hprofile_png", "Download hierarchical profile heatmap (.png)"),
          tags$br(), tags$br(),
          if (requireNamespace("FactoMineR", quietly = TRUE))
            downloadButton("download_mca_png", "Download MCA map (.png)")
          else tags$p(class="small-muted", "Install FactoMineR to enable MCA downloads."),
          p(class="small-muted", "Downloaded files reflect the current controls. Shiny does not automatically write to a local output folder."))),
        column(7,
          h4("Suggested 40–55 minute Shiny demonstration"),
          tags$ol(
            tags$li("PCA (10–12 min): standardization, scree plot, loadings and PC directions."),
            tags$li("K-means (12–15 min): k = 2–6, silhouette, elbow and group profiles."),
            tags$li("Hierarchical (10–15 min): read cut height, change linkages, inspect profiles and ARI."),
            tags$li("MCA (6–8 min): explore the categorical map and inertia."),
            tags$li("Post-hoc (5–8 min): compare groups with withheld zone labels and poverty.")),
          h4("Discussion questions"),
          tags$ol(
            tags$li("Why do PCA and K-means change after removing standardization?"),
            tags$li("Does the first principal component measure economic welfare?"),
            tags$li("Can two different values of k both be meaningful?"),
            tags$li("Does a close pair of MCA categories imply causation?"),
            tags$li("Why is 2025 poverty kept outside all unsupervised fitting?"))
        )
      )
    )
  )
)

# =============================================================================
# SERVER
# =============================================================================
server <- function(input, output, session) {
  model_x <- reactive({
    prepare_x(identical(input$scaling, "scaled"))
  })

  pc <- reactive(calculate_pca(model_x()))
  pv <- reactive(pca_summary(pc()))
  km <- reactive(calculate_kmeans(model_x(), input$k, input$nstart))
  kd <- reactive(calculate_k_curve(model_x(), input$nstart))
  best_k <- reactive(kd()$k[which.max(kd()$mean_silhouette)])

  observeEvent(input$use_best_k, {
    updateSliderInput(session, "k", value = best_k())
  })

  hcl <- reactive(stats::hclust(stats::dist(model_x()), method = input$hmethod))
  hg <- reactive(stats::cutree(hcl(), k = input$hk))
  compare_k <- reactive(if (isTRUE(input$h_same_k)) input$hk else input$k)
  km_comparator <- reactive(calculate_kmeans(model_x(), compare_k(), input$nstart))
  overlap_counts <- reactive(table(KMeans = km_comparator()$cluster,
                                   Hierarchical = hg()))
  hierarchy_profile_z <- reactive(hierarchy_profile(hg(), TRUE))
  hierarchy_profile_raw <- reactive(hierarchy_profile(hg(), FALSE))
  hierarchy_scores <- reactive(data.frame(PC1 = pc()$x[, 1],
                                           PC2 = pc()$x[, 2],
                                           Hierarchical_Group = factor(hg())))


  # MCA deliberately uses the original numeric indicators and categorizes them.
  mca_inputs <- reactive({
    vals <- input$mca_features
    validate(need(length(vals) >= 2, "Select at least two indicators for MCA."))
    keys <- vals
    if (!all(keys %in% features)) stop("Unknown MCA predictor selected.")
    cats <- lapply(X_raw[keys], make_tertile)
    names(cats) <- gsub("[[:space:]]+", "", unname(feature_labels[keys]))
    as.data.frame(cats)
  })
  mca <- reactive({
    validate(need(requireNamespace("FactoMineR", quietly = TRUE),
                  "MCA requires the optional FactoMineR package. Install it with install.packages('FactoMineR')."))
    cats <- mca_inputs()
    FactoMineR::MCA(cats, graph = FALSE, ncp = 2)
  })

  mca_coords <- reactive({
    cr <- mca()$var$coord[, 1:2, drop = FALSE]
    labels <- rownames(cr)
    parts <- strsplit(labels, "_")
    data.frame(category = labels,
               indicator = vapply(parts, function(z) z[1], character(1)),
               Dim1 = as.numeric(cr[, 1]), Dim2 = as.numeric(cr[, 2]))
  })
  mca_eigen <- reactive({
    E <- mca()$eig
    data.frame(dimension = paste0("Dim", seq_len(nrow(E))),
               eigenvalue = as.numeric(E[, 1]),
               inertia_pct = as.numeric(E[, 2]),
               cumulative_inertia_pct = as.numeric(E[, 3]))
  })

  scores <- reactive(make_clusters_data(pc(), km()))
  post <- reactive(posthoc_values(km()$cluster))

  output$dataset_info <- renderTable({
    data.frame(item = c("Data type", "Unit", "Year", "Regions", "Numeric indicators"),
               value = c("Synthetic regional panel cross-section", "Fictitious region",
                         "2024", nrow(profiles), length(features)))
  }, striped = TRUE, spacing = "xs", rownames = FALSE)
  output$indicator_table <- renderTable({
    data.frame(indicator = unname(feature_labels),
               variable_in_workbook = features)
  }, striped = TRUE, spacing = "xs", rownames = FALSE)
  output$missing_table <- renderTable({missing_table},
                                      striped = TRUE, spacing="xs", rownames=FALSE)

  p_scree <- reactive({
    ggplot(pv(), aes(component, variance_pct)) +
      geom_col(fill = "#2f7355", width = .72) +
      geom_line(aes(y = cumulative_pct), group = 1,
                color = "#c18e32", linewidth = 1.05) +
      geom_point(aes(y = cumulative_pct), color = "#c18e32", size = 2.2) +
      scale_x_continuous(breaks = 1:6) +
      labs(x = "Principal component", y = "Variance explained (%)",
           title = "Individual (bars) and cumulative (line) variance") +
      theme_minimal(base_size = 12)
  })
  output$pca_scree <- renderPlot({print(p_scree())})

  p_pc_map <- reactive({
    cc <- data.frame(PC1 = pc()$x[, 1], PC2 = pc()$x[, 2])
    p <- ggplot(cc, aes(PC1, PC2)) +
      geom_point(color = "#25684a", alpha = .74, size = 2.35) +
      geom_hline(yintercept = 0, color = "grey75") +
      geom_vline(xintercept = 0, color = "grey75") +
      labs(title = "PCA scores for 120 synthetic regions",
           subtitle = "Each point is one region; no poverty outcome used",
           x = paste0("PC1 (", round(pv()$variance_pct[1], 1), "% variance)"),
           y = paste0("PC2 (", round(pv()$variance_pct[2], 1), "% variance)")) +
      theme_minimal(base_size = 12)
    if (isTRUE(input$loadings_arrows)) {
      r <- pc()$rotation[, 1:2, drop = FALSE]
      # Scale directions visually. Loadings are NOT in original score units.
      stretch <- 0.75 * min(diff(range(cc$PC1)), diff(range(cc$PC2))) /
        max(sqrt(rowSums(r^2)))
      arrow_data <- data.frame(variable = unname(feature_labels),
                               a1 = r[,1] * stretch, a2 = r[,2] * stretch)
      p <- p +
        geom_segment(data = arrow_data,
                     aes(x = 0, y = 0, xend = a1, yend = a2),
                     inherit.aes = FALSE, color = "#c28b31",
                     arrow = grid::arrow(length = grid::unit(.16, "cm")),
                     linewidth = .8) +
        geom_text(data = arrow_data,
                  aes(x = a1, y = a2, label = variable),
                  inherit.aes = FALSE, color = "#805b1c", size = 3.2,
                  check_overlap = TRUE, vjust = -.4)
    }
    p
  })
  output$pca_scatter <- renderPlot({print(p_pc_map())})
  output$pca_variance_table <- renderTable({
    d <- pv(); d$variance_pct <- round(d$variance_pct, 2)
    d$cumulative_pct <- round(d$cumulative_pct, 2)
    d[seq_len(input$pc_count),c("PC","variance_pct","cumulative_pct")]
  }, striped = TRUE, spacing="xs", rownames=FALSE)
  output$pca_loadings_table <- renderTable({
    L <- pca_loadings(pc())
    L[, 2:ncol(L)] <- round(L[, 2:ncol(L)], 3)
    L[, c("variable", paste0("PC", seq_len(input$pc_count))), drop = FALSE]
  }, striped = TRUE, spacing="xs", rownames=FALSE)

  p_cluster_map <- reactive({
    ggplot(scores(), aes(PC1, PC2, color = cluster)) +
      geom_point(size = 2.85, alpha = .88) +
      labs(title = paste("K-means regions (k =", input$k, ")"),
           subtitle = "Groups fitted on all six indicators; PCs used only as a 2D display",
           x = paste0("PC1 (", round(pv()$variance_pct[1],1), "%)"),
           y = paste0("PC2 (", round(pv()$variance_pct[2],1), "%)"),
           color = "Cluster") +
      theme_minimal(base_size=12)
  })
  output$kmap <- renderPlot({print(p_cluster_map())})

  p_kcurve <- reactive({
    d <- kd()
    # Faceted view keeps elbow (raw withinSS) and silhouette on their own scales.
    long <- rbind(
      data.frame(k = d$k, value = d$total_withinss, metric = "Within-cluster SS (elbow)"),
      data.frame(k = d$k, value = d$mean_silhouette, metric = "Mean silhouette"))
    ggplot(long, aes(k, value)) +
      geom_line(color = "#2f7355", linewidth = 1.2) +
      geom_point(size = 2.4, color = "#c18e32") +
      facet_wrap(~metric, scales = "free_y", ncol = 1) +
      scale_x_continuous(breaks = 2:6) +
      labs(title = paste("Cluster-count diagnostics | silhouette best k =", best_k()),
           x = "Number of clusters k", y = "Diagnostic value") +
      theme_minimal(base_size = 12)
  })
  output$kcurve <- renderPlot({print(p_kcurve())})

  p_heat <- reactive({
    df <- cluster_profiles(km(), standardized = TRUE)
    out <- do.call(rbind, lapply(features, function(v) {
      data.frame(cluster = factor(df$cluster),
                 indicator = unname(feature_labels[v]),
                 avg_z = df[[v]])
    }))
    ggplot(out, aes(indicator, cluster, fill = avg_z)) +
      geom_tile(color = "white", linewidth = 1) +
      geom_text(aes(label = sprintf("%.2f", avg_z)), size=3.5) +
      scale_fill_gradient2(low = "#c28b32", mid = "#f7f7f3",
                           high = "#287858", midpoint = 0) +
      labs(title = "Cluster profile: mean standardized indicator",
           subtitle = "Positive means above the full-sample mean",
           x = NULL, y = "Cluster", fill = "Mean z") +
      theme_minimal(base_size = 11) +
      theme(axis.text.x = element_text(angle = 30, hjust = 1))
  })
  output$kheatmap <- renderPlot({print(p_heat())})

  output$kdiagnostics <- renderTable({
    data.frame(k=kd()$k,
               withinSS = round(kd()$total_withinss, 1),
               silhouette = round(kd()$mean_silhouette, 3))
  }, striped=TRUE, spacing="xs", rownames=FALSE)
  output$ksizes <- renderTable({
    data.frame(cluster=names(table(km()$cluster)),
               regions=as.integer(table(km()$cluster)))
  }, striped=TRUE, spacing="xs", rownames=FALSE)
  output$centers_heading <- renderText({
    if (identical(input$scaling, "scaled")) {
      "Cluster centroids (standardized inputs)"
    } else "Cluster centroids (centered original units)"
  })
  output$kcenters <- renderTable({
    # The standard choice is z-scored input; when unscaled, these are centered
    # raw-unit values and the displayed heading warns via the scaling control.
    out <- as.data.frame(km()$centers)
    out <- cbind(cluster = seq_len(nrow(out)), out)
    out[, -1] <- lapply(out[, -1, drop=FALSE], round, digits=2)
    out
  }, striped=TRUE, spacing="xs", rownames=FALSE)

  output$dendro <- renderPlot({
    draw_hierarchy(hcl(), input$hk, input$hmethod)
  })
  output$hsizes <- renderTable({
    dd <- table(hg())
    data.frame(group = names(dd), regions = as.integer(dd))
  }, striped=TRUE, spacing="xs", rownames=FALSE)
  output$hsummary <- renderTable({
    data.frame(item = c("Linkage", "Hierarchical k", "Compared K-means k",
                        "Adjusted Rand Index", "Cut height"),
               value = c(input$hmethod, input$hk, compare_k(),
                         sprintf("%.3f", hierarchy_ari(km_comparator()$cluster, hg())),
                         sprintf("%.3f", hierarchy_cut_height(hcl(), input$hk))))
  }, striped = TRUE, spacing="xs", rownames = FALSE)
  output$hinsight <- renderUI({
    T <- overlap_counts()
    # Build sentence from the overlap, not from the arbitrary names of clusters.
    sentences <- vapply(seq_len(ncol(T)), function(j) {
      by_col <- T[, j]
      src <- paste(rownames(T)[by_col > 0], collapse = ", ")
      paste0("Hierarchical group ", colnames(T)[j], " contains ",
             sum(by_col), " regions from K-means group(s): ", src, ".")
    }, character(1))
    tags$div(class="panel-note", tags$ul(lapply(sentences, tags$li)))
  })
  output$hcompare <- renderTable({
    x <- as.data.frame.matrix(overlap_counts())
    data.frame(KMeans_Group = rownames(x), x, row.names = NULL,
               check.names = FALSE)
  }, striped=TRUE, spacing="xs", rownames=FALSE)
  output$hcompare_pct <- renderTable({
    T <- overlap_counts()
    P <- 100 * prop.table(T, margin = 1)
    data.frame(KMeans_Group = rownames(P),
               round(as.data.frame.matrix(P), 1), row.names = NULL,
               check.names = FALSE)
  }, striped=TRUE, spacing="xs", rownames=FALSE)
  output$hprofiles_raw <- renderTable({
    d <- hierarchy_profile_raw()
    d[, -1] <- lapply(d[, -1, drop=FALSE], round, 2)
    names(d)[-1] <- unname(feature_labels)
    d
  }, striped=TRUE, spacing="xs", rownames=FALSE)
  p_hheat <- reactive({
    z <- hierarchy_heatmap_data(hg())
    ggplot(z, aes(indicator, group, fill=mean_z)) +
      geom_tile(color="white",linewidth=1) +
      geom_text(aes(label=sprintf("%+.2f", mean_z)),size=3.3) +
      scale_fill_gradient2(low="#c18e32",mid="#f7f7f3",high="#287858",midpoint=0) +
      labs(x=NULL,y="Hierarchical group",fill="Mean z",
           title="Economic characteristics by hierarchical group",
           subtitle="Positive = above the full-sample indicator mean") +
      theme_minimal(base_size=11) +
      theme(axis.text.x=element_text(angle=25,hjust=1))
  })
  output$hheatmap <- renderPlot({print(p_hheat())})
  p_hpca <- reactive({
    ggplot(hierarchy_scores(),aes(PC1,PC2,color=Hierarchical_Group)) +
      geom_point(size=2.8,alpha=.85) +
      labs(title="Hierarchical groups in PCA space",
           subtitle="PCA axes are a display; clustering uses all six economic inputs",
           x=paste0("PC1 (", round(pv()$variance_pct[1],1),"%)"),
           y=paste0("PC2 (", round(pv()$variance_pct[2],1),"%)"),
           color="Group") + theme_minimal(base_size=11)
  })
  output$hpca <- renderPlot({print(p_hpca())})

  p_mca <- reactive({
    cc <- mca_coords()
    ggplot(cc, aes(Dim1, Dim2, color = indicator, label = category)) +
      geom_hline(yintercept = 0, color = "grey75") +
      geom_vline(xintercept = 0, color = "grey75") +
      geom_point(size=3.1) +
      geom_text(vjust = -.8, check_overlap = TRUE, show.legend = FALSE,
                size = 3.5) +
      labs(title="MCA factor map (category coordinates)",
           subtitle="Low/Mid/High are artificial tertiles; not real economic classifications",
           x = paste0("Dim 1 (", round(mca_eigen()$inertia_pct[1],1), "% raw inertia)"),
           y = paste0("Dim 2 (", round(mca_eigen()$inertia_pct[2],1), "% raw inertia)"),
           color="Indicator") +
      theme_minimal(base_size=12)
  })
  output$mca_map <- renderPlot({print(p_mca())})

  p_inertia <- reactive({
    ee <- mca_eigen()
    ggplot(ee, aes(seq_along(inertia_pct), inertia_pct)) +
      geom_col(fill = "#317657", width=.75) +
      scale_x_continuous(breaks = seq_len(nrow(ee))) +
      labs(title="MCA: raw inertia per dimension",
           x="Dimension", y="Inertia (% of total)") +
      theme_minimal(base_size=12)
  })
  output$mca_inertia_plot <- renderPlot({print(p_inertia())})
  output$mca_inertia <- renderTable({
    d <- mca_eigen(); d[, -1] <- lapply(d[,-1,drop=FALSE], round, digits=2)
    d
  }, striped=TRUE, spacing="xs", rownames=FALSE)
  output$mca_coords <- renderTable({
    d <- mca_coords(); d$Dim1 <- round(d$Dim1,3);d$Dim2 <- round(d$Dim2,3);d
  }, striped=TRUE, spacing="xs", rownames=FALSE)

  p_post <- reactive({
    ggplot(post(), aes(cluster, poverty_2025, fill = cluster)) +
      geom_boxplot(alpha=.75, outlier.alpha=.75) +
      labs(title="2025 poverty by 2024 discovered group",
           subtitle="Descriptive comparison; poverty was withheld from fitting",
           x="Cluster based on 2024 economic characteristics",
           y="Synthetic poverty rate in 2025 (%)") +
      theme_minimal(base_size=12) + theme(legend.position="none")
  })
  output$post_poverty <- renderPlot({print(p_post())})
  p_zone <- reactive({
    dd <- as.data.frame(table(cluster = post()$cluster,
                              economic_zone = post()$economic_zone))
    ggplot(dd, aes(cluster, Freq, fill=economic_zone)) +
      geom_col() +
      labs(title="External zone labels by cluster",
           x="Discovered cluster",y="Number of synthetic regions",
           fill="Economic zone") + theme_minimal(base_size=12)
  })
  output$post_zone <- renderPlot({print(p_zone())})
  output$post_poverty_table <- renderTable({
    d <- post()
    z <- aggregate(d$poverty_2025, list(cluster = d$cluster),
                   function(x) c(n=length(x), mean=mean(x), median=median(x)))
    data.frame(cluster=z$cluster, n=z$x[,"n"],
               mean_poverty_2025=round(z$x[,"mean"],2),
               median_poverty_2025=round(z$x[,"median"],2))
  }, striped=TRUE, spacing="xs", rownames=FALSE)
  output$post_zone_table <- renderTable({
    as.data.frame.matrix(table(cluster=post()$cluster,
                               economic_zone=post()$economic_zone))
  }, striped=TRUE, spacing="xs", rownames=TRUE)

  output$download_clusters_csv <- downloadHandler(
    filename = function() paste0("Week3_Clusters_k",input$k,".csv"),
    content = function(file) {
      x <- cbind(scores(), X_raw)
      utils::write.csv(x, file, row.names = FALSE)
    }
  )
  output$download_pca_png <- downloadHandler(
    filename = function() "Week3_PCA_Scores.png",
    content = function(file) ggplot2::ggsave(file, p_pc_map(),
                                             width=10, height=6, dpi=180)
  )
  output$download_kmap_png <- downloadHandler(
    filename = function() paste0("Week3_Cluster_k",input$k,".png"),
    content = function(file) ggplot2::ggsave(file, p_cluster_map(),
                                             width=10, height=6, dpi=180)
  )
  output$download_dendro_png <- downloadHandler(
    filename=function() paste0("Week3_Hierarchical_",input$hmethod,"_k",input$hk,".png"),
    content=function(file){
      grDevices::png(file,width=1600,height=820,res=150)
      on.exit(grDevices::dev.off())
      draw_hierarchy(hcl(),input$hk,input$hmethod)
    }
  )
  output$download_hprofile_png <- downloadHandler(
    filename=function() paste0("Week3_Hierarchical_Profiles_k",input$hk,".png"),
    content=function(file) ggplot2::ggsave(file,p_hheat(),width=11,height=6,dpi=180)
  )
  output$download_mca_png <- downloadHandler(
    filename = function() "Week3_MCA_Category_Map.png",
    content = function(file) ggplot2::ggsave(file, p_mca(),
                                             width=10, height=6, dpi=180)
  )
  output$download_excel <- downloadHandler(
    filename = function() paste0("Week3_Shiny_Results_k",input$k,".xlsx"),
    content = function(file) {
      sheets <- list(
        Read_Me = data.frame(
          item = c("Workshop", "Dataset", "Unit", "Year", "Input indicators",
                   "Scaling", "K-means k", "Hierarchical method", "Hierarchical k",
                   "K-means k for overlap", "ARI", "MCA categorical input",
                   "Poverty/economic_zone", "Caution"),
          value = c("Pattern Discovery: Unsupervised ML", basename(input_file),
                    "120 fictional regions", "2024", paste(features,collapse=", "),
                    if(identical(input$scaling,"scaled")) "z-score" else "center only",
                    input$k, input$hmethod, input$hk, compare_k(),
                    sprintf("%.4f", hierarchy_ari(km_comparator()$cluster,hg())),
                    "rank-based Low / Mid / High tertiles for illustration",
                    "post-hoc only, never used in fitting or k selection",
                    "Cluster ID and PCA/MCA axis signs have no ordered meaning")),
        Input_2024 = profiles,
        Missing_Audit = missing_table,
        PCA_Variance = pv(),
        PCA_Loadings = pca_loadings(pc()),
        PCA_Scores = data.frame(region_id = profiles$region_id,
                                PC1=pc()$x[,1], PC2=pc()$x[,2]),
        K_Diagnostics = kd(),
        Cluster_Assignments = cbind(scores(), X_raw),
        Cluster_Profile_Raw = cluster_profiles(km(), FALSE),
        Cluster_Profile_Z = cluster_profiles(km(), TRUE),
        Hierarchical_Assignments = data.frame(region_id=profiles$region_id,
                           KMeans_Compared=km_comparator()$cluster,
                           Hierarchical_Group=hg()),
        Hierarchical_Sizes = data.frame(group=names(table(hg())),
                                         n=as.integer(table(hg()))),
        Hierarchical_Profile_Raw = hierarchy_profile_raw(),
        Hierarchical_Profile_Z = hierarchy_profile_z(),
        Hierarchical_Comparison = data.frame(KMeans_Group=rownames(overlap_counts()),
                          as.data.frame.matrix(overlap_counts()),check.names=FALSE,
                          row.names=NULL),
        Hierarchical_Overlap_Pct = data.frame(KMeans_Group=rownames(overlap_counts()),
                          round(as.data.frame.matrix(100*prop.table(overlap_counts(),1)),1),
                          check.names=FALSE,row.names=NULL),
        Hierarchical_Diagnostics = data.frame(method=input$hmethod,
                           hierarchical_k=input$hk,
                           kmeans_reference_k=compare_k(),
                           cut_height=hierarchy_cut_height(hcl(),input$hk),
                           adjusted_rand_index=hierarchy_ari(km_comparator()$cluster,hg())),
        Posthoc_2025 = post(),
        Economic_Zone_Comparison = as.data.frame.matrix(table(
          Cluster=post()$cluster, EconomicZone=post()$economic_zone))
      )
      if (requireNamespace("FactoMineR", quietly=TRUE) &&
          length(input$mca_features) >= 2) {
        sheets$MCA_Inputs <- mca_inputs()
        sheets$MCA_Inertia <- mca_eigen()
        sheets$MCA_Category_Coordinates <- mca_coords()
      }
      wb <- openxlsx::createWorkbook()
      for (n in names(sheets)) {
        openxlsx::addWorksheet(wb,n)
        openxlsx::writeDataTable(wb, sheet=n, x=sheets[[n]],
                                 tableStyle = "TableStyleMedium2")
        openxlsx::freezePane(wb, n, firstRow = TRUE)
        openxlsx::setColWidths(wb,n,cols=seq_len(ncol(sheets[[n]])),widths=20)
      }
      openxlsx::setColWidths(wb,"Read_Me",cols=2,widths=75)
      openxlsx::saveWorkbook(wb, file=file, overwrite=TRUE)
    }
  )
}

shinyApp(ui = ui, server = server)
