# Student quickstart | Week 3

1. Unzip the **Student Package** into one folder, including the workbook and `figures/` (if editing slides).
2. Install packages once:

```r
install.packages(c("readxl", "ggplot2", "cluster", "openxlsx", "FactoMineR"))
```

3. In RStudio, set the working directory to the folder containing `ML3_Student_Simplified_v3.R` and `ML3_Regional_Profiles_2024.xlsx`.
4. Execute:

```r
source("ML3_Student_Simplified_v3.R", echo = TRUE)
```

5. For the interactive demo, open `Shiny_Lab/app.R` from the **Complete Package**, set its folder as your RStudio working directory, and run `shiny::runApp(".")`.

## What to look for

- **PCA:** PC1/PC2 scores, loading directions and explained variation. The PCA graphic is not a geographic map.
- **K-means:** how changing k affects groups and silhouette.
- **Hierarchical:** leaves are regions; the merge height is a linkage criterion; the gold cut line creates k groups. Compare Average and Ward.D2, then read the standardized heatmap and group sizes.
- **K-means overlap:** cluster labels have no intrinsic numeric meaning; compare memberships or adjusted Rand index.
- **MCA:** categorical patterns in artificial Low/Mid/High data, not predicted poverty.
- **Post-hoc:** zone and poverty values are examined after cluster fitting and do not cause cluster assignments.
