# Introduction to Machine Learning for Economic Analysis
## Enhanced OLS Prediction Demonstration, v1.1

This release is based on the instructor's uploaded `ML1_Introduction_Demo(1).R`.
It **preserves the existing training/test split, six-variable OLS model,
preprocessing, and output files `01` through `11`** and appends educational
prediction visualizations, a simple OLS model, Stargazer tables, and one Excel
workbook.

**All data are synthetic.** `actual` means the simulated outcome observed in
the synthetic dataset; the files are not empirical evidence about Indonesia.

## Files

- `ML1_Introduction_Demo_OLS_v1_1.R`: complete executable R analysis.
- `ML1_Economic_Panel_Synthetic.xlsx`: input workbook used in the demo.
- `Reference_OLS_Predictions_2025.xlsx`: **precalculated, independent numerical
  reference** produced from the same workbook and model specification, not an
  actual R execution or Stargazer output. It lets instructors inspect the
  expected workbook structure and approximate numeric results.

## Installation / run in RStudio

```r
install.packages(c("readxl", "dplyr", "ggplot2", "stargazer", "openxlsx"))
```

1. Open `ML1_Introduction_Demo_OLS_v1_1.R`.
2. Edit the two variables `input_file` and `out_dir` in Section 0. Existing
   Windows F:/ paths are intentionally preserved from the submitted script.
   To use the extracted package as a self-contained folder, set:

```r
input_file <- "F:/MACHINE LEARNING WORKSHOP/Week 1/ML1_Introduction_Complete_Workshop/ML1_Economic_Panel_Synthetic.xlsx"
out_dir <- "F:/MACHINE LEARNING WORKSHOP/Week 1/ML1_Introduction_Complete_Workshop/ML1_outputs"
# OR, if the working directory is the extracted folder:
# input_file <- file.path(getwd(), "ML1_Economic_Panel_Synthetic.xlsx")
# out_dir <- file.path(getwd(), "ML1_outputs")
```

3. Run the script in RStudio (`Source`).
4. Check the printed model summaries, Stargazer table, plots, CSV files, and
   Excel workbook in `out_dir`.

## Primary instructional goal

Question: Can prior-year (t-1) economic indicators predict poverty in year t?

- Outcome years 2021-2024: fit models on 480 synthetic region-year rows.
- Outcome year 2025: make out-of-sample predictions for 120 fictitious regions.
- Compare a **training-mean benchmark**, a **simple OLS** model using lagged
  schooling, and a **multiple OLS** model using six lagged predictors.
- Show why model fit on training data and predictive accuracy on new data are
  distinct. **OLS is itself a supervised-learning method**; Ridge/LASSO are
  natural next steps for regularization in Session 2.

## Legacy output files preserved: 01-11

- `01_missing_counts.csv`: data quality check.
- `02_poverty_trend.png`: illustrative poverty trend by economic zone.
- `03_train_medians.csv`: predictor imputation parameters estimated from training.
- `04_schooling_poverty_train.png`: bivariate scatter + fitted visual.
- `05_holdout_metrics.csv`: original benchmark versus six-predictor OLS, 2025 MAE/RMSE.
- `06_2025_predictions.csv`: original holdout predictions.
- `07_ols_coefficients.csv`: original multivariate OLS coefficients.
- `08_holdout_actual_vs_predicted.png`: existing 2025 scatter + 45-degree reference.
- `09_holdout_mae_comparison.png`: existing benchmark/OLS comparison.
- `10_zone_error.csv`: 2025 subgroup MAE.
- `11_session_info.txt`: recorded R package versions and runtime information.

## New output files: 12-24

- `12_simple_ols_fitted_line.png`: simple regression **fitted using training**,
  superimposed on training observations and holdout observations.
- `13_stargazer_ols_training.txt`: training-sample regression tables in plain text.
- `14_stargazer_ols_training.html`: same tables formatted for browser/Word.
- `15_training_vs_holdout_performance.csv`: benchmark/simple/multiple OLS metrics
  (MAE, RMSE, mean prediction error, R2) for both time splits.
- `16_holdout_predictions_and_errors_2025.csv`: observed versus all three
  forecasts; signed and absolute OLS errors for each of the 120 regions.
- `17_training_fitted_values_2021_2024.csv`: training fitted values per row.
- `18_ols_coefficients_detailed.csv`: coefficients, SE, t-statistics, p-values.
- `19_holdout_observed_vs_predicted_all_regions.png`: two lines across all
  120 holdout regions, ranked by observed outcome.
- `20_holdout_prediction_gaps_top25.png`: actual-versus-predicted paired
  dots/segments for the 25 largest absolute errors (display subset only).
- `21_holdout_prediction_error_distribution.png`: histogram of signed error.
- `22_holdout_simple_vs_multiple_ols.png`: out-of-sample comparison with 45-degree line.
- `23_zone_diagnostics_extended.csv`: holdout error by synthetic economic zone.
- `24_ML1_OLS_Prediction_Results.xlsx`: one multi-sheet workbook with Overview,
  Model_Performance, Predictions_2025, Training_Fitted, OLS_Coefficients,
  Zone_Diagnostics, Training_Medians, and embedded Plots.

## Interpretation rules

- `signed_error = prediction - observed`. Positive error means an over-prediction;
  negative means an under-prediction. MAE and RMSE are in **percentage points**.
- Stargazer summarizes **training-sample estimation**, not 2025 predictive
  performance. Use `15_training_vs_holdout_performance.csv` and the Excel
  Model_Performance sheet for forecast comparisons.
- Ordinary `lm()` standard errors are printed solely to illustrate regression
  output. With repeated regions across years, they should **not** be treated
  as appropriately cluster-adjusted for substantive panel inference.
- The coefficient interpretation is predictive/associational, **not causal**.
- 2025 testing performance does not establish 2026 predictive accuracy.
- `R2_relative_to_sample_mean` uses a separate observed sample mean per split;
  this differs from the fixed training-mean benchmark used in the MAE/RMSE
  comparison and can legitimately be negative.

## Instructor teaching flow

1. Show the simulated poverty versus schooling scatter and hand-drawn
   regression line in Shiny.
2. Estimate simple OLS; compare the fitted line with the Shiny illustration.
3. Estimate six-variable OLS; inspect coefficients in R/Stargazer.
4. Compare in-sample with 2025 out-of-sample errors.
5. Open the 120-region actual/predicted plot and identify poor predictions.
6. Open `24_ML1_OLS_Prediction_Results.xlsx`, sort signed/absolute errors,
   discuss which regions are under- or over-predicted.
7. Ask why better training fit does not guarantee better holdout accuracy.

## Validation status

- Structural and numerical consistency was independently checked against the
  bundled synthetic dataset, including training and testing sample counts and
  OLS prediction metrics (see reference workbook).
- **The R script has not been executed in an R runtime in the creation
  environment.** Run it in RStudio and report any errors for a patch.
