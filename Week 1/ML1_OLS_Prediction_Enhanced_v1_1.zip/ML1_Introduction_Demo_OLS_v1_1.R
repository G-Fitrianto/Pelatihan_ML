# ============================================================================
# INTRODUCTION TO MACHINE LEARNING FOR ECONOMIC ANALYSIS
# Workshop 1 | Instructor: Gigih Fitrianto
# Dataset: ML1_Economic_Panel_Synthetic.xlsx (fully synthetic teaching data)
#
# QUESTION: Can prior-year regional indicators predict next-year poverty rates?
# DATA: 120 fictitious regions, 2020-2025 (720 region-year records).
# TRAIN: outcomes in 2021-2024 | TEST: outcomes in 2025.
# PREDICTORS: indicators from t-1 only, available before the outcome year.
#
# Run line by line in RStudio. Set the working directory to the folder
# containing BOTH this file and the accompanying Excel workbook.
# ============================================================================

# 0. SETUP --------------------------------------------------------------------
required_packages <- c("readxl", "dplyr", "ggplot2", "stargazer", "openxlsx")
missing_packages <- required_packages[
  !vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)
]
if (length(missing_packages) > 0) {
  stop("Install missing packages first: install.packages(c('",
       paste(missing_packages, collapse = "', '"), "'))")
}

library(readxl)
library(dplyr)
library(ggplot2)

input_file <- "F:/MACHINE LEARNING WORKSHOP/Week 1/ML1_Introduction_Complete_Workshop/ML1_Economic_Panel_Synthetic.xlsx"
out_dir <- "F:/MACHINE LEARNING WORKSHOP/Week 1/ML1_Introduction_Complete_Workshop/ML1_outputs"
if (!file.exists(input_file)) {
  stop("Input workbook not found at: ", input_file, "\nEdit input_file in Section 0.")
}
if (!dir.exists(out_dir)) dir.create(out_dir, recursive = TRUE)

cat("Current working directory:", getwd(), "\n")

# 1. IMPORT AND UNDERSTAND THE DATA ------------------------------------------
raw <- read_excel(input_file, sheet = "Economic_Panel")
print(dim(raw))       # Expected: 720 rows x 10 columns
print(names(raw))
print(head(raw, 6))
print(count(raw, year))
cat("Number of synthetic regions:", n_distinct(raw$region_id), "\n")

# IMPORTANT: This dataset is ARTIFICIAL. Results are not evidence about Indonesia.

# 2. EXPLORATORY DATA ANALYSIS ------------------------------------------------
missing_counts <- data.frame(
  variable = names(raw),
  missing_n = vapply(raw, function(x) sum(is.na(x)), integer(1))
)
print(missing_counts)
write.csv(missing_counts, file.path(out_dir, "01_missing_counts.csv"), row.names = FALSE)

# EDA may use all data for descriptive illustration. Model design and
# model-selection decisions must not use 2025 outcomes.
poverty_trend <- raw %>%
  group_by(year, economic_zone) %>%
  summarise(mean_poverty = mean(poverty_rate_pct), .groups = "drop")

p_trend <- ggplot(poverty_trend,
                 aes(year, mean_poverty, color = economic_zone)) +
  geom_line(linewidth = 0.9) +
  geom_point(size = 1.7) +
  labs(title = "Synthetic poverty trend by economic zone",
       x = "Year", y = "Mean poverty rate (%)", color = "Economic zone") +
  theme_minimal(base_size = 12)
ggsave(file.path(out_dir, "02_poverty_trend.png"), p_trend,
       width = 8.4, height = 5.0, dpi = 180)
print(p_trend)

# 3. DEFINE THE PREDICTION TASK AND CONSTRUCT LAGS ----------------------------
# Regional values in year t-1 are allowed inputs for predicting poverty in t.
# We must SORT by region and year BEFORE using lag().
predictors <- c(
  "grdp_pc_million_idr", "unemployment_pct", "schooling_years",
  "internet_access_pct", "manufacturing_share_pct",
  "investment_pc_million_idr"
)

panel <- raw %>%
  arrange(region_id, year) %>%
  group_by(region_id) %>%
  mutate(across(all_of(predictors), dplyr::lag, .names = "lag_{.col}")) %>%
  ungroup() %>%
  filter(year >= 2021)  # The 2020 year has no t-1 data in the workbook.

lag_predictors <- paste0("lag_", predictors)
stopifnot(nrow(panel) == 600L)  # 120 synthetic regions x 5 target years
cat("Available modeling rows:", nrow(panel), "\n")

# Quick audit: for REG001 in 2025, each lagged value comes from 2024.
print(panel %>% filter(region_id == "REG001", year %in% c(2024, 2025)) %>%
        select(region_id, year, grdp_pc_million_idr,
               lag_grdp_pc_million_idr, poverty_rate_pct))

# 4. TIME-BASED SPLIT: LEARN IN THE PAST, TEST IN THE FUTURE --------------------
# Target outcomes from 2021-2024 form the training period.
# Target outcomes from 2025 form the untouched holdout period.
train <- panel %>% filter(year <= 2024)
test  <- panel %>% filter(year == 2025)
stopifnot(nrow(train) == 480L, nrow(test) == 120L)
stopifnot(max(train$year) < min(test$year))
cat("Training rows:", nrow(train), "; test rows:", nrow(test), "\n")

# 5. HANDLE MISSING PREDICTORS WITHOUT LEAKAGE --------------------------------
# Learn each median from TRAINING ONLY, then apply it to both datasets.
# This introductory strategy is simple; more advanced model pipelines use
# resampling-aware preprocessing and compare alternative imputation methods.
medians <- vapply(lag_predictors, function(v) {
  median(train[[v]], na.rm = TRUE)
}, numeric(1))
stopifnot(all(is.finite(medians)))

for (v in lag_predictors) {
  train[[v]][is.na(train[[v]])] <- medians[[v]]
  test[[v]][is.na(test[[v]])]   <- medians[[v]]
}
stopifnot(!anyNA(train[, lag_predictors]), !anyNA(test[, lag_predictors]))
write.csv(data.frame(variable = names(medians), training_median = medians),
          file.path(out_dir, "03_train_medians.csv"), row.names = FALSE)

# Illustrate lagged predictor vs outcome (training sample only)
p_relation <- ggplot(train, aes(lag_schooling_years, poverty_rate_pct)) +
  geom_point(alpha = 0.40, color = "#407958") +
  geom_smooth(method = "lm", se = FALSE, color = "#B58A25") +
  labs(title = "Training data: lagged schooling vs poverty",
       x = "Years of schooling in year t-1", y = "Poverty rate in year t (%)") +
  theme_minimal(base_size = 12)
ggsave(file.path(out_dir, "04_schooling_poverty_train.png"), p_relation,
       width = 8.4, height = 5.0, dpi = 180)
print(p_relation)

# 6. TWO PREDICTION RULES: BASELINE AND LINEAR MODEL ---------------------------
# A. Very simple benchmark: always predict the training-period average.
baseline_value <- mean(train$poverty_rate_pct)
test$pred_baseline <- rep(baseline_value, nrow(test))

# B. Supervised model: multiple linear regression, fitted on training only.
# lm() is used to make the ML workflow transparent for economics students.
# Model complexity and shrinkage (LASSO) are covered in Session 2.
model_formula <- reformulate(lag_predictors, response = "poverty_rate_pct")
ols_model <- lm(model_formula, data = train)
print(summary(ols_model))
test$pred_ols <- as.numeric(predict(ols_model, newdata = test))

# 7. EVALUATE ONLY ON THE 2025 HOLDOUT ----------------------------------------
mae <- function(actual, predicted) mean(abs(actual - predicted))
rmse <- function(actual, predicted) sqrt(mean((actual - predicted)^2))

metrics <- data.frame(
  model = c("Training-mean benchmark", "OLS with lagged indicators"),
  MAE = c(mae(test$poverty_rate_pct, test$pred_baseline),
          mae(test$poverty_rate_pct, test$pred_ols)),
  RMSE = c(rmse(test$poverty_rate_pct, test$pred_baseline),
           rmse(test$poverty_rate_pct, test$pred_ols))
)
print(metrics)
write.csv(metrics, file.path(out_dir, "05_holdout_metrics.csv"), row.names = FALSE)
write.csv(test %>%
            select(region_id, economic_zone, year, poverty_rate_pct,
                   pred_baseline, pred_ols),
          file.path(out_dir, "06_2025_predictions.csv"), row.names = FALSE)
write.csv(data.frame(variable = names(coef(ols_model)),
                     estimate = as.numeric(coef(ols_model))),
          file.path(out_dir, "07_ols_coefficients.csv"), row.names = FALSE)

# Compare the observed outcomes and 2025 out-of-sample predictions.
p_pred <- ggplot(test, aes(poverty_rate_pct, pred_ols)) +
  geom_point(alpha = 0.70, color = "#407958", size = 1.9) +
  geom_abline(slope = 1, intercept = 0, linetype = "dashed",
              color = "#B58A25", linewidth = 0.8) +
  coord_equal() +
  labs(title = "Out-of-sample predictions: holdout year 2025",
       subtitle = "Dashed line = perfect agreement",
       x = "Actual poverty rate (%)", y = "Predicted poverty rate (%)") +
  theme_minimal(base_size = 12)
ggsave(file.path(out_dir, "08_holdout_actual_vs_predicted.png"), p_pred,
       width = 7.2, height = 5.5, dpi = 180)
print(p_pred)

p_metric <- ggplot(metrics, aes(model, MAE, fill = model)) +
  geom_col(width = 0.58) +
  labs(title = "Holdout MAE: simpler is not always better",
       x = NULL, y = "Mean absolute error (percentage points)") +
  theme_minimal(base_size = 12) +
  theme(legend.position = "none", axis.text.x = element_text(angle = 10, hjust = 0.5))
ggsave(file.path(out_dir, "09_holdout_mae_comparison.png"), p_metric,
       width = 8.3, height = 5.0, dpi = 180)
print(p_metric)

# 8. SUBGROUP DIAGNOSTIC (DESCRIPTIVE) ----------------------------------------
# Investigate if model errors differ across fictitious economic zones.
zone_error <- test %>%
  group_by(economic_zone) %>%
  summarise(n = n(), MAE = mae(poverty_rate_pct, pred_ols), .groups = "drop")
print(zone_error)
write.csv(zone_error, file.path(out_dir, "10_zone_error.csv"), row.names = FALSE)

# 9. WORKSHOP REFLECTION -------------------------------------------------------
cat("\nREFLECTION QUESTIONS:\n")
cat("1. Why are predictors lagged by one year?\n")
cat("2. Why must imputation medians be learned from training only?\n")
cat("3. Can these predictive coefficients support causal claims? (No.)\n")
cat("4. Does a 2025 holdout guarantee stable performance in 2026? (No.)\n")
cat("5. What would you try in Session 2? (LASSO / regularization.)\n")

writeLines(capture.output(sessionInfo()),
           con = file.path(out_dir, "11_session_info.txt"))
cat("\nDone. Outputs saved to:", normalizePath(out_dir), "\n")
# ============================================================================


# ============================================================================
# 10. WORKSHOP EXTENSION v1.1 | OLS FIT AND OUT-OF-SAMPLE VISUAL DIAGNOSTICS
# All original models, splitting, imputation and outputs 01-11 remain unchanged.
# New outputs are numbered 12 onward. Synthetic dataset: NOT real Indonesian data.
# ============================================================================

# 10A. SIMPLE OLS FIT: show how the fitted line is actually estimated ----------
# This is an additional model. The existing multivariate OLS is unchanged.
ols_simple <- lm(poverty_rate_pct ~ lag_schooling_years, data = train)
print(summary(ols_simple))

train$pred_baseline <- rep(baseline_value, nrow(train))
train$pred_simple_ols <- as.numeric(predict(ols_simple, newdata = train))
train$pred_multiple_ols <- as.numeric(predict(ols_model, newdata = train))

test$pred_simple_ols <- as.numeric(predict(ols_simple, newdata = test))
test$pred_multiple_ols <- test$pred_ols  # Same 2025 predictions as original script.

# Signed prediction error = predicted minus observed (positive = over-prediction).
train$error_simple_ols <- train$pred_simple_ols - train$poverty_rate_pct
train$error_multiple_ols <- train$pred_multiple_ols - train$poverty_rate_pct
test$error_simple_ols <- test$pred_simple_ols - test$poverty_rate_pct
test$error_multiple_ols <- test$pred_multiple_ols - test$poverty_rate_pct
test$absolute_error_multiple_ols <- abs(test$error_multiple_ols)

# Correct line-fitting demonstration: the orange line below comes explicitly
# from ols_simple fitted on 2021-2024, NOT a line estimated on the 2025 holdout.
x_grid <- data.frame(
  lag_schooling_years = seq(min(train$lag_schooling_years),
                            max(train$lag_schooling_years), length.out = 200)
)
x_grid$pred_simple_ols <- as.numeric(predict(ols_simple, newdata = x_grid))

p_simple_fit <- ggplot() +
  geom_point(data = train,
             aes(x = lag_schooling_years, y = poverty_rate_pct),
             alpha = 0.30, size = 1.5, color = "grey45") +
  geom_line(data = x_grid,
            aes(x = lag_schooling_years, y = pred_simple_ols),
            linewidth = 1.15, color = "#B58A25") +
  geom_point(data = test,
             aes(x = lag_schooling_years, y = poverty_rate_pct),
             size = 2.0, alpha = 0.65, color = "#407958") +
  labs(title = "Simple OLS: poverty and prior-year schooling",
       subtitle = "Grey = training (2021-2024), green = observed test (2025); line fitted only on training",
       x = "Schooling in year t-1 (years)", y = "Poverty in year t (%)") +
  theme_minimal(base_size = 12)
ggsave(file.path(out_dir, "12_simple_ols_fitted_line.png"), p_simple_fit,
       width = 10, height = 5.8, dpi = 180)
print(p_simple_fit)

# 10B. STARGAZER: show the two estimated regression specifications -------------
# Stargazer contains IN-SAMPLE coefficient estimates and inference only.
# Predictive accuracy is reported separately on the untouched 2025 test data.
cat("\n================ STARGAZER: TRAINING-SAMPLE OLS ================\n")
stargazer::stargazer(
  ols_simple, ols_model, type = "text",
  title = "OLS Regression Models (2021-2024 Training Sample)",
  column.labels = c("Simple OLS", "Multiple OLS"),
  dep.var.labels = "Poverty rate (%)",
  digits = 3, no.space = TRUE, header = FALSE
)

stargazer::stargazer(
  ols_simple, ols_model, type = "text",
  title = "OLS Regression Models (2021-2024 Training Sample)",
  column.labels = c("Simple OLS", "Multiple OLS"),
  dep.var.labels = "Poverty rate (%)",
  digits = 3, no.space = TRUE, header = FALSE,
  out = file.path(out_dir, "13_stargazer_ols_training.txt")
)
stargazer::stargazer(
  ols_simple, ols_model, type = "html",
  title = "OLS Regression Models (2021-2024 Training Sample)",
  column.labels = c("Simple OLS", "Multiple OLS"),
  dep.var.labels = "Poverty rate (%)",
  digits = 3, no.space = TRUE, header = FALSE,
  out = file.path(out_dir, "14_stargazer_ols_training.html")
)

# 10C. TRAIN AND TEST EVALUATION -----------------------------------------------
# MAE/RMSE are measured in poverty percentage points, not percent relative error.
# Here, prediction bias means average predicted minus observed poverty.
scoring <- function(actual, predicted) {
  ok <- is.finite(actual) & is.finite(predicted)
  stopifnot(any(ok))
  actual <- actual[ok]; predicted <- predicted[ok]
  denom <- sum((actual - mean(actual))^2)
  data.frame(
    n = length(actual),
    MAE = mean(abs(predicted - actual)),
    RMSE = sqrt(mean((predicted - actual)^2)),
    mean_prediction_error = mean(predicted - actual),
    R2_relative_to_sample_mean = if (denom > 0) {
      1 - sum((actual - predicted)^2) / denom
    } else NA_real_
  )
}

build_metrics <- function(dataset, split_label) {
  model_cols <- c("pred_baseline", "pred_simple_ols", "pred_multiple_ols")
  labels <- c("Training-mean benchmark", "Simple OLS: schooling",
              "Multiple OLS: six lagged indicators")
  do.call(rbind, lapply(seq_along(model_cols), function(k) {
    cbind(data.frame(split = split_label, model = labels[k]),
          scoring(dataset$poverty_rate_pct, dataset[[model_cols[k]]]))
  }))
}

all_performance <- rbind(build_metrics(train, "Training: 2021-2024"),
                         build_metrics(test, "Holdout: 2025"))
rownames(all_performance) <- NULL
cat("\n================ MODEL PERFORMANCE ================\n")
print(all_performance, row.names = FALSE, digits = 4)
write.csv(all_performance,
          file.path(out_dir, "15_training_vs_holdout_performance.csv"),
          row.names = FALSE)

# Important: R2_relative_to_sample_mean uses a separate mean within each split.
# The testing value can be negative. This is NOT the same benchmark as the
# fixed training-mean forecast evaluated in the main RMSE/MAE comparison.

# 10D. PREDICTIONS AND ERRORS: ONE ROW PER FICTITIOUS REGION -----------------
# Keep the full 2025 holdout intact: no sorting/trimming in the saved data.
holdout_predictions <- test %>%
  transmute(
    region_id, economic_zone, year,
    actual_poverty_pct = poverty_rate_pct,
    predicted_baseline_pct = pred_baseline,
    predicted_simple_ols_pct = pred_simple_ols,
    predicted_multiple_ols_pct = pred_multiple_ols,
    signed_error_simple_ols_pp = error_simple_ols,
    signed_error_multiple_ols_pp = error_multiple_ols,
    absolute_error_multiple_ols_pp = absolute_error_multiple_ols,
    lag_schooling_years,
    lag_grdp_pc_million_idr,
    lag_unemployment_pct,
    lag_internet_access_pct,
    lag_manufacturing_share_pct,
    lag_investment_pc_million_idr
  )

train_predictions <- train %>%
  transmute(region_id, economic_zone, year,
            actual_poverty_pct = poverty_rate_pct,
            predicted_baseline_pct = pred_baseline,
            predicted_simple_ols_pct = pred_simple_ols,
            predicted_multiple_ols_pct = pred_multiple_ols,
            signed_error_multiple_ols_pp = error_multiple_ols)

write.csv(holdout_predictions,
          file.path(out_dir, "16_holdout_predictions_and_errors_2025.csv"),
          row.names = FALSE)
write.csv(train_predictions,
          file.path(out_dir, "17_training_fitted_values_2021_2024.csv"),
          row.names = FALSE)

# Extract estimates/SE/t-stat/p-values from training OLS (not test sample).
extract_coefs <- function(fit, label) {
  ct <- summary(fit)$coefficients
  data.frame(
    model = label,
    term = rownames(ct),
    estimate = unname(ct[, 1]),
    std_error = unname(ct[, 2]),
    t_statistic = unname(ct[, 3]),
    p_value = unname(ct[, 4]),
    row.names = NULL
  )
}
coefficient_table <- rbind(
  extract_coefs(ols_simple, "Simple OLS"),
  extract_coefs(ols_model, "Multiple OLS")
)
write.csv(coefficient_table,
          file.path(out_dir, "18_ols_coefficients_detailed.csv"),
          row.names = FALSE)

# 10E. OUT-OF-SAMPLE PLOTS ----------------------------------------------------
# (a) Ordered regional plot: observed and predicted curves for ALL 120 test rows.
ordered_test <- holdout_predictions %>%
  arrange(actual_poverty_pct) %>%
  mutate(observation_rank = row_number())

p_holdout_series <- ggplot(ordered_test, aes(x = observation_rank)) +
  geom_line(aes(y = actual_poverty_pct, color = "Observed 2025"), linewidth = 1.0) +
  geom_line(aes(y = predicted_multiple_ols_pct, color = "OLS prediction"),
            linewidth = 0.95) +
  scale_color_manual(values = c("Observed 2025" = "#407958",
                                "OLS prediction" = "#B58A25")) +
  labs(title = "2025 holdout: observed versus OLS-predicted poverty",
       subtitle = "120 fictitious regions ranked by observed poverty; model never fitted on 2025",
       x = "Region rank (low to high observed poverty)",
       y = "Poverty rate (%)", color = NULL) +
  theme_minimal(base_size = 12) +
  theme(legend.position = "bottom")
ggsave(file.path(out_dir, "19_holdout_observed_vs_predicted_all_regions.png"),
       p_holdout_series, width = 11, height = 5.8, dpi = 180)
print(p_holdout_series)

# (b) Dumbbell plot for 25 largest absolute errors (selection for DISPLAY ONLY).
# All 120 observations remain in workbook/CSV.
top_errors <- holdout_predictions %>%
  arrange(desc(absolute_error_multiple_ols_pp)) %>%
  slice_head(n = 25) %>%
  arrange(signed_error_multiple_ols_pp) %>%
  mutate(region_label = factor(region_id, levels = region_id))

p_gaps <- ggplot(top_errors) +
  geom_segment(aes(x = actual_poverty_pct, xend = predicted_multiple_ols_pct,
                   y = region_label, yend = region_label),
               linewidth = 1.0, color = "grey55") +
  geom_point(aes(x = actual_poverty_pct, y = region_label,
                 color = "Observed"), size = 2.8) +
  geom_point(aes(x = predicted_multiple_ols_pct, y = region_label,
                 color = "OLS predicted"), size = 2.8) +
  scale_color_manual(values = c("Observed" = "#407958",
                                "OLS predicted" = "#B58A25")) +
  labs(title = "Which regions have the largest 2025 prediction gaps?",
       subtitle = "25 largest absolute OLS errors; connecting segment is the magnitude of the gap",
       x = "Poverty rate (%)", y = NULL, color = NULL) +
  theme_minimal(base_size = 12) +
  theme(legend.position = "bottom")
ggsave(file.path(out_dir, "20_holdout_prediction_gaps_top25.png"),
       p_gaps, width = 10.3, height = 8.0, dpi = 180)
print(p_gaps)

# (c) Histogram of signed prediction errors: bias and spread across regions.
p_error <- ggplot(holdout_predictions,
                  aes(x = signed_error_multiple_ols_pp)) +
  geom_histogram(bins = 22, fill = "#4472A2", color = "white") +
  geom_vline(xintercept = 0, linetype = "dashed", color = "black") +
  geom_vline(xintercept = mean(holdout_predictions$signed_error_multiple_ols_pp),
             color = "#B58A25", linewidth = 1.05) +
  labs(title = "2025 out-of-sample error distribution",
       subtitle = "Signed error = predicted minus observed; positive means over-prediction",
       x = "Prediction error (percentage points)", y = "Number of regions") +
  theme_minimal(base_size = 12)
ggsave(file.path(out_dir, "21_holdout_prediction_error_distribution.png"),
       p_error, width = 9, height = 5.6, dpi = 180)
print(p_error)

# (d) Scatter: compare simple vs multiple OLS out-of-sample forecasts.
comparison_points <- rbind(
  data.frame(actual = holdout_predictions$actual_poverty_pct,
             predicted = holdout_predictions$predicted_simple_ols_pct,
             model = "Simple OLS"),
  data.frame(actual = holdout_predictions$actual_poverty_pct,
             predicted = holdout_predictions$predicted_multiple_ols_pct,
             model = "Multiple OLS")
)
p_two_ols <- ggplot(comparison_points, aes(actual, predicted)) +
  geom_point(alpha = 0.65, color = "#407958", size = 1.5) +
  geom_abline(slope = 1, intercept = 0, linetype = "dashed",
              color = "#B58A25") +
  facet_wrap(~model) +
  coord_equal() +
  labs(title = "Out-of-sample prediction: simple versus multiple OLS",
       subtitle = "Each point is a 2025 region. Dashed line indicates exact prediction.",
       x = "Observed poverty (%)", y = "Predicted poverty (%)") +
  theme_minimal(base_size = 12)
ggsave(file.path(out_dir, "22_holdout_simple_vs_multiple_ols.png"),
       p_two_ols, width = 10.8, height = 5.4, dpi = 180)
print(p_two_ols)

# 10F. HOLDOUT SUBGROUP DIAGNOSTIC --------------------------------------------
zone_diagnostics <- holdout_predictions %>%
  group_by(economic_zone) %>%
  summarise(
    n = n(),
    MAE_simple_ols = mean(abs(signed_error_simple_ols_pp)),
    MAE_multiple_ols = mean(abs(signed_error_multiple_ols_pp)),
    RMSE_multiple_ols = sqrt(mean(signed_error_multiple_ols_pp^2)),
    mean_error_multiple_ols = mean(signed_error_multiple_ols_pp),
    .groups = "drop"
  )
write.csv(zone_diagnostics, file.path(out_dir, "23_zone_diagnostics_extended.csv"),
          row.names = FALSE)
print(zone_diagnostics)

# 10G. SINGLE XLSX WORKBOOK WITH ALL MAJOR RESULTS AND FIGURES -----------------
# This workbook is created WHEN R is run. Actuals are observed values from a
# SYNTHETIC workbook, not administrative poverty data from Indonesia.
wb <- openxlsx::createWorkbook()

overview <- data.frame(
  item = c("Workshop", "Dataset", "Data status", "Question", "Training outcomes",
           "Test outcomes", "Training observations", "Test observations",
           "Simple model", "Multiple model", "Main outcome unit",
           "Prediction error convention", "Evaluation caveat", "Causal caveat"),
  value = c(
    "Introduction to Machine Learning for Economic Analysis",
    "ML1_Economic_Panel_Synthetic.xlsx",
    "Fully synthetic; fictitious regions; NOT observed Indonesian regional data",
    "Can prior-year indicators predict current-year regional poverty?",
    "2021-2024", "2025", nrow(train), nrow(test),
    "Poverty(t) ~ Schooling(t-1)",
    paste("Poverty(t) ~", paste(lag_predictors, collapse = " + ")),
    "Poverty percentage points",
    "Prediction minus observed; positive = over-prediction",
    "Single 2025 holdout is an illustration, not proof of 2026 performance",
    "Predictive OLS coefficients alone are not causal effects"
  ), stringsAsFactors = FALSE
)

sheets <- list(
  "Overview" = overview,
  "Model_Performance" = all_performance,
  "Predictions_2025" = holdout_predictions,
  "Training_Fitted" = train_predictions,
  "OLS_Coefficients" = coefficient_table,
  "Zone_Diagnostics" = zone_diagnostics,
  "Training_Medians" = data.frame(
    predictor = names(medians), training_median = unname(medians))
)

for (sheet_name in names(sheets)) {
  openxlsx::addWorksheet(wb, sheet_name)
  openxlsx::writeDataTable(wb, sheet = sheet_name, x = sheets[[sheet_name]],
                            startRow = 1, startCol = 1,
                            tableStyle = "TableStyleMedium2")
  openxlsx::freezePane(wb, sheet = sheet_name, firstRow = TRUE)
  openxlsx::setColWidths(wb, sheet = sheet_name,
                         cols = seq_len(ncol(sheets[[sheet_name]])), widths = 19)
}
openxlsx::setColWidths(wb, "Overview", cols = 2, widths = 88)
openxlsx::setColWidths(wb, "OLS_Coefficients", cols = 2, widths = 37)
openxlsx::setColWidths(wb, "Model_Performance", cols = 2, widths = 39)
openxlsx::setColWidths(wb, "Predictions_2025", cols = 1:2, widths = c(16, 22))

openxlsx::addWorksheet(wb, "Plots")
openxlsx::writeData(wb, sheet = "Plots", x =
  "Illustrative plots: complete regional predictions are in Predictions_2025", startRow = 1)
# Excel supports embedded PNG images; individual high-resolution files are also saved.
openxlsx::insertImage(wb, "Plots",
  file = file.path(out_dir, "19_holdout_observed_vs_predicted_all_regions.png"),
  startRow = 3, startCol = 1, width = 9, height = 4.8, units = "in")
openxlsx::insertImage(wb, "Plots",
  file = file.path(out_dir, "20_holdout_prediction_gaps_top25.png"),
  startRow = 28, startCol = 1, width = 8.5, height = 6.5, units = "in")
openxlsx::insertImage(wb, "Plots",
  file = file.path(out_dir, "22_holdout_simple_vs_multiple_ols.png"),
  startRow = 63, startCol = 1, width = 9, height = 4.8, units = "in")

excel_output <- file.path(out_dir, "24_ML1_OLS_Prediction_Results.xlsx")
openxlsx::saveWorkbook(wb, file = excel_output, overwrite = TRUE)
cat("\nCreated Excel workbook:", normalizePath(excel_output), "\n")
cat("Stargazer output: 13_stargazer_ols_training.txt / 14_stargazer_ols_training.html\n")
cat("Holdout diagnostics: 19-22 PNG figures, 16_holdout_predictions_and_errors_2025.csv\n")
cat("All legacy outputs (01-11) remain available.\n")
# ============================================================================
